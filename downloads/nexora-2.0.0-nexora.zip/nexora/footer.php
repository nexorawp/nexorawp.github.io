<?php
/**
 * Footer.
 *
 * @package Nexora
 */
?>

<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
	<div class="nexora-ad-band nexora-ad-band--footer"><?php nexora_ad_slot( 'footer' ); ?></div>
<?php endif; ?>

<footer class="nexora-footer">
	<div class="nexora-wrap nexora-footer__grid">
		<div class="nexora-footer__col nexora-footer__col--brand">
			<?php if ( has_custom_logo() ) : ?>
				<div class="nexora-logo nexora-logo--custom nexora-footer__logo"><?php the_custom_logo(); ?></div>
			<?php else : ?>
				<a class="nexora-logo nexora-footer__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<img class="nexora-logo__icon" src="<?php echo esc_url( nexora_mark_url( 'svg' ) ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="24" height="24" decoding="async">
					<span aria-hidden="true"><?php nexora_logo_wordmark(); ?></span>
				</a>
			<?php endif; ?>
			<?php
			$footer_blurb = trim( (string) get_bloginfo( 'description', 'display' ) );
			if ( '' === $footer_blurb ) {
				$footer_blurb = __( 'Practical magazine guides — clear writing for everyday questions.', 'nexora' );
			}
			?>
			<p class="nexora-footer__blurb"><?php echo esc_html( $footer_blurb ); ?></p>
			<p class="nexora-footer__mail">
				<a href="mailto:<?php echo esc_attr( nexora_contact_email() ); ?>"><?php echo esc_html( nexora_contact_email() ); ?></a>
			</p>
		</div>

		<div class="nexora-footer__cluster">
			<nav class="nexora-footer__col nexora-footer__col--explore" aria-label="<?php esc_attr_e( 'Explore', 'nexora' ); ?>">
				<p class="nexora-footer__label"><?php esc_html_e( 'Explore', 'nexora' ); ?></p>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer_explore',
						'container'      => false,
						'menu_class'     => 'nexora-footer__links',
						'fallback_cb'    => 'nexora_fallback_footer_explore',
						'depth'          => 2,
						'walker'         => class_exists( 'Nexora_Nav_Walker' ) ? new Nexora_Nav_Walker() : null,
					)
				);
				?>
			</nav>

			<nav class="nexora-footer__col nexora-footer__col--legal" aria-label="<?php esc_attr_e( 'Legal', 'nexora' ); ?>">
				<p class="nexora-footer__label"><?php esc_html_e( 'Legal', 'nexora' ); ?></p>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer_legal',
						'container'      => false,
						'menu_class'     => 'nexora-footer__links',
						'fallback_cb'    => 'nexora_fallback_footer_legal',
						'depth'          => 1,
					)
				);
				?>
			</nav>

			<div class="nexora-footer__col nexora-footer__col--disclaimer">
				<p class="nexora-footer__label"><?php esc_html_e( 'Disclaimer', 'nexora' ); ?></p>
				<p class="nexora-disclosure nexora-footer__disclosure"><?php echo nexora_disclosure(); ?></p>
			</div>

			<?php if ( function_exists( 'nexora_footer_newsletter' ) ) : ?>
				<?php nexora_footer_newsletter(); ?>
			<?php endif; ?>
		</div>
	</div>
	<div class="nexora-wrap nexora-footer__base">
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'nexora' ); ?></p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
