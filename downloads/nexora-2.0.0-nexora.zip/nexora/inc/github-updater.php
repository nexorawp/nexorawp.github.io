<?php
/**
 * Automatic theme updates from GitHub Releases (private repo OK).
 *
 * Single channel: Nexora theme from
 * https://github.com/sanjaypaul-777/nexora (legacy paulworld-*.zip assets still accepted).
 * Token (first match wins):
 *   1. define( 'NEXORA_GITHUB_TOKEN', 'ghp_…' ); in wp-config.php
 *   2. Appearance → Nexora → Advanced (stored as option nexora_github_token)
 * Optional:
 *   define( 'NEXORA_GITHUB_REPO', 'sanjaypaul-777/nexora' );
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var string Canonical GitHub owner/repo after rename to Nexora. */
const NEXORA_GITHUB_REPO_DEFAULT = 'sanjaypaul-777/nexora';

/**
 * Whether a release asset name is this theme’s zip (legacy paulworld-* or nexora-*).
 *
 * @param string $name Asset filename.
 * @return bool
 */
function nexora_is_theme_release_zip( $name ) {
	return (bool) preg_match( '/^(paulworld|nexora)-.+\.zip$/i', (string) $name );
}

/**
 * GitHub owner/repo for updates.
 *
 * @return string
 */
function nexora_github_repo() {
	if ( defined( 'NEXORA_GITHUB_REPO' ) && NEXORA_GITHUB_REPO ) {
		$repo = (string) NEXORA_GITHUB_REPO;
	} else {
		$repo = NEXORA_GITHUB_REPO_DEFAULT;
	}
	$repo = preg_replace( '#^https?://github\.com/#', '', trim( $repo, " \t\n\r\0\x0B/" ) );
	return is_string( $repo ) && $repo ? $repo : NEXORA_GITHUB_REPO_DEFAULT;
}

/**
 * Public GitHub URL for the theme repo.
 *
 * @return string
 */
function nexora_github_repo_url() {
	return 'https://github.com/' . nexora_github_repo();
}

/**
 * GitHub PAT for private release updates.
 * Prefers wp-config constant; falls back to Appearance → Nexora → Advanced.
 *
 * @return string
 */
function nexora_github_token() {
	if ( defined( 'NEXORA_GITHUB_TOKEN' ) && NEXORA_GITHUB_TOKEN ) {
		return trim( (string) NEXORA_GITHUB_TOKEN );
	}
	$stored = get_option( 'nexora_github_token', '' );
	return is_string( $stored ) ? trim( $stored ) : '';
}

/**
 * Whether the active token comes from wp-config.php.
 *
 * @return bool
 */
function nexora_github_token_from_wp_config() {
	return defined( 'NEXORA_GITHUB_TOKEN' ) && (bool) NEXORA_GITHUB_TOKEN;
}

/**
 * Optional auth headers (private repo + token).
 *
 * @return array<string,string>
 */
function nexora_github_http_headers() {
	$headers = array(
		'Accept'     => 'application/vnd.github+json',
		'User-Agent' => 'Nexora-Theme-Updater/' . ( defined( 'NEXORA_VERSION' ) ? NEXORA_VERSION : '1.0' ),
	);
	$token = nexora_github_token();
	if ( $token ) {
		$headers['Authorization'] = 'Bearer ' . $token;
	}
	return $headers;
}

/**
 * Latest release payload (cached).
 *
 * @return array<string,mixed>|null
 */
function nexora_github_latest_release() {
	$repo = nexora_github_repo();
	if ( ! $repo || false === strpos( $repo, '/' ) ) {
		return null;
	}

	$cache_key = 'nexora_gh_rel_' . md5( $repo );
	$cached    = get_site_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$url = 'https://api.github.com/repos/' . $repo . '/releases/latest';
	$res = wp_remote_get(
		$url,
		array(
			'timeout' => 15,
			'headers' => nexora_github_http_headers(),
		)
	);
	$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
	if ( is_wp_error( $res ) || 200 !== $code ) {
		// Cache misses briefly so Themes screen can retry soon.
		set_site_transient( $cache_key, array( '_empty' => 1, '_code' => $code ), 15 * MINUTE_IN_SECONDS );
		return null;
	}
	$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
	if ( ! is_array( $data ) || empty( $data['tag_name'] ) ) {
		set_site_transient( $cache_key, array( '_empty' => 1 ), 15 * MINUTE_IN_SECONDS );
		return null;
	}

	$version = ltrim( (string) $data['tag_name'], 'vV' );
	$zip     = '';
	if ( ! empty( $data['assets'] ) && is_array( $data['assets'] ) ) {
		foreach ( $data['assets'] as $asset ) {
			$name = isset( $asset['name'] ) ? (string) $asset['name'] : '';
			if ( ! nexora_is_theme_release_zip( $name ) ) {
				continue;
			}
			// Private repos: API asset URL + Accept: application/octet-stream (browser_download_url 404s).
			if ( ! empty( $asset['url'] ) ) {
				$zip = (string) $asset['url'];
			} elseif ( ! empty( $asset['browser_download_url'] ) ) {
				$zip = (string) $asset['browser_download_url'];
			}
			if ( $zip ) {
				break;
			}
		}
	}

	if ( ! $zip ) {
		set_site_transient( $cache_key, array( '_empty' => 1 ), 15 * MINUTE_IN_SECONDS );
		return null;
	}

	$payload = array(
		'version'   => $version,
		'zip'       => $zip,
		'url'       => isset( $data['html_url'] ) ? (string) $data['html_url'] : ( nexora_github_repo_url() . '/releases' ),
		'published' => isset( $data['published_at'] ) ? (string) $data['published_at'] : '',
		'notes'     => isset( $data['body'] ) ? (string) $data['body'] : '',
	);
	set_site_transient( $cache_key, $payload, 6 * HOUR_IN_SECONDS );
	return $payload;
}

/**
 * Inject GitHub release into theme update transient (Appearance → Themes).
 *
 * @param object $transient Update transient.
 * @return object
 */
function nexora_github_update_themes( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}

	$stylesheet = get_template();
	$current    = defined( 'NEXORA_VERSION' ) ? NEXORA_VERSION : '';
	if ( ! empty( $transient->checked ) && is_array( $transient->checked ) && ! empty( $transient->checked[ $stylesheet ] ) ) {
		$current = (string) $transient->checked[ $stylesheet ];
	}
	if ( ! $current ) {
		return $transient;
	}

	$release = nexora_github_latest_release();
	if ( ! $release || ! empty( $release['_empty'] ) || empty( $release['version'] ) || empty( $release['zip'] ) ) {
		return $transient;
	}

	if ( version_compare( $release['version'], $current, '<=' ) ) {
		return $transient;
	}

	$transient->response[ $stylesheet ] = array(
		'theme'        => $stylesheet,
		'new_version'  => $release['version'],
		'url'          => $release['url'],
		'package'      => $release['zip'],
		'requires'     => '6.0',
		'requires_php' => '7.4',
	);

	return $transient;
}
add_filter( 'pre_set_site_transient_update_themes', 'nexora_github_update_themes' );

/**
 * Theme details modal (View version X.Y.Z details).
 *
 * @param false|object|array $result  Result.
 * @param string             $action  Action.
 * @param object             $args    Args.
 * @return false|object|array
 */
function nexora_github_themes_api( $result, $action, $args ) {
	if ( 'theme_information' !== $action || empty( $args->slug ) ) {
		return $result;
	}
	if ( get_template() !== $args->slug && 'nexora' !== $args->slug ) {
		return $result;
	}

	$release = nexora_github_latest_release();
	$version = ( $release && empty( $release['_empty'] ) && ! empty( $release['version'] ) )
		? $release['version']
		: ( defined( 'NEXORA_VERSION' ) ? NEXORA_VERSION : '1.0.0' );
	$package = ( $release && ! empty( $release['zip'] ) ) ? $release['zip'] : '';

	$info                 = new stdClass();
	$info->name           = defined( 'NEXORA_THEME_NAME' ) ? NEXORA_THEME_NAME : 'Nexora';
	$info->slug           = 'nexora';
	$info->version        = $version;
	$info->author         = '<a href="https://nexorawp.github.io">Sanjay Paul</a>';
	$info->homepage       = nexora_github_repo_url();
	$info->download_link  = $package;
	$info->sections       = array(
		'description' => 'Universal premium magazine theme. Updates ship from GitHub Releases automatically.',
		'changelog'   => ( $release && ! empty( $release['notes'] ) ) ? $release['notes'] : 'See ' . nexora_github_repo_url() . '/releases',
	);
	$info->requires       = '6.0';
	$info->requires_php   = '7.4';
	return $info;
}
add_filter( 'themes_api', 'nexora_github_themes_api', 20, 3 );

/**
 * Clear cached release when checking updates in admin.
 */
function nexora_github_clear_cache() {
	$repo = nexora_github_repo();
	delete_site_transient( 'nexora_gh_rel_' . md5( $repo ) );
}
add_action( 'load-update-core.php', 'nexora_github_clear_cache' );
add_action( 'load-themes.php', 'nexora_github_clear_cache' );
add_action( 'load-update.php', 'nexora_github_clear_cache' );

/**
 * Live probe of GitHub Releases (no cache) for admin diagnostics.
 *
 * @return array<string,mixed>
 */
function nexora_github_probe() {
	$out = array(
		'token'     => (bool) nexora_github_token(),
		'repo'      => nexora_github_repo(),
		'installed' => defined( 'NEXORA_VERSION' ) ? NEXORA_VERSION : '',
		'code'      => 0,
		'version'   => '',
		'zip'       => false,
		'message'   => '',
		'update'    => false,
	);

	if ( ! $out['token'] ) {
		$out['message'] = __( 'No GitHub token — paste one under Appearance → Nexora → Advanced, or define NEXORA_GITHUB_TOKEN in wp-config.php.', 'nexora' );
		return $out;
	}

	nexora_github_clear_cache();
	$url = 'https://api.github.com/repos/' . $out['repo'] . '/releases/latest';
	$res = wp_remote_get(
		$url,
		array(
			'timeout' => 15,
			'headers' => nexora_github_http_headers(),
		)
	);

	if ( is_wp_error( $res ) ) {
		$out['message'] = $res->get_error_message();
		return $out;
	}

	$out['code'] = (int) wp_remote_retrieve_response_code( $res );
	$body        = (string) wp_remote_retrieve_body( $res );
	if ( 200 !== $out['code'] ) {
		if ( 401 === $out['code'] || 403 === $out['code'] ) {
			$out['message'] = __( 'Token rejected. Revoke and create a new fine-grained token with Contents: Read on nexora.', 'nexora' );
		} elseif ( 404 === $out['code'] ) {
			$out['message'] = __( '404 — token cannot see the private repo, or no Releases exist yet. Check token repo access + Actions release zip.', 'nexora' );
		} else {
			$out['message'] = sprintf(
				/* translators: %d: HTTP status */
				__( 'GitHub API HTTP %d.', 'nexora' ),
				$out['code']
			);
		}
		return $out;
	}

	$data = json_decode( $body, true );
	if ( ! is_array( $data ) || empty( $data['tag_name'] ) ) {
		$out['message'] = __( 'Release response was empty.', 'nexora' );
		return $out;
	}

	$out['version'] = ltrim( (string) $data['tag_name'], 'vV' );
	if ( ! empty( $data['assets'] ) && is_array( $data['assets'] ) ) {
		foreach ( $data['assets'] as $asset ) {
			$name = isset( $asset['name'] ) ? (string) $asset['name'] : '';
			if ( nexora_is_theme_release_zip( $name ) ) {
				$out['zip'] = true;
				break;
			}
		}
	}

	if ( ! $out['zip'] ) {
		$out['message'] = __( 'Release found but no nexora-*.zip (or legacy paulworld-*.zip) asset. Open GitHub → Actions and fix the Release workflow.', 'nexora' );
		return $out;
	}

	$out['update'] = version_compare( $out['version'], $out['installed'], '>' );
	if ( $out['update'] ) {
		$out['message'] = sprintf(
			/* translators: 1: installed version, 2: release version */
			__( 'Update available: %1$s → %2$s. Open Appearance → Themes.', 'nexora' ),
			$out['installed'],
			$out['version']
		);
		delete_site_transient( 'update_themes' );
	} else {
		$out['message'] = sprintf(
			/* translators: 1: installed, 2: github */
			__( 'Installed %1$s matches GitHub %2$s — no Update button (already current).', 'nexora' ),
			$out['installed'],
			$out['version']
		);
	}

	return $out;
}

/**
 * Admin: force update check.
 */
function nexora_handle_github_check() {
	if ( ! current_user_can( 'update_themes' ) && ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Forbidden', 'nexora' ) );
	}
	check_admin_referer( 'nexora_github_check' );
	$probe = nexora_github_probe();
	set_transient( 'nexora_github_probe', $probe, 5 * MINUTE_IN_SECONDS );
	$page = function_exists( 'nexora_settings_page_slug' ) ? nexora_settings_page_slug() : 'nexora';
	wp_safe_redirect( admin_url( 'themes.php?page=' . $page . '&tab=advanced&nexora_gh=1' ) );
	exit;
}
add_action( 'admin_post_nexora_github_check', 'nexora_handle_github_check' );

/**
 * Attach GitHub token when WordPress downloads private release zips / API.
 *
 * @param array  $args Request args.
 * @param string $url  URL.
 * @return array
 */
function nexora_github_http_request_args( $args, $url ) {
	$token = nexora_github_token();
	if ( ! $token ) {
		return $args;
	}
	if ( ! is_string( $url ) || '' === $url ) {
		return $args;
	}

	$repo = nexora_github_repo();
	$host = wp_parse_url( $url, PHP_URL_HOST );
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );

	$ok = false;
	if ( in_array( $host, array( 'api.github.com', 'github.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com' ), true ) ) {
		if (
			false !== strpos( $url, $repo ) ||
			false !== strpos( $path, '/paulworld-' ) ||
			false !== strpos( $path, '/nexora-' ) ||
			'objects.githubusercontent.com' === $host ||
			'release-assets.githubusercontent.com' === $host
		) {
			$ok = true;
		}
	}
	if ( ! $ok ) {
		return $args;
	}

	if ( ! isset( $args['headers'] ) || ! is_array( $args['headers'] ) ) {
		$args['headers'] = array();
	}
	$args['headers']['Authorization'] = 'Bearer ' . $token;
	if ( empty( $args['headers']['User-Agent'] ) ) {
		$args['headers']['User-Agent'] = 'Nexora-Theme-Updater';
	}
	// Required for private release asset downloads via the API.
	if ( false !== strpos( $path, '/releases/assets/' ) ) {
		$args['headers']['Accept'] = 'application/octet-stream';
		$args['redirection']       = 5;
		$args['timeout']           = 60;
	}
	return $args;
}
add_filter( 'http_request_args', 'nexora_github_http_request_args', 10, 2 );

/**
 * Download private GitHub release zip ourselves (avoids WP “Download failed. Not Found”).
 *
 * @param bool        $reply    Short-circuit value.
 * @param string      $package  Package URL.
 * @param WP_Upgrader $upgrader Upgrader.
 * @return bool|string|WP_Error
 */
function nexora_github_upgrader_pre_download( $reply, $package, $upgrader ) {
	unset( $upgrader );
	if ( ! is_string( $package ) || '' === $package ) {
		return $reply;
	}
	if ( ! nexora_github_token() ) {
		return $reply;
	}
	$is_api_asset = ( false !== strpos( $package, 'api.github.com' ) && false !== strpos( $package, '/releases/assets/' ) );
	$is_gh_zip    = (
		false !== strpos( $package, 'github.com/' . nexora_github_repo() ) &&
		( false !== strpos( $package, '/paulworld-' ) || false !== strpos( $package, '/nexora-' ) )
	);
	if ( ! $is_api_asset && ! $is_gh_zip ) {
		return $reply;
	}

	$headers = nexora_github_http_headers();
	if ( $is_api_asset ) {
		$headers['Accept'] = 'application/octet-stream';
	}

	$res = wp_remote_get(
		$package,
		array(
			'timeout'     => 60,
			'redirection' => 5,
			'headers'     => $headers,
		)
	);
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$code = (int) wp_remote_retrieve_response_code( $res );
	if ( 200 !== $code ) {
		return new WP_Error(
			'nexora_github_download',
			sprintf(
				/* translators: %d: HTTP status */
				__( 'GitHub zip download failed (HTTP %d). Confirm the release has nexora-*.zip and the token can read Contents.', 'nexora' ),
				$code
			)
		);
	}
	$body = wp_remote_retrieve_body( $res );
	if ( ! is_string( $body ) || '' === $body ) {
		return new WP_Error( 'nexora_github_download', __( 'GitHub returned an empty zip.', 'nexora' ) );
	}
	$tmp = wp_tempnam( 'nexora-update.zip' );
	if ( ! $tmp ) {
		return new WP_Error( 'nexora_github_download', __( 'Could not create a temp file for the update.', 'nexora' ) );
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	if ( false === file_put_contents( $tmp, $body ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return new WP_Error( 'nexora_github_download', __( 'Could not write the update zip.', 'nexora' ) );
	}

	return $tmp;
}
add_filter( 'upgrader_pre_download', 'nexora_github_upgrader_pre_download', 10, 3 );
