<?php
/**
 * Magazine homepage helpers + live search API.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Query posts ordered by view score.
 *
 * @param int    $count   How many.
 * @param int[]  $exclude IDs to skip.
 * @param string $order   DESC|ASC.
 * @return WP_Post[]
 */
function nexora_posts_by_views( $count, $exclude = array(), $order = 'DESC' ) {
	nexora_maybe_seed_post_views();
	$count   = max( 0, (int) $count );
	$exclude = array_values( array_unique( array_filter( array_map( 'intval', (array) $exclude ) ) ) );
	if ( $count < 1 ) {
		return array();
	}
	$order = ( 'ASC' === strtoupper( $order ) ) ? 'ASC' : 'DESC';

	$q = new WP_Query(
		array(
			'posts_per_page'      => $count,
			'post_status'         => 'publish',
			'post__not_in'        => $exclude,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'meta_key'            => nexora_views_meta_key(),
			'orderby'             => array(
				'meta_value_num' => $order,
				'date'           => 'DESC',
			),
		)
	);
	return $q->posts;
}

/**
 * Unified homepage waterfall (page 1, unfiltered).
 *
 * Selection order (unique IDs across curated bands):
 * 1. Latest (1) — sticky if set, else newest date
 * 2. Top Reads (6) — next highest `_pw_post_views`
 * 3. Most Popular (3) — next highest views (mid-column ads)
 * 4. Explore More Topics (2) — remaining; one per category; lowest views
 * 5. All Articles — full newest-first library (does not exclude 1–4)
 *
 * @return array{latest:?WP_Post,top:WP_Post[],popular:WP_Post[],explore:WP_Post[]}
 */
function nexora_home_content_pack() {
	static $pack = null;
	if ( null !== $pack ) {
		return $pack;
	}

	nexora_maybe_seed_post_views();
	$used   = array();
	$latest = null;

	$sticky = get_option( 'sticky_posts' );
	if ( is_array( $sticky ) && $sticky ) {
		$q = new WP_Query(
			array(
				'post__in'            => array_slice( array_map( 'intval', $sticky ), 0, 1 ),
				'posts_per_page'      => 1,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);
		if ( $q->have_posts() ) {
			$latest = $q->posts[0];
		}
	}
	if ( ! $latest ) {
		$q = new WP_Query(
			array(
				'posts_per_page'      => 1,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'orderby'             => 'date',
				'order'               => 'DESC',
			)
		);
		if ( $q->have_posts() ) {
			$latest = $q->posts[0];
		}
	}
	if ( $latest ) {
		$used[] = (int) $latest->ID;
	}

	// Top Reads: next 6 by views.
	$top = nexora_posts_by_views( 6, $used, 'DESC' );
	foreach ( $top as $p ) {
		$used[] = (int) $p->ID;
	}

	// Most Popular display: 3 posts (middle column reserved for ads).
	// Keep room for Explore (2): with a ~12-post library, 1+6+4 left only 1 unused.
	$popular = nexora_posts_by_views( 3, $used, 'DESC' );
	foreach ( $popular as $p ) {
		$used[] = (int) $p->ID;
	}

	// Explore: 2 less-read, one per category, from remaining only.
	$explore = nexora_explore_topic_posts( 2, $used );

	$pack = array(
		'latest'  => $latest,
		'top'     => $top,
		'popular' => $popular,
		'explore' => $explore,
	);
	return $pack;
}

/**
 * Post view meta key.
 */
function nexora_views_meta_key() {
	return '_pw_post_views';
}

/**
 * Increment views on single posts (skip previews / editors).
 */
function nexora_track_post_views() {
	if ( is_admin() || ! is_singular( 'post' ) || is_preview() ) {
		return;
	}
	if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
		return;
	}
	$post_id = (int) get_queried_object_id();
	if ( $post_id < 1 ) {
		return;
	}
	$key   = nexora_views_meta_key();
	$views = (int) get_post_meta( $post_id, $key, true );
	update_post_meta( $post_id, $key, $views + 1 );
}
add_action( 'template_redirect', 'nexora_track_post_views', 20 );

/**
 * Soft seed so popular/explore have distinct scores before real traffic accumulates.
 * Re-runs when version bumps (safe: only fills empty meta).
 */
function nexora_maybe_seed_post_views() {
	if ( nexora_option_with_legacy( 'nexora_views_seeded_v2', 'paulworld_views_seeded_v2', false ) ) {
		return;
	}
	$posts = get_posts(
		array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
		)
	);
	$total = count( $posts );
	foreach ( $posts as $i => $pid ) {
		$pid = (int) $pid;
		// Spread scores so top/bottom sets never collide when the library is small.
		$score = max( 1, ( $total - $i ) * 17 + ( ( $i * 3 ) % 11 ) );
		update_post_meta( $pid, nexora_views_meta_key(), $score );
	}
	update_option( 'nexora_views_seeded_v2', 1, false );
}

/**
 * Discovery posts: one less-read guide per topic, never overlapping used IDs.
 *
 * @param int   $count   How many (typically 2).
 * @param int[] $exclude IDs to skip.
 * @return WP_Post[]
 */
function nexora_explore_topic_posts( $count = 2, $exclude = array() ) {
	nexora_maybe_seed_post_views();
	$count   = max( 1, min( 4, (int) $count ) );
	$exclude = array_values( array_unique( array_filter( array_map( 'intval', (array) $exclude ) ) ) );
	$picked  = array();
	$used    = $exclude;

	$cats = function_exists( 'nexora_blog_categories' ) ? nexora_blog_categories() : array();
	foreach ( $cats as $cat ) {
		if ( count( $picked ) >= $count ) {
			break;
		}
		if ( ! $cat instanceof WP_Term ) {
			continue;
		}
		$q = new WP_Query(
			array(
				'posts_per_page'      => 1,
				'post_status'         => 'publish',
				'cat'                 => (int) $cat->term_id,
				'post__not_in'        => $used,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'meta_key'            => nexora_views_meta_key(),
				'orderby'             => array(
					'meta_value_num' => 'ASC',
					'date'           => 'DESC',
				),
			)
		);
		if ( empty( $q->posts[0] ) ) {
			continue;
		}
		$post     = $q->posts[0];
		$picked[] = $post;
		$used[]   = (int) $post->ID;
	}

	if ( count( $picked ) < $count ) {
		$fill = nexora_posts_by_views( $count - count( $picked ), $used, 'ASC' );
		foreach ( $fill as $post ) {
			$id = (int) $post->ID;
			if ( in_array( $id, $used, true ) ) {
				continue;
			}
			$picked[] = $post;
			$used[]   = $id;
			if ( count( $picked ) >= $count ) {
				break;
			}
		}
	}

	return $picked;
}

/**
 * Echo a middle-column ad cell when the between_cards placement is live.
 *
 * @return bool Whether an ad cell was printed.
 */
function nexora_magazine_grid_ad_cell() {
	if ( ! function_exists( 'nexora_render_ad_placement' ) ) {
		return false;
	}
	$ad_html = (string) nexora_render_ad_placement( 'between_cards' );
	if ( '' === trim( $ad_html ) ) {
		return false;
	}
	echo '<div class="nexora-magazine__cell nexora-magazine__cell--ad">';
	echo $ad_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ad HTML from admin/unit builder.
	echo '</div>';
	return true;
}

/**
 * Render the main query as a 3-col magazine grid with middle-column ads.
 * Rhythm: post | ad | post (repeats) so ads sit in the center column at ≥1200px.
 */
function nexora_magazine_loop_with_ads() {
	if ( ! have_posts() ) {
		get_template_part( 'template-parts/content', 'none' );
		return;
	}
	echo '<div class="nexora-magazine__grid nexora-magazine__grid--ads">';
	$n = 0;
	while ( have_posts() ) {
		the_post();
		++$n;
		echo '<div class="nexora-magazine__cell">';
		get_template_part( 'template-parts/content', 'post' );
		echo '</div>';
		// After 1st, 3rd, 5th… post → insert ad so row is post | ad | post.
		if ( 1 === ( $n % 2 ) ) {
			nexora_magazine_grid_ad_cell();
		}
	}
	echo '</div>';
}

/**
 * Homepage: Most Popular Posts — 3 cards + middle-column ad slots.
 *
 * @param WP_Post[]|null $posts Optional pack posts.
 */
function nexora_home_popular_posts( $posts = null ) {
	if ( null === $posts ) {
		$pack  = nexora_home_content_pack();
		$posts = $pack['popular'];
	}
	if ( ! $posts ) {
		return;
	}
	?>
	<section class="nexora-popular" aria-labelledby="nexora-popular-title">
		<header class="nexora-popular__head">
			<h2 id="nexora-popular-title" class="nexora-popular__title"><?php esc_html_e( 'Most Popular Posts', 'nexora' ); ?></h2>
		</header>
		<div class="nexora-magazine__grid nexora-magazine__grid--popular nexora-magazine__grid--ads">
			<?php
			global $post;
			$queue = array_values( $posts );
			$n     = 0;
			while ( $queue ) {
				$post = array_shift( $queue ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				setup_postdata( $post );
				++$n;
				?>
				<div class="nexora-magazine__cell">
					<?php get_template_part( 'template-parts/content', 'post' ); ?>
				</div>
				<?php
				if ( 1 === ( $n % 2 ) ) {
					nexora_magazine_grid_ad_cell();
				}
			}
			wp_reset_postdata();
			?>
		</div>
	</section>
	<?php
}

/**
 * Homepage: Explore more topics (wide + narrow image cards).
 *
 * @param WP_Post[]|null $posts Optional pack posts.
 */
function nexora_home_explore_topics( $posts = null ) {
	if ( null === $posts ) {
		$pack  = nexora_home_content_pack();
		$posts = $pack['explore'];
	}
	if ( count( (array) $posts ) < 1 ) {
		return;
	}
	?>
	<section class="nexora-explore" aria-labelledby="nexora-explore-title">
		<div class="nexora-wrap">
			<header class="nexora-explore__head">
				<h2 id="nexora-explore-title" class="nexora-explore__title"><?php esc_html_e( 'Explore More Topics', 'nexora' ); ?></h2>
			</header>
			<div class="nexora-explore__grid">
				<?php
				global $post;
				$seen = array();
				foreach ( $posts as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					$id = (int) $post->ID;
					if ( isset( $seen[ $id ] ) ) {
						continue;
					}
					$seen[ $id ] = true;
					$card_index  = count( $seen );
					setup_postdata( $post );
					$mod     = ( 1 === $card_index ) ? 'nexora-explore__card--wide' : 'nexora-explore__card--narrow';
					$excerpt = get_the_excerpt( $post );
					$excerpt = $excerpt ? wp_trim_words( wp_strip_all_tags( $excerpt ), 14, '…' ) : '';
					$cats    = get_the_category( $id );
					$cat     = null;
					foreach ( (array) $cats as $c ) {
						if ( $c && 'uncategorized' !== $c->slug ) {
							$cat = $c;
							break;
						}
					}
					?>
					<a class="nexora-explore__card <?php echo esc_attr( $mod ); ?>" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
						<span class="nexora-explore__media" aria-hidden="true">
							<?php if ( has_post_thumbnail( $post ) ) : ?>
								<?php
								echo get_the_post_thumbnail(
									$post,
									( 1 === $card_index ) ? 'nexora-wide' : 'nexora-mid',
									nexora_post_thumbnail_attrs(
										$post,
										array(
											'loading'            => 'lazy',
											'decoding'           => 'async',
											'class'              => 'nexora-explore__img',
											'data-nexora-decorative' => '1',
										)
									)
								);
								?>
							<?php else : ?>
								<span class="nexora-explore__fallback"></span>
							<?php endif; ?>
						</span>
						<span class="nexora-explore__shade" aria-hidden="true"></span>
						<span class="nexora-explore__copy">
							<?php if ( $cat ) : ?>
								<span class="nexora-explore__kicker"><?php echo esc_html( $cat->name ); ?></span>
							<?php endif; ?>
							<span class="nexora-explore__card-title"><?php echo esc_html( get_the_title( $post ) ); ?></span>
							<?php if ( $excerpt ) : ?>
								<span class="nexora-explore__card-lede"><?php echo esc_html( $excerpt ); ?></span>
							<?php endif; ?>
						</span>
						<?php if ( 1 !== $card_index ) : ?>
							<span class="nexora-explore__arrow" aria-hidden="true">
								<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</span>
						<?php endif; ?>
					</a>
					<?php
				}
				wp_reset_postdata();
				?>
			</div>
		</div>
	</section>
	<?php
}

/**
 * Legacy no-op — illustrated newsletter band removed (niche-unfriendly).
 * Signup lives in the footer via nexora_footer_newsletter().
 *
 * @param string $variant Ignored.
 */
function nexora_newsletter_band( $variant = 'full' ) {
	unset( $variant );
}

/**
 * Compact newsletter signup for the site footer (no illustration — niche-safe).
 */
function nexora_footer_newsletter() {
	$contact = nexora_page_url( 'contact' );
	?>
	<div class="nexora-footer__col nexora-footer__col--news" aria-labelledby="nexora-footer-news-title">
		<p class="nexora-footer__label" id="nexora-footer-news-title"><?php echo esc_html( nexora_newsletter_eyebrow() ); ?></p>
		<p class="nexora-footer__news-lede"><?php echo esc_html( nexora_newsletter_lede() ); ?></p>
		<form class="nexora-footer__news-form" method="get" action="<?php echo esc_url( $contact ); ?>">
			<input type="hidden" name="nexora_subject" value="<?php echo esc_attr__( 'Newsletter signup', 'nexora' ); ?>">
			<label class="nexora-visually-hidden" for="nexora-footer-news-email"><?php esc_html_e( 'Email', 'nexora' ); ?></label>
			<input id="nexora-footer-news-email" class="nexora-footer__news-input" type="email" name="nexora_email" required placeholder="<?php esc_attr_e( 'Your email', 'nexora' ); ?>" autocomplete="email" inputmode="email">
			<button class="nexora-btn nexora-btn--primary nexora-footer__news-btn" type="submit"><?php esc_html_e( 'Subscribe', 'nexora' ); ?></button>
		</form>
	</div>
	<?php
}

/**
 * Live search REST (title-weighted ranking).
 */
function nexora_register_search_rest() {
	register_rest_route(
		'nexora/v1',
		'/search',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'args'                => array(
				'q' => array(
					'required'          => true,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
			'callback'            => 'nexora_rest_search',
		)
	);
}
add_action( 'rest_api_init', 'nexora_register_search_rest' );

/**
 * Search callback.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function nexora_rest_search( $request ) {
	$q = trim( (string) $request->get_param( 'q' ) );
	if ( strlen( $q ) < 2 ) {
		return rest_ensure_response( array() );
	}

	$query = new WP_Query(
		array(
			's'              => $q,
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 8,
			'no_found_rows'  => true,
		)
	);

	$items = array();
	foreach ( $query->posts as $post ) {
		$score = 0;
		$title = get_the_title( $post );
		if ( false !== stripos( $title, $q ) ) {
			$score += 10;
		}
		if ( 0 === stripos( $title, $q ) ) {
			$score += 5;
		}
		$thumb = get_the_post_thumbnail_url( $post, 'medium_large' );
		$items[] = array(
			'id'        => (int) $post->ID,
			'title'     => $title,
			'url'       => get_permalink( $post ),
			'excerpt'   => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), 18 ),
			'date'      => get_the_date( '', $post ),
			'thumbnail' => $thumb ? $thumb : '',
			'score'     => $score,
		);
	}

	usort(
		$items,
		static function ( $a, $b ) {
			return $b['score'] <=> $a['score'];
		}
	);

	return rest_ensure_response( $items );
}

/**
 * Prefer title matches on the main search query.
 *
 * @param string   $orderby Orderby SQL.
 * @param WP_Query $query   Query.
 * @return string
 */
function nexora_search_title_orderby( $orderby, $query ) {
	global $wpdb;
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
		return $orderby;
	}
	$s = $query->get( 's' );
	if ( ! $s ) {
		return $orderby;
	}
	$like = '%' . $wpdb->esc_like( $s ) . '%';
	return $wpdb->prepare( "CASE WHEN {$wpdb->posts}.post_title LIKE %s THEN 0 ELSE 1 END, {$wpdb->posts}.post_date DESC", $like );
}
add_filter( 'posts_orderby', 'nexora_search_title_orderby', 10, 2 );
