<?php
/**
 * Shared theme option helpers (theme_mods with defaults).
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default option map.
 *
 * @return array<string,mixed>
 */
function nexora_option_defaults() {
	return array(
		'niche_preset'             => 'automotive',
		'developer_contact_url'    => '',
		'home_h1'                  => '',
		'home_lede'                => '',
		'newsletter_eyebrow'       => 'Stay in the loop',
		'preloader_enabled'        => false,
		'ga4_measurement_id'       => '',
		'gsc_verification'         => '',
		'bing_verification'        => '',
		'article_reading_time'     => true,
		'article_meta_author'      => true,
		'article_meta_date'        => true,
		'article_toc'              => true,
		'article_author_box'       => false,
		'article_breadcrumbs'      => false,
		'article_updated_date'     => true,
		'ads_enabled'              => true,
		'adsense_client'           => '',
		'adsense_auto_ads'         => true,
		'adsense_in_article'       => true,
		'adsense_slot_in_article'  => '',
		'adsense_in_article_after' => 2,
		'ad_placements'            => array(),
		'ads_exclude_categories'   => array(),
		'amazon_tracking_id'       => '',
		'amazon_marketplace'       => 'www.amazon.com',
		'affiliate_disclosure'     => '',
		'cookie_banner'            => true,
		'privacy_policy_url'       => '',
		'cookie_policy_url'        => '',
		'aff_track_clicks'         => true,
		'adsense_manual_revenue'   => '',
		'adsense_manual_rpm'       => '',
		'adsense_manual_note'      => '',
	);
}

/**
 * Homepage hero H1 (empty = automotive default string for new installs).
 *
 * @return string
 */
function nexora_home_h1() {
	$custom = trim( (string) nexora_get_option( 'home_h1' ) );
	if ( '' !== $custom ) {
		return $custom;
	}
	return __( 'Car Maintenance, DIY Auto Repair & Mechanic Guides', 'nexora' );
}

/**
 * Homepage hero lede.
 *
 * @return string
 */
function nexora_home_lede() {
	$custom = trim( (string) nexora_get_option( 'home_lede' ) );
	if ( '' !== $custom ) {
		return $custom;
	}
	return __( 'Explore practical automotive knowledge, beginner-friendly mechanic tutorials, DIY car maintenance, automotive painting, garage care, and mechanic education. Find clear answers to everyday car questions.', 'nexora' );
}

/**
 * Newsletter eyebrow (default: “Stay in the loop”).
 *
 * @return string
 */
function nexora_newsletter_eyebrow() {
	$default = __( 'Stay in the loop', 'nexora' );
	$custom  = trim( (string) nexora_get_option( 'newsletter_eyebrow' ) );
	if ( '' === $custom || 'Stay in the loop' === $custom ) {
		return $default;
	}
	return $custom;
}

/**
 * Get a theme option with default.
 *
 * @param string $key Option key.
 * @return mixed
 */
function nexora_get_option( $key ) {
	$defaults = nexora_option_defaults();
	$default  = array_key_exists( $key, $defaults ) ? $defaults[ $key ] : '';
	return get_theme_mod( $key, $default );
}

/**
 * Whether ads may load (global + publisher).
 *
 * @return bool
 */
function nexora_ads_allowed() {
	if ( ! nexora_get_option( 'ads_enabled' ) ) {
		return false;
	}
	$client = (string) nexora_get_option( 'adsense_client' );
	if ( ! preg_match( '/^ca-pub-\d+$/', trim( $client ) ) ) {
		return false;
	}
	return true;
}

/**
 * Default ad placement definitions.
 *
 * @return array<string,array<string,mixed>>
 */
function nexora_ad_placement_defs() {
	$keys = array(
		'below_nav'             => __( 'Below navigation', 'nexora' ),
		'hero_left'             => __( 'Article hero — left ad column', 'nexora' ),
		'hero_right'            => __( 'Article hero — right ad column', 'nexora' ),
		'below_title'           => __( 'Below article title (center)', 'nexora' ),
		'after_image'           => __( 'After featured image', 'nexora' ),
		'rail_before_toc'       => __( 'Left rail — before table of contents', 'nexora' ),
		'rail_after_toc'        => __( 'Left rail — after table of contents', 'nexora' ),
		'rail_after_newsletter' => __( 'Left rail — after newsletter', 'nexora' ),
		'rail_right_top'        => __( 'Right rail — top', 'nexora' ),
		'rail_right_bottom'     => __( 'Right rail — bottom', 'nexora' ),
		'before_content'        => __( 'Before article content', 'nexora' ),
		'after_p2'              => __( 'After paragraph 2', 'nexora' ),
		'after_p4'              => __( 'After paragraph 4', 'nexora' ),
		'end_content'           => __( 'End of article', 'nexora' ),
		'between_cards'         => __( 'Post grids — middle column (Popular & All Articles)', 'nexora' ),
		'footer'                => __( 'Above footer', 'nexora' ),
	);
	$out = array();
	foreach ( $keys as $key => $label ) {
		$out[ $key ] = array(
			'label'   => $label,
			/* after_p2 + between_cards on by default so grids are ad-ready */
			'enabled' => ( 'after_p2' === $key || 'between_cards' === $key ),
			'desktop' => true,
			'mobile'  => true,
			'code'    => '',
			'slot'    => '',
		);
	}
	return $out;
}

/**
 * Merged ad placements.
 *
 * @return array<string,array<string,mixed>>
 */
function nexora_ad_placements() {
	$defs  = nexora_ad_placement_defs();
	$saved = nexora_get_option( 'ad_placements' );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	foreach ( $defs as $key => $row ) {
		if ( isset( $saved[ $key ] ) && is_array( $saved[ $key ] ) ) {
			$defs[ $key ] = array_merge(
				$row,
				array(
					'enabled' => ! empty( $saved[ $key ]['enabled'] ),
					'desktop' => ! isset( $saved[ $key ]['desktop'] ) || ! empty( $saved[ $key ]['desktop'] ),
					'mobile'  => ! isset( $saved[ $key ]['mobile'] ) || ! empty( $saved[ $key ]['mobile'] ),
					'code'    => isset( $saved[ $key ]['code'] ) ? (string) $saved[ $key ]['code'] : '',
					'slot'    => isset( $saved[ $key ]['slot'] ) ? preg_replace( '/\D+/', '', (string) $saved[ $key ]['slot'] ) : '',
				)
			);
		}
	}
	return $defs;
}

/**
 * Whether current request device matches placement rules.
 *
 * @param array $row Placement row.
 * @return bool
 */
function nexora_ad_device_ok( $row ) {
	$is_mobile = wp_is_mobile();
	if ( $is_mobile && empty( $row['mobile'] ) ) {
		return false;
	}
	if ( ! $is_mobile && empty( $row['desktop'] ) ) {
		return false;
	}
	return true;
}
