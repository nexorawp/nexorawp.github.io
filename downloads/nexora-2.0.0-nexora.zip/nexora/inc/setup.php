<?php
/**
 * Theme supports, menus, and shared helpers.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme logo / icon asset URL.
 *
 * @param string $size One of svg|112|512|1200.
 * @return string
 */
function nexora_mark_url( $size = 'svg' ) {
	$map = array(
		'svg'  => 'logo-mark.svg',
		'112'  => 'logo-mark-112.png',
		'512'  => 'logo-mark-512.png',
		'1200' => 'logo-mark-1200.png',
	);
	$file = isset( $map[ $size ] ) ? $map[ $size ] : $map['svg'];
	$path = NEXORA_DIR . '/assets/img/' . $file;
	if ( ! file_exists( $path ) ) {
		$file = 'logo-mark.svg';
	}
	return NEXORA_URI . '/assets/img/' . $file;
}

/**
 * Default Open Graph share image (1200×675 brand card).
 * Used when a page/post has no featured image.
 *
 * @return string Absolute URL, or empty if the asset is missing.
 */
function nexora_default_og_image_url() {
	$file = 'og-site-1200x675.png';
	$path = NEXORA_DIR . '/assets/img/' . $file;
	if ( ! file_exists( $path ) ) {
		return '';
	}
	return NEXORA_URI . '/assets/img/' . $file;
}

/**
 * Attachment alt text with optional fallback (never returns null).
 *
 * @param int    $attachment_id Attachment ID.
 * @param string $fallback      Used when media alt is empty.
 * @return string
 */
function nexora_attachment_alt( $attachment_id, $fallback = '' ) {
	$attachment_id = (int) $attachment_id;
	$alt           = '';
	if ( $attachment_id > 0 ) {
		$alt = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
	}
	if ( '' !== $alt ) {
		return $alt;
	}
	$fallback = trim( (string) $fallback );
	if ( '' !== $fallback ) {
		return $fallback;
	}
	if ( $attachment_id > 0 ) {
		$title = trim( (string) get_the_title( $attachment_id ) );
		if ( '' !== $title ) {
			return $title;
		}
	}
	return '';
}

/**
 * Attrs for a post thumbnail. Informative images fall back to the post title.
 * Pass `'data-nexora-decorative' => '1'` for thumbs inside aria-hidden media links
 * (forces empty alt; marker is stripped before HTML output).
 *
 * @param int|WP_Post|null     $post  Post.
 * @param array<string,string> $extra Extra img attributes.
 * @return array<string,string>
 */
function nexora_post_thumbnail_attrs( $post = null, $extra = array() ) {
	$post  = get_post( $post );
	$extra = is_array( $extra ) ? $extra : array();
	if ( ! empty( $extra['data-nexora-decorative'] ) ) {
		$extra['alt'] = '';
		return $extra;
	}
	if ( array_key_exists( 'alt', $extra ) && '' !== trim( (string) $extra['alt'] ) ) {
		return $extra;
	}
	$thumb_id     = $post ? (int) get_post_thumbnail_id( $post ) : 0;
	$fallback     = $post ? (string) get_the_title( $post ) : '';
	$extra['alt'] = nexora_attachment_alt( $thumb_id, $fallback );
	return $extra;
}

/**
 * Dual-tone wordmark: Paul (dark teal) + World (light teal).
 */
function nexora_logo_wordmark() {
	?>
	<span class="nexora-logo__mark">
		<span class="nexora-logo__mark-dark"><?php esc_html_e( 'Paul', 'nexora' ); ?></span>
		<span class="nexora-logo__mark-light"><?php esc_html_e( 'World', 'nexora' ); ?></span>
	</span>
	<?php
}

/**
 * Absolute filesystem path for a logo asset.
 *
 * @param string $size Size key.
 * @return string
 */
function nexora_mark_path( $size = '512' ) {
	$map = array(
		'svg'  => 'logo-mark.svg',
		'112'  => 'logo-mark-112.png',
		'512'  => 'logo-mark-512.png',
		'1200' => 'logo-mark-1200.png',
	);
	$file = isset( $map[ $size ] ) ? $map[ $size ] : $map['512'];
	return NEXORA_DIR . '/assets/img/' . $file;
}

/**
 * Import the theme globe as the Site Icon when none is set.
 */
function nexora_ensure_site_icon() {
	if ( (int) get_option( 'site_icon' ) > 0 ) {
		return;
	}
	$path = nexora_mark_path( '512' );
	if ( ! file_exists( $path ) || ! function_exists( 'media_handle_sideload' ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$tmp = wp_tempnam( 'nexora-site-icon.png' );
	if ( ! $tmp || ! copy( $path, $tmp ) ) {
		return;
	}
	$file = array(
		'name'     => 'nexora-logo-mark-512.png',
		'type'     => 'image/png',
		'tmp_name' => $tmp,
		'error'    => 0,
		'size'     => filesize( $tmp ),
	);
	$id = media_handle_sideload( $file, 0, defined( 'NEXORA_THEME_NAME' ) ? ( NEXORA_THEME_NAME . ' logo' ) : 'Nexora logo' );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return;
	}
	update_option( 'site_icon', (int) $id );
}

/**
 * Default affiliate + ads disclosure (footer). Full detail lives on Disclosure / Privacy.
 *
 * @return string
 */
function nexora_default_disclosure() {
	$name = get_bloginfo( 'name', 'display' );
	if ( ! $name ) {
		$name = 'This site';
	}
	return sprintf(
		/* translators: %s: site name */
		__( '%s is reader-supported. We may earn from affiliate links and show ads at no extra cost to you. See Disclosure and Privacy.', 'nexora' ),
		$name
	);
}

/**
 * Refresh footer disclosure when it still matches a retired default.
 */
function nexora_maybe_refresh_disclosure() {
	$current = (string) get_theme_mod( 'footer_disclosure', '' );
	$retired = array(
		'If you buy through a link in a review, Paul World may earn a commission. It does not raise the price you pay.',
		'Paul World is reader-supported. If you buy through our links, we may earn a commission at no extra cost to you.',
		'Paul World is reader-supported. Guides may include affiliate links — we may earn a commission at no extra cost to you. We may also show ads (including Google AdSense). Ad partners may use cookies or similar tech as described in our Privacy Policy.',
		'Paul World is reader-supported. Reviews may include affiliate links — we may earn a commission at no extra cost to you. We may also show ads (including Google AdSense). Ad partners may use cookies or similar tech as described in our Privacy Policy.',
		'Paul World is reader-supported. Affiliate links and ads may appear — see Disclosure and Privacy.',
		'Reader-supported. Affiliate links and ads may appear — see Disclosure and Privacy.',
		'Paul World is reader-supported. We may earn from affiliate links and show ads. See our Disclosure and Privacy policies.',
	);
	if ( '' === $current || in_array( $current, $retired, true ) ) {
		set_theme_mod( 'footer_disclosure', nexora_default_disclosure() );
	}
}
add_action( 'after_setup_theme', 'nexora_maybe_refresh_disclosure', 20 );

/**
 * Default primary CTA / affiliate click URL.
 *
 * @return string
 */
function nexora_default_affiliate_url() {
	return NEXORA_DEFAULT_AFFILIATE_URL;
}

/**
 * Escaped primary CTA / affiliate URL from Customizer.
 *
 * @return string
 */
function nexora_affiliate_url() {
	$url = trim( (string) get_theme_mod( 'ghl_affiliate_url', '' ) );
	if ( ! $url || '#' === $url ) {
		$url = nexora_default_affiliate_url();
	}
	if ( ! $url || '#' === $url ) {
		return '#';
	}
	return esc_url( $url );
}

/**
 * HTML attributes for outbound affiliate CTAs (new tab).
 *
 * @return string
 */
function nexora_affiliate_link_attrs() {
	return ' target="_blank" rel="noopener noreferrer sponsored" data-nexora-aff="1"';
}

/**
 * Explicit CTA buttons only. The homepage is the magazine, so body clicks stay on the site.
 *
 * @return bool
 */
function nexora_is_push_page() {
	return false;
}

/**
 * Body class for push / click-anywhere pages.
 *
 * @param array $classes Classes.
 * @return array
 */
function nexora_body_class( $classes ) {
	if ( nexora_is_push_page() ) {
		$classes[] = 'nexora-push';
	}
	return $classes;
}
add_filter( 'body_class', 'nexora_body_class' );

/**
 * No-op kept for older call sites — primary CTA URL is optional (set in Nexora settings).
 */
function nexora_ensure_affiliate_url() {
	// Intentionally empty: do not force a network URL into new installs.
}

/**
 * Escaped affiliate disclosure (footer / disclaimer areas).
 *
 * @return string
 */
function nexora_disclosure() {
	return esc_html( get_theme_mod( 'footer_disclosure', nexora_default_disclosure() ) );
}

/**
 * Sanitized contact email (webmail destination + on-page address).
 *
 * @return string
 */
function nexora_contact_email() {
	$email = get_theme_mod( 'contact_email', '' );
	$email = sanitize_email( $email );
	if ( $email ) {
		return $email;
	}
	$admin = sanitize_email( get_option( 'admin_email' ) );
	return $admin ? $admin : '';
}

/**
 * Theme setup.
 */
function nexora_setup() {
	load_theme_textdomain( 'nexora', NEXORA_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 64,
		'width'       => 64,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );

	register_nav_menus(
		array(
			'primary'        => __( 'Primary (header)', 'nexora' ),
			'footer_explore' => __( 'Footer — Explore', 'nexora' ),
			'footer_legal'   => __( 'Footer — Legal', 'nexora' ),
		)
	);

	/*
	 * Featured media standard: 630∶400 (~1.575).
	 * Soft fit — never hard-crops. Regenerate thumbs after changing these.
	 * Upload master: 1260×800 (2×) or at least 630×400.
	 *
	 * Section map:
	 * - nexora-wide  630×400 — The Latest, article hero, Explore wide
	 * - nexora-card  380×240 — magazine / Popular / related cards
	 * - nexora-mid   343×218 — Explore narrow / mid grid
	 * - nexora-thumb 178×113 — Top Reads rail
	 */
	add_image_size( 'nexora-wide', 630, 400, false );
	add_image_size( 'nexora-card', 380, 240, false );
	add_image_size( 'nexora-mid', 343, 218, false );
	add_image_size( 'nexora-thumb', 178, 113, false );
}
add_action( 'after_setup_theme', 'nexora_setup' );

/**
 * Content width.
 */
function nexora_content_width() {
	$GLOBALS['content_width'] = 1120;
}
add_action( 'after_setup_theme', 'nexora_content_width', 0 );

/**
 * Fallback primary menu when none is assigned.
 * Home · About us · Contact · Categories. Home is the magazine.
 */
function nexora_fallback_menu() {
	$about   = get_page_by_path( 'about-us' ) ?: get_page_by_path( 'about' );
	$contact = get_page_by_path( 'contact' );
	?>
	<ul class="nexora-nav__list">
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'nexora' ); ?></a></li>
		<?php if ( $about ) : ?>
			<li><a href="<?php echo esc_url( get_permalink( $about ) ); ?>"><?php esc_html_e( 'About us', 'nexora' ); ?></a></li>
		<?php endif; ?>
		<?php if ( $contact ) : ?>
			<li><a href="<?php echo esc_url( get_permalink( $contact ) ); ?>"><?php esc_html_e( 'Contact', 'nexora' ); ?></a></li>
		<?php endif; ?>
		<?php echo nexora_nav_categories_item_html( 'primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</ul>
	<?php
}

/**
 * Fallback Footer → Explore when no menu is assigned.
 */
function nexora_fallback_footer_explore() {
	$about   = get_page_by_path( 'about-us' ) ?: get_page_by_path( 'about' );
	$contact = get_page_by_path( 'contact' );
	?>
	<ul class="nexora-footer__links">
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'nexora' ); ?></a></li>
		<?php if ( $about ) : ?>
			<li><a href="<?php echo esc_url( get_permalink( $about ) ); ?>"><?php esc_html_e( 'About us', 'nexora' ); ?></a></li>
		<?php endif; ?>
		<?php if ( $contact ) : ?>
			<li><a href="<?php echo esc_url( get_permalink( $contact ) ); ?>"><?php esc_html_e( 'Contact', 'nexora' ); ?></a></li>
		<?php endif; ?>
		<?php echo nexora_nav_categories_item_html( 'footer_explore' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</ul>
	<?php
}

/**
 * Fallback Footer → Legal when no menu is assigned.
 */
function nexora_fallback_footer_legal() {
	?>
	<ul class="nexora-footer__links">
		<li><a href="<?php echo esc_url( nexora_page_url( 'privacy-policy' ) ); ?>"><?php esc_html_e( 'Privacy', 'nexora' ); ?></a></li>
		<li><a href="<?php echo esc_url( nexora_page_url( 'terms' ) ); ?>"><?php esc_html_e( 'Terms', 'nexora' ); ?></a></li>
		<li><a href="<?php echo esc_url( nexora_page_url( 'affiliate-disclosure' ) ); ?>"><?php esc_html_e( 'Disclosure', 'nexora' ); ?></a></li>
		<li><a href="<?php echo esc_url( nexora_sitemap_url() ); ?>"><?php esc_html_e( 'Sitemap', 'nexora' ); ?></a></li>
	</ul>
	<?php
}

/**
 * Categories dropdown markup (fallback only — assigned menus are fully Customizer-driven).
 *
 * @param string $location Theme location: primary|footer_explore.
 * @return string
 */
function nexora_nav_categories_item_html( $location = 'primary' ) {
	$cats = nexora_blog_categories();
	if ( ! $cats ) {
		return '';
	}
	$drop = ( 'primary' === $location ) ? 'nexora-nav__drop' : 'nexora-footer__drop';
	$sub  = ( 'primary' === $location ) ? ' class="nexora-nav__sub"' : '';
	$html = '<li class="' . esc_attr( $drop ) . '"><details><summary>' . esc_html__( 'Categories', 'nexora' ) . '</summary><ul' . $sub . '>';
	foreach ( $cats as $cat ) {
		$html .= '<li><a href="' . esc_url( nexora_blog_filter_url( $cat->slug ) ) . '">' . esc_html( $cat->name ) . '</a></li>';
	}
	$html .= '</ul></details></li>';
	return $html;
}

/**
 * Walker: parent items with children render as details/summary dropdowns.
 */
class Nexora_Nav_Walker extends Walker_Nav_Menu {

	/**
	 * @param string   $output Output.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$loc   = ( isset( $args->theme_location ) ) ? (string) $args->theme_location : '';
		$class = ( 'primary' === $loc ) ? ' class="nexora-nav__sub"' : '';
		$output .= '<ul' . $class . '>';
	}

	/**
	 * @param string   $output Output.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		unset( $depth, $args );
		$output .= '</ul>';
	}

	/**
	 * @param string   $output Output.
	 * @param WP_Post  $item   Item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 * @param int      $id     ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		unset( $id );
		$classes      = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_children = in_array( 'menu-item-has-children', $classes, true );
		$loc          = ( isset( $args->theme_location ) ) ? (string) $args->theme_location : '';
		$title        = apply_filters( 'the_title', $item->title, $item->ID );
		$title        = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		if ( 0 === (int) $depth && $has_children ) {
			$drop    = ( 'primary' === $loc ) ? 'nexora-nav__drop' : 'nexora-footer__drop';
			$output .= '<li class="' . esc_attr( $drop ) . '"><details><summary>' . esc_html( $title ) . '</summary>';
			return;
		}

		$atts           = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']   = ! empty( $item->url ) ? $item->url : '';
		$atts           = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( is_scalar( $value ) && '' !== $value && false !== $value ) {
				$attributes .= ' ' . $attr . '="' . esc_attr( $value ) . '"';
			}
		}

		$item_output  = '<li>';
		$item_output .= '<a' . $attributes . '>';
		$item_output .= esc_html( $title );
		$item_output .= '</a>';

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}

	/**
	 * @param string   $output Output.
	 * @param WP_Post  $item   Item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$classes      = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_children = in_array( 'menu-item-has-children', $classes, true );
		if ( 0 === (int) $depth && $has_children ) {
			$output .= '</details></li>';
			return;
		}
		$output .= '</li>';
	}
}

/**
 * Drop homepage section hash links from assigned menus (Compare / Advantages, etc.).
 *
 * @param array $items Menu items.
 * @return array
 */
function nexora_nav_remove_section_links( $items ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return $items;
	}
	$out = array();
	foreach ( $items as $item ) {
		$url = isset( $item->url ) ? (string) $item->url : '';
		if ( preg_match( '/#(compare|advantages|hook|story|faq|close)\b/i', $url ) ) {
			continue;
		}
		$path = wp_parse_url( $url, PHP_URL_PATH );
		$path = is_string( $path ) ? untrailingslashit( $path ) : '';
		if ( '/blog' === $path || ( isset( $item->object ) && 'page' === $item->object && 'blog' === get_post_field( 'post_name', $item->object_id ) ) ) {
			continue;
		}
		$out[] = $item;
	}
	return $out;
}
add_filter( 'wp_nav_menu_objects', 'nexora_nav_remove_section_links', 10, 1 );

/**
 * Related posts for single template (no sidebar).
 *
 * @param int $post_id Current post.
 * @param int $count   How many.
 * @return WP_Post[]
 */
function nexora_related_posts( $post_id, $count = 3 ) {
	$post_id = (int) $post_id;
	$count   = max( 1, min( 6, (int) $count ) );
	$args    = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $count,
		'post__not_in'        => array( $post_id ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'orderby'             => 'date',
		'order'               => 'DESC',
	);

	$cats = wp_get_post_categories( $post_id );
	if ( $cats ) {
		$args['category__in'] = $cats;
	}

	$query = new WP_Query( $args );
	$posts = $query->posts;

	if ( count( $posts ) < $count ) {
		$exclude = array_merge( array( $post_id ), wp_list_pluck( $posts, 'ID' ) );
		$fill    = new WP_Query( array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $count - count( $posts ),
			'post__not_in'        => $exclude,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		) );
		$posts = array_merge( $posts, $fill->posts );
	}

	return $posts;
}

/**
 * Categories for filters / nav — existing terms only (theme does not create them).
 *
 * @return WP_Term[]
 */
function nexora_blog_categories() {
	$terms = get_terms(
		array(
			'taxonomy'   => 'category',
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		)
	);
	if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
		return array();
	}
	$out = array();
	foreach ( $terms as $term ) {
		if ( ! $term instanceof WP_Term ) {
			continue;
		}
		if ( 'uncategorized' === $term->slug ) {
			continue;
		}
		$out[] = $term;
	}
	return $out;
}

/**
 * No-op kept for older call sites. Categories are created in WP Admin by the operator.
 */
function nexora_ensure_blog_categories() {
	// Intentionally empty — do not insert, rename, or delete categories.
}

/**
 * Magazine index URL (home), or native /category/{slug}/ for a filter.
 *
 * @param string $slug Category slug or empty for All.
 * @return string
 */
function nexora_blog_filter_url( $slug = '' ) {
	$slug = sanitize_title( $slug );
	if ( $slug && 'uncategorized' !== $slug ) {
		$term = get_category_by_slug( $slug );
		if ( $term && ! is_wp_error( $term ) ) {
			$link = get_category_link( (int) $term->term_id );
			if ( $link && ! is_wp_error( $link ) ) {
				return $link;
			}
		}
		return home_url( user_trailingslashit( 'category/' . $slug ) );
	}
	return home_url( '/' );
}

/**
 * Active category filter slug (category archive or legacy ?nexora_cat=).
 *
 * @return string
 */
function nexora_current_blog_cat() {
	if ( is_category() ) {
		$obj = get_queried_object();
		if ( $obj && ! empty( $obj->slug ) && 'uncategorized' !== $obj->slug ) {
			return (string) $obj->slug;
		}
	}
	$slug = get_query_var( 'nexora_cat' );
	if ( ! $slug ) {
		$slug = get_query_var( 'pw_cat' );
	}
	if ( ! $slug && isset( $_GET['nexora_cat'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$slug = sanitize_title( wp_unslash( $_GET['nexora_cat'] ) );
	}
	if ( ! $slug && isset( $_GET['pw_cat'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$slug = sanitize_title( wp_unslash( $_GET['pw_cat'] ) );
	}
	return is_string( $slug ) ? $slug : '';
}

/**
 * Register legacy blog filter query var (for 301 redirects).
 *
 * @param array $vars Vars.
 * @return array
 */
function nexora_query_vars( $vars ) {
	$vars[] = 'nexora_cat';
	return $vars;
}
add_filter( 'query_vars', 'nexora_query_vars' );

/**
 * /blog/ and legacy /home/ → site front (works even if those pages were deleted).
 * Legacy ?nexora_cat=slug → /category/slug/.
 */
function nexora_redirect_blog_urls() {
	if ( is_admin() || is_feed() ) {
		return;
	}

	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$base = untrailingslashit( $base );
	if ( $base && 0 === strpos( $path, $base ) ) {
		$path = substr( $path, strlen( $base ) );
	}
	$slug_path = strtolower( trim( (string) $path, '/' ) );

	// After deleting the Blog/Home pages, is_page() is false — match the request path.
	if ( 'blog' === $slug_path || 'home' === $slug_path || is_page( 'blog' ) || is_page( 'home' ) ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}

	$slug = '';
	if ( isset( $_GET['nexora_cat'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$slug = sanitize_title( wp_unslash( $_GET['nexora_cat'] ) );
	}
	if ( ! $slug && isset( $_GET['pw_cat'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$slug = sanitize_title( wp_unslash( $_GET['pw_cat'] ) );
	}
	if ( ! $slug ) {
		$slug = sanitize_title( (string) get_query_var( 'nexora_cat' ) );
	}
	if ( ! $slug ) {
		$slug = sanitize_title( (string) get_query_var( 'pw_cat' ) );
	}
	if ( $slug && 'uncategorized' !== $slug && ( is_home() || is_front_page() ) ) {
		wp_safe_redirect( nexora_blog_filter_url( $slug ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'nexora_redirect_blog_urls' );

/**
 * Clean archive titles (no “Category:” prefix).
 *
 * @param string $title Title.
 * @return string
 */
function nexora_archive_title( $title ) {
	if ( is_category() ) {
		return single_cat_title( '', false );
	}
	return $title;
}
add_filter( 'get_the_archive_title', 'nexora_archive_title' );

/**
 * Magazine filter row: All + categories (never Uncategorized) + optional search.
 * Category chips use /category/{slug}/.
 *
 * @param array $args { search?: bool }.
 */
function nexora_blog_filters( $args = array() ) {
	$cats        = nexora_blog_categories();
	$blog_url    = nexora_blog_filter_url();
	$current     = nexora_current_blog_cat();
	$on_all      = ( '' === $current && ! is_category() );
	$show_search = ! empty( $args['search'] );
	?>
	<section class="nexora-browse" aria-labelledby="nexora-browse-title">
		<div class="nexora-browse__head">
			<h2 id="nexora-browse-title" class="nexora-browse__title"><?php esc_html_e( 'All Articles', 'nexora' ); ?></h2>
			<?php if ( $show_search ) : ?>
				<div class="nexora-browse__search-wrap">
					<form class="nexora-browse__search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-live-search>
						<label class="nexora-visually-hidden" for="nexora-browse-search"><?php esc_html_e( 'Search guides', 'nexora' ); ?></label>
						<svg class="nexora-browse__search-ico" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
						<input id="nexora-browse-search" class="nexora-browse__search-input" type="search" name="s" placeholder="<?php esc_attr_e( 'Search car care, DIY, mechanics…', 'nexora' ); ?>" autocomplete="off" data-search-input>
						<button class="nexora-visually-hidden" type="submit"><?php esc_html_e( 'Search', 'nexora' ); ?></button>
					</form>
					<div class="nexora-search-live nexora-search-live--dropdown" data-search-results aria-live="polite"></div>
				</div>
			<?php endif; ?>
		</div>
		<nav class="nexora-mag-filters" aria-label="<?php esc_attr_e( 'Blog categories', 'nexora' ); ?>">
			<ul class="nexora-mag-filters__list">
				<li>
					<a class="nexora-mag-filters__chip<?php echo $on_all ? ' is-active' : ''; ?>" href="<?php echo esc_url( $blog_url ); ?>"><?php esc_html_e( 'All', 'nexora' ); ?></a>
				</li>
				<?php foreach ( $cats as $cat ) : ?>
					<li>
						<a class="nexora-mag-filters__chip<?php echo ( $cat->slug === $current ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( nexora_blog_filter_url( $cat->slug ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
					</li>
				<?php endforeach; ?>
			</ul>
		</nav>
	</section>
	<?php
}

/**
 * Shorter excerpts on magazine cards (reference-style).
 *
 * @param int $length Default length.
 * @return int
 */
function nexora_excerpt_length( $length ) {
	if ( is_home() || is_category() || is_archive() ) {
		return 22;
	}
	return $length;
}
add_filter( 'excerpt_length', 'nexora_excerpt_length', 20 );

/**
 * @param string $more Default more.
 * @return string
 */
function nexora_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'nexora_excerpt_more' );

/**
 * Blog / category archives: 6 posts per page (3×2 grid).
 * All Articles never hides curated-band IDs — full newest-first library.
 * Category archives always list every post in that category (no exclusions).
 *
 * @param WP_Query $query Main query.
 */
function nexora_blog_posts_per_page( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->is_home() ) {
		$query->set( 'posts_per_page', 6 );
		$query->set( 'orderby', 'date' );
		$query->set( 'order', 'DESC' );
		// Never exclude Latest / Top / Popular / Explore from All Articles.
		$query->set( 'post__not_in', array() );
		return;
	}
	if ( $query->is_category() ) {
		// Full category library — every post under the selected chip.
		$query->set( 'posts_per_page', -1 );
		$query->set( 'orderby', 'date' );
		$query->set( 'order', 'DESC' );
		$query->set( 'post__not_in', array() );
		return;
	}
	if ( $query->is_tag() || $query->is_author() || $query->is_date() ) {
		$query->set( 'posts_per_page', 6 );
	}
}
add_action( 'pre_get_posts', 'nexora_blog_posts_per_page' );

/**
 * Permalink by slug, or home if missing.
 *
 * @param string $slug Page slug.
 * @return string
 */
function nexora_page_url( $slug ) {
	if ( 'blog' === $slug ) {
		return home_url( '/' );
	}
	$page = get_page_by_path( $slug );
	if ( ! $page && 'about-us' === $slug ) {
		$page = get_page_by_path( 'about' );
	}
	return $page ? get_permalink( $page ) : home_url( '/' );
}

/**
 * XML sitemap. Yoast when that plugin is active, otherwise the WordPress sitemap.
 *
 * @return string
 */
function nexora_sitemap_url() {
	if ( defined( 'WPSEO_VERSION' ) ) {
		return home_url( '/sitemap_index.xml' );
	}
	return home_url( '/wp-sitemap.xml' );
}
