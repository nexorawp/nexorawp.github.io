<?php
/**
 * Performance: deferred JS, image pipeline, branded preloader.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defer the theme script.
 *
 * @param string $tag    Script tag.
 * @param string $handle Handle.
 * @param string $src    Src.
 * @return string
 */
function nexora_defer_scripts( $tag, $handle, $src ) {
	if ( 'nexora-main' === $handle && false === strpos( $tag, ' defer' ) ) {
		return str_replace( ' src', ' defer src', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'nexora_defer_scripts', 10, 3 );

/**
 * Prefer WebP for new JPEG/PNG uploads when the host can encode it.
 *
 * @param array<string,string> $formats Mime map.
 * @return array<string,string>
 */
function nexora_image_output_format( $formats ) {
	if ( ! is_array( $formats ) ) {
		$formats = array();
	}
	if ( function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) ) ) {
		$formats['image/jpeg'] = 'image/webp';
		$formats['image/png']  = 'image/webp';
	}
	return $formats;
}
add_filter( 'image_editor_output_format', 'nexora_image_output_format' );

/**
 * Balanced JPEG/WebP quality (sharp enough, smaller files).
 *
 * @return int
 */
function nexora_image_quality() {
	return 82;
}
add_filter( 'jpeg_quality', 'nexora_image_quality' );
add_filter( 'wp_editor_set_quality', 'nexora_image_quality' );

/**
 * Cap very large originals so media library stays lean.
 *
 * @return int
 */
function nexora_big_image_threshold() {
	return 2048;
}
add_filter( 'big_image_size_threshold', 'nexora_big_image_threshold' );

/**
 * Default lazy + async decoding on attachment images (LCP can override).
 *
 * @param array<string,string> $attr       Attributes.
 * @param WP_Post              $attachment Attachment.
 * @param string|int[]         $size       Size.
 * @return array<string,string>
 */
function nexora_attachment_image_attributes( $attr, $attachment, $size ) {
	unset( $size );
	if ( ! is_array( $attr ) ) {
		$attr = array();
	}
	if ( empty( $attr['decoding'] ) ) {
		$attr['decoding'] = 'async';
	}
	if ( empty( $attr['loading'] ) ) {
		$attr['loading'] = 'lazy';
	}

	// Theme marker for thumbs inside aria-hidden media links — keep alt empty.
	$decorative = ! empty( $attr['data-nexora-decorative'] );
	unset( $attr['data-nexora-decorative'] );

	$id       = ( $attachment instanceof WP_Post ) ? (int) $attachment->ID : 0;
	$fallback = ( $attachment instanceof WP_Post ) ? (string) $attachment->post_title : '';

	if ( $decorative ) {
		$attr['alt'] = '';
	} elseif ( ! isset( $attr['alt'] ) || '' === trim( (string) $attr['alt'] ) ) {
		$attr['alt'] = function_exists( 'nexora_attachment_alt' )
			? nexora_attachment_alt( $id, $fallback )
			: $fallback;
	}

	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'nexora_attachment_image_attributes', 10, 3 );

/**
 * Custom logo must keep a non-empty alt (site name).
 *
 * @param array<string,string> $attr Logo img attributes.
 * @return array<string,string>
 */
function nexora_custom_logo_image_attributes( $attr ) {
	if ( ! is_array( $attr ) ) {
		$attr = array();
	}
	if ( empty( $attr['alt'] ) ) {
		$attr['alt'] = get_bloginfo( 'name', 'display' );
	}
	/* Keep natural aspect — never force a square box via equal width/height attrs. */
	unset( $attr['style'] );
	return $attr;
}
add_filter( 'get_custom_logo_image_attributes', 'nexora_custom_logo_image_attributes' );

/**
 * Ensure in-content images get lazy + async + an alt attribute when WordPress prints them.
 *
 * @param string $html Img tag.
 * @return string
 */
function nexora_content_img_tag( $html ) {
	if ( ! is_string( $html ) || '' === $html ) {
		return $html;
	}
	if ( false === stripos( $html, ' decoding=' ) ) {
		$html = preg_replace( '/<img\b/i', '<img decoding="async"', $html, 1 );
	}
	if ( false === stripos( $html, ' loading=' ) ) {
		$html = preg_replace( '/<img\b/i', '<img loading="lazy"', $html, 1 );
	}
	// Missing alt attribute entirely (not empty alt="") — add empty decorative default.
	if ( is_string( $html ) && ! preg_match( '/\salt\s*=/i', $html ) ) {
		$html = preg_replace( '/<img\b/i', '<img alt=""', $html, 1 );
	}
	return is_string( $html ) ? $html : '';
}
add_filter( 'wp_content_img_tag', 'nexora_content_img_tag' );

/**
 * Brand mark preloader (logo-mark + wordmark).
 */
function nexora_preloader_markup() {
	if ( is_admin() || ! nexora_get_option( 'preloader_enabled' ) ) {
		return;
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
	if ( $ua && preg_match( '/bot|crawl|slurp|spider|mediapartners|facebookexternalhit/i', $ua ) ) {
		return;
	}
	$logo = function_exists( 'nexora_mark_url' ) ? nexora_mark_url( 'svg' ) : '';
	?>
	<div class="nexora-preloader" data-nexora-preloader role="status" aria-live="polite" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: site name */ __( 'Loading %s', 'nexora' ), get_bloginfo( 'name', 'display' ) ) ); ?>">
		<div class="nexora-preloader__inner">
			<?php if ( $logo ) : ?>
				<img class="nexora-preloader__mark" src="<?php echo esc_url( $logo ); ?>" alt="" width="48" height="48" decoding="async" fetchpriority="high" aria-hidden="true">
			<?php endif; ?>
			<?php if ( function_exists( 'nexora_logo_wordmark' ) ) : ?>
				<?php nexora_logo_wordmark(); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php
}
add_action( 'wp_body_open', 'nexora_preloader_markup', 1 );
