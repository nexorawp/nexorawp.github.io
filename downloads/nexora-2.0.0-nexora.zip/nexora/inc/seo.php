<?php
/**
 * Search-result titles and meta descriptions.
 *
 * Visible page headings stay in the templates. These strings are only for
 * the browser title and the Google snippet.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Brand string for SEO titles = Site Identity name (never forces “Nexora” onto the live site brand).
 *
 * @return string
 */
function nexora_seo_brand() {
	$name = get_bloginfo( 'name', 'display' );
	if ( $name ) {
		return $name;
	}
	return defined( 'NEXORA_THEME_NAME' ) ? NEXORA_THEME_NAME : 'Nexora';
}

/**
 * WordPress tagline helper (read-only default for empty sites — does not write options).
 *
 * @return string
 */
function nexora_seo_tagline() {
	$tag = get_bloginfo( 'description', 'display' );
	if ( $tag ) {
		return $tag;
	}
	return __( 'Practical guides for curious readers.', 'nexora' );
}

/**
 * Default site description used in snippets and schema.
 *
 * @return string
 */
function nexora_seo_blurb() {
	$tag = trim( (string) get_bloginfo( 'description', 'display' ) );
	if ( $tag ) {
		return $tag;
	}
	return __( 'Practical magazine guides — clear writing for everyday questions.', 'nexora' );
}

/**
 * Refresh stale disclosure theme_mod only. Never overwrites site title or tagline.
 */
function nexora_sync_tagline() {
	$disclosure = get_theme_mod( 'footer_disclosure', '' );
	$stale_disc = array(
		'',
		'Paul World is reader-supported. If you buy through our links, we may earn a commission at no extra cost to you.',
		'Paul World is reader-supported. Reviews may include affiliate links — we may earn a commission at no extra cost to you. We may also show ads (including Google AdSense). Ad partners may use cookies or similar tech as described in our Privacy Policy.',
		'Paul World is reader-supported. Guides may include affiliate links — we may earn a commission at no extra cost to you. We may also show ads (including Google AdSense). Ad partners may use cookies or similar tech as described in our Privacy Policy.',
		'Paul World is reader-supported. Affiliate links and ads may appear — see Disclosure and Privacy.',
		'Reader-supported. Affiliate links and ads may appear — see Disclosure and Privacy.',
	);
	if ( in_array( $disclosure, $stale_disc, true ) ) {
		set_theme_mod( 'footer_disclosure', nexora_default_disclosure() );
	}
}

/**
 * Trim a snippet to a search-result length.
 *
 * @param string $text Raw text.
 * @param int    $max  Character budget.
 * @return string
 */
function nexora_seo_trim( $text, $max = 158 ) {
	$text = wp_strip_all_tags( (string) $text );
	$text = preg_replace( '/\s+/u', ' ', $text );
	$text = trim( (string) $text );
	if ( '' === $text ) {
		return '';
	}
	if ( function_exists( 'mb_strlen' ) && mb_strlen( $text ) <= $max ) {
		return $text;
	}
	if ( ! function_exists( 'mb_strlen' ) && strlen( $text ) <= $max ) {
		return $text;
	}
	$cut   = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, $max - 1 ) : substr( $text, 0, $max - 1 );
	$space = function_exists( 'mb_strrpos' ) ? mb_strrpos( $cut, ' ' ) : strrpos( $cut, ' ' );
	if ( false !== $space && $space > 40 ) {
		$cut = function_exists( 'mb_substr' ) ? mb_substr( $cut, 0, $space ) : substr( $cut, 0, $space );
	}
	return rtrim( $cut, " \t\n\r\0\x0B.,;:—-" ) . '…';
}

/**
 * Canonical title + description for the current request.
 *
 * @return array{title:string,description:string,robots?:string,url?:string}|null
 */
function nexora_seo_for_request() {
	$brand      = nexora_seo_brand();
	$home_title = sprintf(
		/* translators: %s: site name */
		__( '%1$s | %2$s', 'nexora' ),
		nexora_seo_tagline(),
		$brand
	);
	$home_desc = nexora_seo_blurb();

	$map = array(
		'front' => array(
			'title'       => $home_title,
			'description' => $home_desc,
			'url'         => home_url( '/' ),
		),
		'about-us' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'About | %s', 'nexora' ), $brand ),
			'description' => $home_desc,
		),
		'about' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'About | %s', 'nexora' ), $brand ),
			'description' => $home_desc,
		),
		'contact' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Contact | %s', 'nexora' ), $brand ),
			'description' => sprintf(
				/* translators: %s: site name */
				__( 'Ask a question or send a correction. Use the contact form on %s.', 'nexora' ),
				$brand
			),
		),
		'gohighlevel-review' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'GoHighLevel Review | %s', 'nexora' ), $brand ),
			'description' => __( 'An independent GoHighLevel review: what the platform covers, who it fits, who should skip it, and where to confirm current plans.', 'nexora' ),
		),
		'privacy-policy' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Privacy Policy | %s', 'nexora' ), $brand ),
			'description' => sprintf(
				/* translators: %s: site name */
				__( 'How %s handles the contact form, site logs, and affiliate clicks.', 'nexora' ),
				$brand
			),
		),
		'terms' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Terms of Service | %s', 'nexora' ), $brand ),
			'description' => sprintf(
				/* translators: %s: site name */
				__( 'Terms for using %s. Guides are information only — no income promises.', 'nexora' ),
				$brand
			),
		),
		'affiliate-disclosure' => array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Affiliate Disclosure | %s', 'nexora' ), $brand ),
			'description' => sprintf(
				/* translators: %s: site name */
				__( '%s may earn a commission if you buy through a link on this site. The price you pay does not go up.', 'nexora' ),
				$brand
			),
		),
	);

	if ( is_category() ) {
		$cat = get_queried_object();
		if ( $cat && ! is_wp_error( $cat ) && ! empty( $cat->slug ) && 'uncategorized' !== $cat->slug ) {
			$desc = trim( wp_strip_all_tags( (string) $cat->description ) );
			if ( '' === $desc ) {
				$desc = sprintf(
					/* translators: 1: category name 2: site name */
					__( '%1$s guides from %2$s.', 'nexora' ),
					$cat->name,
					$brand
				);
			}
			$row = array(
				'title'       => sprintf(
					/* translators: 1: category name 2: site name */
					__( '%1$s | %2$s', 'nexora' ),
					$cat->name,
					$brand
				),
				'description' => nexora_seo_trim( $desc ),
				'url'         => get_category_link( (int) $cat->term_id ),
			);
			if ( is_paged() ) {
				$row['robots'] = 'noindex, follow';
				$row['url']    = get_category_link( (int) $cat->term_id );
			}
			return $row;
		}
	}

	if ( is_front_page() || is_home() ) {
		$row = $map['front'];
		// Thin paginated lists: keep canonical on page 1, do not index page 2+.
		if ( is_paged() ) {
			$row['robots'] = 'noindex, follow';
		}
		return $row;
	}

	if ( is_singular( 'post' ) ) {
		$post_id = get_queried_object_id();
		$title   = wp_strip_all_tags( get_the_title( $post_id ) );
		$brand_q = preg_quote( $brand, '/' );
		if ( $brand && ! preg_match( '/' . $brand_q . '/i', $title ) ) {
			$title .= ' | ' . $brand;
		}
		$raw = get_post_field( 'post_excerpt', $post_id );
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			$raw = get_post_field( 'post_content', $post_id );
		}
		$desc = nexora_seo_trim( $raw );
		if ( '' === $desc ) {
			$desc = $home_desc;
		}
		return array(
			'title'       => $title,
			'description' => $desc,
			'url'         => get_permalink( $post_id ),
		);
	}

	if ( is_page() ) {
		$slug = (string) get_post_field( 'post_name', get_queried_object_id() );
		if ( isset( $map[ $slug ] ) ) {
			$row        = $map[ $slug ];
			$row['url'] = get_permalink();
			return $row;
		}
		$title   = wp_strip_all_tags( get_the_title() );
		$brand_q = preg_quote( $brand, '/' );
		if ( $brand && ! preg_match( '/' . $brand_q . '/i', $title ) ) {
			$title .= ' | ' . $brand;
		}
		return array(
			'title'       => $title,
			'description' => $home_desc,
			'url'         => get_permalink(),
		);
	}

	if ( is_search() ) {
		return array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Search | %s', 'nexora' ), $brand ),
			'description' => $home_desc,
			'robots'      => 'noindex, follow',
		);
	}

	if ( is_author() ) {
		return array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Author archive | %s', 'nexora' ), $brand ),
			'description' => $home_desc,
			'robots'      => 'noindex, follow',
		);
	}

	if ( is_404() ) {
		return array(
			'title'       => sprintf( /* translators: %s: site name */ __( 'Page not found | %s', 'nexora' ), $brand ),
			'description' => sprintf(
				/* translators: %s: site name */
				__( 'That page is not on %s. Browse guides from the homepage.', 'nexora' ),
				$brand
			),
			'robots'      => 'noindex, follow',
		);
	}

	return null;
}



/**
 * Whether another SEO plugin is already printing the title and description.
 *
 * @return bool
 */
function nexora_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

/**
 * Replace weak titles such as "{Site name}: Home".
 *
 * @param array $parts Title parts.
 * @return array
 */
function nexora_document_title_parts( $parts ) {
	$seo = nexora_seo_for_request();
	if ( ! $seo ) {
		return $parts;
	}
	$parts['title'] = $seo['title'];
	unset( $parts['site'], $parts['tagline'] );
	return $parts;
}
add_filter( 'document_title_parts', 'nexora_document_title_parts' );

/**
 * Description, canonical, robots, and social tags when Yoast is not active.
 */
function nexora_meta_description() {
	if ( nexora_seo_plugin_active() ) {
		return;
	}
	$seo = nexora_seo_for_request();
	if ( ! $seo ) {
		return;
	}

	if ( ! empty( $seo['description'] ) ) {
		echo '<meta name="description" content="' . esc_attr( $seo['description'] ) . '">' . "\n";
	}
	if ( ! empty( $seo['robots'] ) ) {
		echo '<meta name="robots" content="' . esc_attr( $seo['robots'] ) . '">' . "\n";
	}
	if ( ! empty( $seo['url'] ) ) {
		echo '<link rel="canonical" href="' . esc_url( $seo['url'] ) . '">' . "\n";
	}

	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $seo['title'] ) . '">' . "\n";
	if ( ! empty( $seo['description'] ) ) {
		echo '<meta property="og:description" content="' . esc_attr( $seo['description'] ) . '">' . "\n";
	}
	echo '<meta property="og:type" content="' . ( is_singular( 'post' ) ? 'article' : 'website' ) . '">' . "\n";
	if ( ! empty( $seo['url'] ) ) {
		echo '<meta property="og:url" content="' . esc_url( $seo['url'] ) . '">' . "\n";
	}

	$image = '';
	if ( is_singular() && has_post_thumbnail() ) {
		$image = (string) get_the_post_thumbnail_url( get_queried_object_id(), 'full' );
	}
	if ( ! $image && function_exists( 'nexora_default_og_image_url' ) ) {
		$image = nexora_default_og_image_url();
	}
	if ( ! $image && function_exists( 'nexora_mark_url' ) ) {
		$image = nexora_mark_url( '1200' );
	}
	if ( $image ) {
		echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
		if ( function_exists( 'nexora_default_og_image_url' ) && $image === nexora_default_og_image_url() ) {
			echo '<meta property="og:image:width" content="1200">' . "\n";
			echo '<meta property="og:image:height" content="675">' . "\n";
		}
	}

	echo '<meta name="twitter:card" content="' . ( $image ? 'summary_large_image' : 'summary' ) . '">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $seo['title'] ) . '">' . "\n";
	if ( ! empty( $seo['description'] ) ) {
		echo '<meta name="twitter:description" content="' . esc_attr( $seo['description'] ) . '">' . "\n";
	}

	if ( is_singular( 'post' ) ) {
		$names = array();
		$cats  = get_the_category();
		if ( is_array( $cats ) ) {
			foreach ( $cats as $cat ) {
				if ( $cat && 'uncategorized' !== $cat->slug ) {
					$names[] = $cat->name;
				}
			}
		}
		$tags = get_the_tags();
		if ( is_array( $tags ) ) {
			foreach ( $tags as $tag ) {
				if ( $tag && ! in_array( $tag->name, $names, true ) ) {
					$names[] = $tag->name;
				}
			}
		}
		foreach ( array_slice( $names, 0, 8 ) as $name ) {
			echo '<meta property="article:tag" content="' . esc_attr( $name ) . '">' . "\n";
		}
	}
}
add_action( 'wp_head', 'nexora_meta_description', 1 );

/**
 * Avoid duplicate rel=canonical (core + theme).
 */
function nexora_disable_core_canonical() {
	if ( nexora_seo_plugin_active() ) {
		return;
	}
	remove_action( 'wp_head', 'rel_canonical' );
}
add_action( 'wp_head', 'nexora_disable_core_canonical', 0 );

/**
 * Drop author/user URLs from the core XML sitemap.
 *
 * @param WP_Sitemaps_Provider $provider Provider instance.
 * @param string               $name     Provider name.
 * @return WP_Sitemaps_Provider|false
 */
function nexora_disable_user_sitemap( $provider, $name ) {
	if ( 'users' === $name ) {
		return false;
	}
	return $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'nexora_disable_user_sitemap', 10, 2 );

/**
 * Yoast: use the same titles and descriptions.
 *
 * @param string $title Generated title.
 * @return string
 */
function nexora_wpseo_title( $title ) {
	$seo = nexora_seo_for_request();
	return $seo ? $seo['title'] : $title;
}
add_filter( 'wpseo_title', 'nexora_wpseo_title' );

/**
 * Yoast meta description.
 *
 * @param string $description Generated description.
 * @return string
 */
function nexora_wpseo_metadesc( $description ) {
	$seo = nexora_seo_for_request();
	return $seo ? $seo['description'] : $description;
}
add_filter( 'wpseo_metadesc', 'nexora_wpseo_metadesc' );

/**
 * Open Graph title/description for Yoast.
 *
 * @param string $value Current value.
 * @return string
 */
function nexora_wpseo_opengraph_title( $value ) {
	$seo = nexora_seo_for_request();
	return $seo ? $seo['title'] : $value;
}
add_filter( 'wpseo_opengraph_title', 'nexora_wpseo_opengraph_title' );

/**
 * Open Graph description for Yoast.
 *
 * @param string $value Current value.
 * @return string
 */
function nexora_wpseo_opengraph_desc( $value ) {
	$seo = nexora_seo_for_request();
	return $seo ? $seo['description'] : $value;
}
add_filter( 'wpseo_opengraph_desc', 'nexora_wpseo_opengraph_desc' );

/**
 * Whether this request should use the theme brand OG card (no featured image).
 *
 * @return bool
 */
function nexora_should_use_default_og_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		return false;
	}
	return (bool) nexora_default_og_image_url();
}

/**
 * Yoast Open Graph image: featured image when present, else brand 1200×675 card.
 *
 * @param string $url Current image URL.
 * @return string
 */
function nexora_wpseo_opengraph_image( $url ) {
	if ( ! nexora_should_use_default_og_image() ) {
		return $url;
	}
	$default = nexora_default_og_image_url();
	return $default ? $default : $url;
}
add_filter( 'wpseo_opengraph_image', 'nexora_wpseo_opengraph_image' );

/**
 * Yoast Twitter image — same fallback as Open Graph.
 *
 * @param string $url Current image URL.
 * @return string
 */
function nexora_wpseo_twitter_image( $url ) {
	return nexora_wpseo_opengraph_image( $url );
}
add_filter( 'wpseo_twitter_image', 'nexora_wpseo_twitter_image' );

/**
 * Ensure Yoast still emits an OG image when none is stored (empty social default).
 *
 * @param object $image_container Yoast image container.
 */
function nexora_wpseo_add_og_images( $image_container ) {
	if ( ! nexora_should_use_default_og_image() || ! is_object( $image_container ) ) {
		return;
	}
	if ( method_exists( $image_container, 'has_images' ) && $image_container->has_images() ) {
		return;
	}
	$url = nexora_default_og_image_url();
	if ( ! $url ) {
		return;
	}
	if ( method_exists( $image_container, 'add_image_by_url' ) ) {
		$image_container->add_image_by_url( $url );
	} elseif ( method_exists( $image_container, 'add_image' ) ) {
		$image_container->add_image(
			array(
				'url' => $url,
			)
		);
	}
}
add_action( 'wpseo_add_opengraph_images', 'nexora_wpseo_add_og_images' );

/**
 * OG dimensions when using the theme brand card.
 *
 * @param string|int $width Current width.
 * @return string|int
 */
function nexora_wpseo_opengraph_image_width( $width ) {
	return nexora_should_use_default_og_image() ? 1200 : $width;
}
add_filter( 'wpseo_opengraph_image_width', 'nexora_wpseo_opengraph_image_width' );

/**
 * @param string|int $height Current height.
 * @return string|int
 */
function nexora_wpseo_opengraph_image_height( $height ) {
	return nexora_should_use_default_og_image() ? 675 : $height;
}
add_filter( 'wpseo_opengraph_image_height', 'nexora_wpseo_opengraph_image_height' );

/**
 * Yoast robots for thin URLs the theme also noindexes.
 *
 * @param string $robots Current directive.
 * @return string
 */
function nexora_wpseo_robots( $robots ) {
	if ( is_search() || is_author() || is_404() || ( ( is_home() || is_front_page() || is_category() ) && is_paged() ) ) {
		return 'noindex, follow';
	}
	return $robots;
}
add_filter( 'wpseo_robots', 'nexora_wpseo_robots' );

/**
 * Virtual robots.txt at /robots.txt. A real file in the WordPress root would override this.
 *
 * When Yoast (or another SEO plugin) is active, leave its robots.txt unchanged so the
 * Sitemap URL is declared once inside the plugin block. Without an SEO plugin, the theme
 * publishes a minimal allow-all file plus one Sitemap line (core/WP sitemap).
 *
 * @param string $output Existing rules.
 * @param string $public Site visibility option.
 * @return string
 */
function nexora_robots_txt( $output, $public ) {
	if ( '0' === (string) $public ) {
		return $output;
	}

	// Yoast already prints User-agent / Disallow / Sitemap — do not duplicate Sitemap.
	if ( function_exists( 'nexora_seo_plugin_active' ) && nexora_seo_plugin_active() ) {
		return $output;
	}

	$site_url = wp_parse_url( site_url() );
	$path     = '';
	if ( is_array( $site_url ) && ! empty( $site_url['path'] ) ) {
		$path = untrailingslashit( (string) $site_url['path'] );
	}

	$lines   = array();
	$lines[] = 'User-agent: *';
	$lines[] = 'Disallow: ' . $path . '/wp-admin/';
	$lines[] = 'Allow: ' . $path . '/wp-admin/admin-ajax.php';
	$lines[] = '';
	$lines[] = 'Sitemap: ' . nexora_sitemap_url();

	return implode( "\n", $lines ) . "\n";
}
add_filter( 'robots_txt', 'nexora_robots_txt', 99, 2 );
