<?php
/**
 * Create essential pages on theme activation.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Insert a page if the slug does not exist.
 *
 * @param array $args Page args.
 * @return int Page ID.
 */
function nexora_ensure_page( $args ) {
	$existing = get_page_by_path( $args['post_name'] );
	if ( $existing ) {
		if ( ! empty( $args['page_template'] ) ) {
			update_post_meta( $existing->ID, '_wp_page_template', $args['page_template'] );
		}
		return (int) $existing->ID;
	}

	$template = isset( $args['page_template'] ) ? $args['page_template'] : '';
	unset( $args['page_template'] );

	$args = wp_parse_args( $args, array(
		'post_status' => 'publish',
		'post_type'   => 'page',
	) );

	$id = wp_insert_post( $args, true );
	if ( is_wp_error( $id ) ) {
		return 0;
	}

	if ( $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}

	return (int) $id;
}

/**
 * Update an existing page’s title, content, and template.
 *
 * @param string $slug     Page slug.
 * @param string $title    Post title.
 * @param string $content  HTML content.
 * @param string $template Page template path.
 */
function nexora_refresh_page_content( $slug, $title, $content, $template = '' ) {
	$page = get_page_by_path( $slug );
	if ( ! $page ) {
		return;
	}
	wp_update_post( array(
		'ID'           => (int) $page->ID,
		'post_title'   => $title,
		'post_content' => $content,
		'post_status'  => 'publish',
	) );
	if ( $template ) {
		update_post_meta( (int) $page->ID, '_wp_page_template', $template );
	}
}

/**
 * Rename a page slug when the new slug is free (SEO-friendly URLs).
 *
 * @param string $old_slug Current slug.
 * @param string $new_slug Desired slug.
 */
function nexora_migrate_page_slug( $old_slug, $new_slug ) {
	if ( get_page_by_path( $new_slug ) ) {
		return;
	}
	$old = get_page_by_path( $old_slug );
	if ( ! $old ) {
		return;
	}
	wp_update_post( array(
		'ID'        => (int) $old->ID,
		'post_name' => $new_slug,
	) );
}

/**
 * Ensure essential site pages (never demo posts or sample media).
 *
 * Does not create blog posts, categories, or stock/dummy images.
 * Missing featured images stay empty (CSS placeholder only).
 */
function nexora_after_switch_theme() {
	// Prefer SEO slug /about-us/ if an older /about/ page exists.
	nexora_migrate_page_slug( 'about', 'about-us' );

	// Only structural/legal pages — skip if the slug already exists.
	nexora_ensure_page( array(
		'post_title'     => 'About',
		'post_name'      => 'about-us',
		'post_content'   => nexora_content_about(),
		'page_template'  => 'page-templates/template-about.php',
	) );

	nexora_ensure_page( array(
		'post_title'     => 'Contact',
		'post_name'      => 'contact',
		'post_content'   => nexora_content_contact(),
		'page_template'  => 'page-templates/template-contact.php',
	) );

	nexora_ensure_page( array(
		'post_title'     => 'Privacy Policy',
		'post_name'      => 'privacy-policy',
		'post_content'   => nexora_content_privacy(),
		'page_template'  => 'page-templates/template-legal.php',
	) );

	nexora_ensure_page( array(
		'post_title'     => 'Terms of Service',
		'post_name'      => 'terms',
		'post_content'   => nexora_content_terms(),
		'page_template'  => 'page-templates/template-legal.php',
	) );

	nexora_ensure_page( array(
		'post_title'     => 'Affiliate Disclosure',
		'post_name'      => 'affiliate-disclosure',
		'post_content'   => nexora_content_affiliate(),
		'page_template'  => 'page-templates/template-legal.php',
	) );

	/*
	 * Do not overwrite existing About/Privacy/Terms/Contact HTML.
	 * ensure_page() only inserts missing slugs — existing live content stays.
	 */
	nexora_use_posts_as_front();
	if ( function_exists( 'nexora_ensure_site_icon' ) ) {
		nexora_ensure_site_icon();
	}

	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'nexora_after_switch_theme' );

/**
 * Latest posts are the homepage. /blog/ is not a separate posts page.
 */
function nexora_use_posts_as_front() {
	update_option( 'show_on_front', 'posts' );
	update_option( 'page_on_front', 0 );
	update_option( 'page_for_posts', 0 );
	flush_rewrite_rules( false );
}

/**
 * Legacy helper — no longer overwrites page bodies (Nexora content lock).
 * Kept so older hooks/docs do not fatal; creates nothing and updates nothing.
 */
function nexora_sync_legal_pages() {
	// Intentionally empty: niche/theme updates must not mutate live page content.
}

/**
 * After a zip upload (theme already active): structural defaults only.
 * Does not rewrite posts, pages, site title, or tagline.
 */
function nexora_maybe_sync_content() {
	if ( ! defined( 'NEXORA_CONTENT_VERSION' ) ) {
		return;
	}
	if ( nexora_option_with_legacy( 'nexora_content_version', 'paulworld_content_version', '' ) === NEXORA_CONTENT_VERSION ) {
		return;
	}
	if ( 'nexora' !== get_option( 'template' ) ) {
		return;
	}

	nexora_use_posts_as_front();
	// Disclosure theme_mod only when still a known retired default — never blogdescription.
	if ( function_exists( 'nexora_maybe_refresh_disclosure' ) ) {
		nexora_maybe_refresh_disclosure();
	}
	if ( function_exists( 'nexora_ensure_site_icon' ) ) {
		nexora_ensure_site_icon();
	}
	update_option( 'nexora_content_version', NEXORA_CONTENT_VERSION );
}
add_action( 'init', 'nexora_maybe_sync_content', 30 );

/**
 * Site identity helpers for seeded legal/about HTML (new installs only).
 *
 * @return array{name:string,host:string,home:string,email:string}
 */
function nexora_seed_site_identity() {
	$name  = get_bloginfo( 'name', 'display' );
	$home  = home_url( '/' );
	$host  = wp_parse_url( $home, PHP_URL_HOST );
	$email = sanitize_email( (string) get_theme_mod( 'contact_email', '' ) );
	if ( ! $name ) {
		$name = 'This site';
	}
	if ( ! $host ) {
		$host = 'example.com';
	}
	if ( ! is_email( $email ) ) {
		$email = 'contact@' . $host;
	}
	return array(
		'name'  => $name,
		'host'  => $host,
		'home'  => $home,
		'email' => $email,
	);
}

/**
 * About copy.
 *
 * @return string
 */
function nexora_content_about() {
	$s = nexora_seed_site_identity();
	return '<p>' . esc_html( $s['name'] ) . ' publishes practical guides with clear steps, honest limits, and no invented stories.</p>'
		. '<p>Some articles may include affiliate links. That does not change how safety notes are written. If something here is wrong or outdated, use the <a href="/contact/">contact form</a>.</p>';
}

/**
 * Contact intro.
 *
 * @return string
 */
function nexora_content_contact() {
	return <<<HTML
<p>Use the form for a question about a guide, a factual correction, or a partnership that is not cold outreach spam. Prefer a clear subject line so the reply lands in the right thread.</p>
HTML;
}

/**
 * Privacy Policy.
 *
 * @return string
 */
function nexora_content_privacy() {
	$s     = nexora_seed_site_identity();
	$name  = esc_html( $s['name'] );
	$host  = esc_html( $s['host'] );
	$home  = esc_url( $s['home'] );
	$email = esc_html( $s['email'] );
	$mail  = esc_url( 'mailto:' . $s['email'] );
	return <<<HTML
<p>This Privacy Policy explains how <strong>{$name}</strong> (<a href="{$home}">{$host}</a>) collects and uses information. We may earn a commission when you use our referral links. Those links can point to different companies and affiliate networks, not one vendor only.</p>

<h2>Who we are</h2>
<p>Privacy questions: <a href="{$mail}">{$email}</a> or the <a href="/contact/">contact form</a>.</p>

<h2>Information we collect</h2>
<p><strong>Contact form.</strong> If you message us, we receive your name, email address, subject, and message so we can reply.</p>
<p><strong>Technical data.</strong> Our host may log IP address, browser type, device info, referring page, and timestamps for security and reliability.</p>
<p><strong>Analytics.</strong> The site may use Google Analytics (often via Yoast or another plugin) to see which pages are visited. Google may set cookies under <a href="https://policies.google.com/privacy">Google’s privacy policy</a>. You can opt out with the <a href="https://tools.google.com/dlpage/gaoptout">Google Analytics opt-out browser add-on</a> or your browser’s cookie controls.</p>
<p><strong>Advertising.</strong> We may show ads through Google AdSense. Google and its partners use cookies or similar technologies to serve ads based on your prior visits to this site or other sites. You can manage ad personalization in <a href="https://adssettings.google.com/">Google Ad Settings</a>.</p>
<p><strong>Affiliate / ad tracking.</strong> When you click a referral link, your browser is sent to a vendor or affiliate network. That company may use cookies under its own privacy policy. We do not control those cookies.</p>

<h2>How we use information</h2>
<ul>
<li>Answer your messages</li>
<li>Run, secure, and improve this website</li>
<li>Attribute affiliate referrals through vendor tracking (we do not sell your contact-form data)</li>
<li>Show advertising through Google AdSense when ads are enabled</li>
<li>Meet legal obligations</li>
</ul>

<h2>Cookies</h2>
<p>We may use essential cookies for WordPress and site security. Analytics, AdSense, and affiliate partners may set their own cookies. You can control cookies in your browser; blocking some may affect tracking, ads, or features.</p>

<h2>Sharing</h2>
<p>We share data only as needed with hosting and email providers that run the site, with vendors when you choose a referral link, and with authorities when the law requires it. We do not sell mailing lists built from the contact form.</p>

<h2>Retention and security</h2>
<p>We keep contact messages as long as needed to reply and for normal business or legal records. We use reasonable security for a small informational site. No online transmission is fully secure.</p>

<h2>Children</h2>
<p>This site is for adults. We do not knowingly collect personal information from children under 16.</p>

<h2>Your choices</h2>
<p>Depending on where you live, you may ask to access, correct, or delete personal data we hold. Email <a href="{$mail}">{$email}</a> and we will respond within a reasonable time.</p>

<h2>Changes</h2>
<p>We may update this policy. The “Last updated” date on this page will change when we do.</p>

<h2>Contact</h2>
<p><a href="{$mail}">{$email}</a> · <a href="/contact/">Contact page</a></p>
HTML;
}

/**
 * Terms of Service.
 *
 * @return string
 */
function nexora_content_terms() {
	$s     = nexora_seed_site_identity();
	$name  = esc_html( $s['name'] );
	$host  = esc_html( $s['host'] );
	$email = esc_html( $s['email'] );
	$mail  = esc_url( 'mailto:' . $s['email'] );
	return <<<HTML
<p>By using <strong>{$host}</strong> ({$name}), you agree to these Terms of Service. If you do not agree, please do not use the site.</p>

<h2>What this site is</h2>
<p>{$name} publishes independent educational guides. We are not a bank, lender, lawyer, tax adviser, or professional certification body.</p>

<h2>Information only — no guarantees</h2>
<p>Everything on this site is for general information. Always confirm details with a qualified professional or the vendor’s official materials before you buy or act.</p>
<p><strong>We do not promise income, outcomes, or savings.</strong> Outcomes depend on your situation. This site does not promote “get rich” schemes or fabricated stories.</p>

<h2>Affiliate links</h2>
<p>Some buttons and links on this site are affiliate or referral links. If you purchase through them, we may earn a commission at no extra cost to you. This is explained in our footer and on the <a href="/affiliate-disclosure/">Affiliate Disclosure</a> page. You are never required to use our links.</p>

<h2>Third-party products</h2>
<p>Links to vendors go to sites we do not control. Their products, billing, support, uptime, and policies are their responsibility. {$name} is not liable for third-party charges, account issues, or outages.</p>

<h2>Acceptable use</h2>
<p>Do not misuse the site: no attacks on security, abusive scraping, spam through the contact form, or illegal use of the content.</p>

<h2>Intellectual property</h2>
<p>Unless noted otherwise, text, design, and branding on {$host} belong to the site operator. You may view pages and share links; you may not copy large portions for republication without permission.</p>

<h2>Disclaimer and limitation of liability</h2>
<p>The site is provided “as is” and “as available.” To the fullest extent allowed by law, {$name} and its operator disclaim warranties of merchantability, fitness for a particular purpose, and non-infringement, and are not liable for indirect, incidental, special, consequential, or punitive damages arising from your use of the site.</p>

<h2>Changes</h2>
<p>We may update these Terms at any time. Continued use after an update means you accept the new Terms.</p>

<h2>Contact</h2>
<p><a href="{$mail}">{$email}</a> · <a href="/contact/">Contact page</a></p>
HTML;
}

/**
 * Affiliate Disclosure (FTC / ads material connection).
 *
 * @return string
 */
function nexora_content_affiliate() {
	$s     = nexora_seed_site_identity();
	$name  = esc_html( $s['name'] );
	$host  = esc_html( $s['host'] );
	$email = esc_html( $s['email'] );
	$mail  = esc_url( 'mailto:' . $s['email'] );
	return <<<HTML
<p><strong>Disclosure:</strong> {$name} takes part in affiliate and referral programs for products or services we write about. That is a material connection under advertising and consumer-protection rules.</p>

<h2>How we may be paid</h2>
<p>If you click a link on {$host} and later buy a product or start a paid plan, <strong>we may earn a commission</strong>. In ordinary cases it does <strong>not</strong> increase the price you pay versus going to the vendor directly.</p>

<h2>Which links are affiliate links</h2>
<p>Buttons in articles, header CTAs, text links, and short addresses on this domain may be affiliate links. Which partner a button uses depends on the article.</p>

<h2>Where we say this</h2>
<ul>
<li>Short disclaimer in the <strong>footer</strong> on every page</li>
<li>This <strong>Affiliate Disclosure</strong> page</li>
<li>Related notes in the Privacy Policy and Terms of Service</li>
</ul>

<h2>Advertising</h2>
<p>If you arrive from an ad, the same affiliate relationship may apply to links on the page you land on. Our ads and pages promote educational content — not guaranteed earnings or “get rich” claims.</p>

<h2>Editorial note</h2>
<p>Compensation does not mean we invent testimonials, hide limits, or claim fake results. Always run your own due diligence.</p>

<h2>Your choice</h2>
<p>You can buy without using our links. Using our links is optional and helps fund {$host}.</p>

<h2>Questions</h2>
<p><a href="{$mail}">{$email}</a> · <a href="/contact/">Contact page</a></p>
HTML;
}
