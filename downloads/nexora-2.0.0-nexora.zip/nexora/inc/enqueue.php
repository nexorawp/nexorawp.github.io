<?php
/**
 * Styles, scripts, fonts, analytics, favicons.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Google Fonts stylesheet URL (Instrument Sans).
 *
 * @return string
 */
function nexora_fonts_url() {
	return 'https://fonts.googleapis.com/css2?family=Instrument+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap';
}

/**
 * Preconnect to font origins (+ AdSense when enabled).
 *
 * @param array  $urls          URLs.
 * @param string $relation_type Rel type.
 * @return array
 */
function nexora_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
		if ( function_exists( 'nexora_adsense_enabled' ) && nexora_adsense_enabled() ) {
			$urls[] = array(
				'href'        => 'https://pagead2.googlesyndication.com',
				'crossorigin' => 'anonymous',
			);
		}
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'nexora_resource_hints', 10, 2 );

/**
 * Preload the fonts stylesheet.
 */
function nexora_preload_fonts() {
	printf(
		'<link rel="preload" as="style" href="%s">' . "\n",
		esc_url( nexora_fonts_url() )
	);
}
add_action( 'wp_head', 'nexora_preload_fonts', 1 );

/**
 * Always use the theme dotted-globe mark as the browser tab icon.
 */
function nexora_favicon() {
	$svg    = function_exists( 'nexora_mark_url' ) ? nexora_mark_url( 'svg' ) : NEXORA_URI . '/assets/img/logo-mark.svg';
	$png32  = function_exists( 'nexora_mark_url' ) ? nexora_mark_url( '112' ) : NEXORA_URI . '/assets/img/logo-mark-112.png';
	$png512 = function_exists( 'nexora_mark_url' ) ? nexora_mark_url( '512' ) : NEXORA_URI . '/assets/img/logo-mark-512.png';
	printf( '<link rel="icon" href="%s" type="image/svg+xml">' . "\n", esc_url( $svg ) );
	printf( '<link rel="icon" href="%s" type="image/png" sizes="32x32">' . "\n", esc_url( $png32 ) );
	printf( '<link rel="icon" href="%s" type="image/png" sizes="192x192">' . "\n", esc_url( $png512 ) );
	printf( '<link rel="shortcut icon" href="%s">' . "\n", esc_url( $png32 ) );
	printf( '<link rel="apple-touch-icon" href="%s" sizes="180x180">' . "\n", esc_url( $png512 ) );
}
add_action( 'wp_head', 'nexora_favicon', 2 );

/**
 * Suppress default Site Icon tags (cropped uploads) so the theme mark wins the tab.
 *
 * @param array $meta_tags Default tags.
 * @return array
 */
function nexora_suppress_default_site_icon_tags( $meta_tags ) {
	return array();
}
add_filter( 'site_icon_meta_tags', 'nexora_suppress_default_site_icon_tags' );

/**
 * Search Console / Bing verification meta (optional — set under Appearance → Nexora).
 * Analytics: use Yoast / Site Kit; the theme does not load GA.
 */
function nexora_search_console_meta() {
	if ( is_admin() || ! function_exists( 'nexora_get_option' ) ) {
		return;
	}
	$gsc  = trim( (string) nexora_get_option( 'gsc_verification' ) );
	$bing = trim( (string) nexora_get_option( 'bing_verification' ) );
	if ( $gsc ) {
		printf( '<meta name="google-site-verification" content="%s">' . "\n", esc_attr( $gsc ) );
	}
	if ( $bing ) {
		printf( '<meta name="msvalidate.01" content="%s">' . "\n", esc_attr( $bing ) );
	}
}
add_action( 'wp_head', 'nexora_search_console_meta', 1 );

/**
 * Lightweight consent bridge for AdSense when the theme cookie banner is on.
 * Does not load Google Analytics (Yoast / Site Kit own that).
 */
function nexora_consent_bridge() {
	if ( is_admin() ) {
		return;
	}
	$consent = function_exists( 'nexora_get_option' ) && nexora_get_option( 'cookie_banner' );
	if ( $consent && function_exists( 'nexora_certified_cmp_detected' ) && nexora_certified_cmp_detected() ) {
		$consent = false;
	}

	echo "<script>\n";
	echo "window.nexoraEnableAnalytics = function(){ if (typeof gtag==='function'){ try{ gtag('consent','update',{analytics_storage:'granted'}); }catch(e){} } };\n";
	echo "window.nexoraEnableAds = function(){ if (typeof gtag==='function'){ try{ gtag('consent','update',{ad_storage:'granted',ad_user_data:'granted',ad_personalization:'granted'}); }catch(e){} } if (window.nexoraLoadAutoAds) window.nexoraLoadAutoAds(); if (window.nexoraPendingAds){ window.nexoraPendingAds.forEach(function(fn){fn();}); window.nexoraPendingAds=[]; } window.nexoraAdsConsent = true; };\n";
	echo $consent ? "window.nexoraAdsConsent = false;\n" : "window.nexoraAdsConsent = true;\n";
	echo "</script>\n";
}
add_action( 'wp_head', 'nexora_consent_bridge', 2 );

/**
 * Enqueue theme assets.
 */
function nexora_assets() {
	$css = NEXORA_DIR . '/assets/css/main.css';
	$js  = NEXORA_DIR . '/assets/js/main.js';

	wp_enqueue_style(
		'nexora-fonts',
		nexora_fonts_url(),
		array(),
		null
	);

	wp_enqueue_style(
		'nexora-main',
		NEXORA_URI . '/assets/css/main.css',
		array( 'nexora-fonts' ),
		file_exists( $css ) ? (string) filemtime( $css ) : NEXORA_VERSION
	);

	wp_enqueue_script(
		'nexora-main',
		NEXORA_URI . '/assets/js/main.js',
		array(),
		file_exists( $js ) ? (string) filemtime( $js ) : NEXORA_VERSION,
		true
	);

	$show_cookie = function_exists( 'nexora_get_option' ) ? (bool) nexora_get_option( 'cookie_banner' ) : false;
	if ( $show_cookie && function_exists( 'nexora_certified_cmp_detected' ) && nexora_certified_cmp_detected() ) {
		$show_cookie = false;
	}

	wp_localize_script(
		'nexora-main',
		'nexoraData',
		array(
			'affUrl'           => nexora_affiliate_url(),
			'push'             => nexora_is_push_page(),
			'cookieBanner'     => $show_cookie,
			'preloader'        => function_exists( 'nexora_get_option' ) ? (bool) nexora_get_option( 'preloader_enabled' ) : false,
			'preloaderTimeout' => 1200,
			'affTrack'         => function_exists( 'nexora_get_option' ) ? (bool) nexora_get_option( 'aff_track_clicks' ) : true,
			'affRest'          => esc_url_raw( rest_url( 'nexora/v1/aff-click' ) ),
			'searchRest'       => esc_url_raw( rest_url( 'nexora/v1/search' ) ),
			'postId'           => is_singular() ? (int) get_queried_object_id() : 0,
		)
	);
}
add_action( 'wp_enqueue_scripts', 'nexora_assets' );
