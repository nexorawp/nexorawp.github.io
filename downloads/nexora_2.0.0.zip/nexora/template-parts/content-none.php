<?php
/**
 * Empty loop.
 *
 * @package Nexora
 */
?>
<div class="nexora-empty">
	<p><?php esc_html_e( 'Nothing published here yet. Check back after the first note goes up.', 'nexora' ); ?></p>
</div>
