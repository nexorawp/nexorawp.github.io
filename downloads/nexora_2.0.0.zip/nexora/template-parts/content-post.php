<?php
/**
 * Post teaser — magazine card (category overlay on image).
 *
 * @package Nexora
 */

$cats = get_the_category();
$cat  = null;
foreach ( $cats as $c ) {
	if ( 'uncategorized' !== $c->slug ) {
		$cat = $c;
		break;
	}
}
?>
<article <?php post_class( 'nexora-card' ); ?>>
	<div class="nexora-card__media-wrap">
		<a class="nexora-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php
				// Soft 16:9-friendly size. CSS frame uses object-fit: cover.
				the_post_thumbnail(
					'nexora-card',
					nexora_post_thumbnail_attrs(
						null,
						array(
							'loading'            => 'lazy',
							'decoding'           => 'async',
							'sizes'              => '(max-width: 700px) 100vw, (max-width: 960px) 50vw, 420px',
							'class'              => 'nexora-card__img',
							'data-nexora-decorative' => '1',
						)
					)
				);
				?>
			<?php else : ?>
				<span class="nexora-card__placeholder"></span>
			<?php endif; ?>
		</a>
		<?php if ( $cat ) : ?>
			<a class="nexora-card__label nexora-card__label--overlay" href="<?php echo esc_url( nexora_blog_filter_url( $cat->slug ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
		<?php endif; ?>
	</div>
	<div class="nexora-card__body">
		<p class="nexora-card__meta">
			<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></time>
		</p>
		<h2 class="nexora-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>
		<div class="nexora-card__excerpt"><?php the_excerpt(); ?></div>
		<p class="nexora-card__more">
			<a class="nexora-text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'nexora' ); ?></a>
		</p>
	</div>
</article>
