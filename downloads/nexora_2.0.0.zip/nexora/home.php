<?php
/**
 * Homepage magazine: Latest(1) + Top Reads(6) + Popular(3) + Explore(2) + All Articles.
 *
 * @package Nexora
 */

get_header();

$show_split = ! is_paged();
$pack       = ( $show_split && function_exists( 'nexora_home_content_pack' ) )
	? nexora_home_content_pack()
	: null;
?>

<main id="main" class="nexora-main nexora-main--magazine">
	<?php if ( $show_split && $pack && $pack['latest'] ) : ?>
		<div class="nexora-home-hero">
			<div class="nexora-mag-atmosphere" aria-hidden="true"></div>
			<header class="nexora-wrap nexora-home-hero__intro">
				<h1><?php echo esc_html( nexora_home_h1() ); ?></h1>
				<p class="nexora-mag-hero__lede"><?php echo esc_html( nexora_home_lede() ); ?></p>
			</header>
			<section class="nexora-wrap nexora-home-split" aria-label="<?php esc_attr_e( 'Featured guides', 'nexora' ); ?>">
			<div class="nexora-home-split__latest">
				<p class="nexora-home-split__kicker"><?php esc_html_e( 'The Latest', 'nexora' ); ?></p>
				<?php
				$post = $pack['latest']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				setup_postdata( $post );
				?>
				<article <?php post_class( 'nexora-feature', $post->ID ); ?>>
					<a class="nexora-feature__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
						<?php if ( has_post_thumbnail() ) : ?>
							<?php
							the_post_thumbnail(
								'nexora-wide',
								nexora_post_thumbnail_attrs(
									$post,
									array(
										'loading'             => 'eager',
										'decoding'            => 'async',
										'fetchpriority'       => 'high',
										'sizes'               => '(max-width: 960px) 100vw, 630px',
										'class'               => 'nexora-feature__img',
										'data-nexora-decorative'  => '1',
									)
								)
							);
							?>
						<?php else : ?>
							<span class="nexora-card__placeholder"></span>
						<?php endif; ?>
					</a>
					<div class="nexora-feature__body">
						<h2 class="nexora-feature__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p class="nexora-feature__meta">
							<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></time>
							<?php
							$feature_author = trim( (string) get_the_author() );
							if ( '' !== $feature_author ) :
								?>
								<span class="nexora-card__dot" aria-hidden="true">|</span>
								<span><?php echo esc_html( $feature_author ); ?></span>
							<?php endif; ?>
						</p>
						<div class="nexora-feature__excerpt"><?php the_excerpt(); ?></div>
						<p class="nexora-feature__more">
							<a class="nexora-text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'nexora' ); ?></a>
						</p>
					</div>
				</article>
				<?php wp_reset_postdata(); ?>
			</div>

			<aside class="nexora-home-split__top" aria-labelledby="nexora-top-reads-title">
				<p id="nexora-top-reads-title" class="nexora-home-split__kicker"><?php esc_html_e( 'Top Reads', 'nexora' ); ?></p>
				<ul class="nexora-top-reads">
					<?php
					foreach ( $pack['top'] as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
						setup_postdata( $post );
						?>
						<li class="nexora-top-reads__item">
							<?php
							$mins = function_exists( 'nexora_reading_time' ) ? (int) nexora_reading_time() : 0;
							$cats = get_the_category();
							$cat  = ( $cats && ! is_wp_error( $cats ) ) ? $cats[0] : null;
							?>
							<a class="nexora-top-reads__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php
									the_post_thumbnail(
										'nexora-thumb',
										nexora_post_thumbnail_attrs(
											$post,
											array(
												'loading'            => 'lazy',
												'decoding'           => 'async',
												'sizes'              => '178px',
												'class'              => 'nexora-top-reads__img',
												'data-nexora-decorative' => '1',
											)
										)
									);
									?>
								<?php else : ?>
									<span class="nexora-card__placeholder"></span>
								<?php endif; ?>
							</a>
							<div class="nexora-top-reads__body">
								<h3 class="nexora-top-reads__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<div class="nexora-top-reads__info">
									<p class="nexora-top-reads__meta">
										<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date( 'M Y' ) ); ?></time>
										<?php if ( $mins > 0 ) : ?>
											<span class="nexora-card__dot" aria-hidden="true">•</span>
											<span>
												<?php
												echo esc_html(
													sprintf(
														/* translators: %d: minutes */
														_n( '%d min', '%d min', $mins, 'nexora' ),
														$mins
													)
												);
												?>
											</span>
										<?php endif; ?>
										<?php if ( $cat ) : ?>
											<a class="nexora-top-reads__badge" href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
										<?php endif; ?>
									</p>
								</div>
							</div>
						</li>
						<?php
					}
					wp_reset_postdata();
					?>
				</ul>
			</aside>
			</section>
		</div>
	<?php else : ?>
		<div class="nexora-mag-atmosphere" aria-hidden="true"></div>
		<header class="nexora-mag-hero nexora-mag-hero--compact">
			<div class="nexora-wrap">
				<h1><?php echo esc_html( nexora_home_h1() ); ?></h1>
				<p class="nexora-mag-hero__lede"><?php echo esc_html( nexora_home_lede() ); ?></p>
			</div>
		</header>
	<?php endif; ?>

	<?php if ( $show_split && $pack && ! nexora_current_blog_cat() ) : ?>
		<?php if ( function_exists( 'nexora_home_popular_posts' ) ) : ?>
			<?php nexora_home_popular_posts( $pack['popular'] ); ?>
		<?php endif; ?>
		<?php if ( function_exists( 'nexora_home_explore_topics' ) ) : ?>
			<?php nexora_home_explore_topics( $pack['explore'] ); ?>
		<?php endif; ?>
	<?php endif; ?>

	<div class="nexora-wrap nexora-magazine">
		<?php nexora_blog_filters( array( 'search' => true ) ); ?>

		<?php if ( have_posts() ) : ?>
			<?php
			if ( function_exists( 'nexora_magazine_loop_with_ads' ) ) {
				nexora_magazine_loop_with_ads();
			}
			global $wp_query;
			if ( $wp_query->max_num_pages > 1 ) :
				?>
			<nav class="nexora-pagination" aria-label="<?php esc_attr_e( 'Blog pages', 'nexora' ); ?>">
				<?php
				the_posts_pagination(
					array(
						'mid_size'  => 2,
						'prev_text' => __( 'Newer', 'nexora' ),
						'next_text' => __( 'Older', 'nexora' ),
					)
				);
				?>
			</nav>
			<?php endif; ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>

</main>

<?php
get_footer();
