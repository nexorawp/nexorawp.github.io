<?php
/**
 * Gutenberg monetization blocks + affiliate article patterns.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register editor script once.
 */
function nexora_register_block_assets() {
	$js = NEXORA_DIR . '/assets/js/blocks-editor.js';
	if ( ! file_exists( $js ) ) {
		return;
	}
	wp_register_script(
		'nexora-blocks-editor',
		NEXORA_URI . '/assets/js/blocks-editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
		(string) filemtime( $js ),
		true
	);
}
add_action( 'init', 'nexora_register_block_assets', 5 );

/**
 * Register blocks (server-rendered).
 */
function nexora_register_blocks() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}

	register_block_type(
		'nexora/ad',
		array(
			'api_version'     => 2,
			'title'           => __( 'Nexora Ad', 'nexora' ),
			'category'        => 'widgets',
			'icon'            => 'megaphone',
			'editor_script'   => 'nexora-blocks-editor',
			'attributes'      => array(
				'placement' => array( 'type' => 'string', 'default' => 'end_content' ),
				'slot'      => array( 'type' => 'string', 'default' => '' ),
			),
			'render_callback' => static function ( $attrs ) {
				$placement = sanitize_key( $attrs['placement'] ?? 'end_content' );
				if ( $placement && function_exists( 'nexora_render_ad_placement' ) ) {
					$html = nexora_render_ad_placement( $placement );
					if ( $html ) {
						return $html;
					}
				}
				$slot = preg_replace( '/\D+/', '', (string) ( $attrs['slot'] ?? '' ) );
				return function_exists( 'nexora_adsense_unit_html' ) ? nexora_adsense_unit_html( $slot, 'auto' ) : '';
			},
		)
	);

	register_block_type(
		'nexora/product',
		array(
			'api_version'     => 2,
			'title'           => __( 'Affiliate Product Card', 'nexora' ),
			'category'        => 'widgets',
			'icon'            => 'cart',
			'editor_script'   => 'nexora-blocks-editor',
			'attributes'      => array(
				'name'     => array( 'type' => 'string', 'default' => '' ),
				'url'      => array( 'type' => 'string', 'default' => '' ),
				'image'    => array( 'type' => 'string', 'default' => '' ),
				'pros'     => array( 'type' => 'string', 'default' => '' ),
				'cons'     => array( 'type' => 'string', 'default' => '' ),
				'features' => array( 'type' => 'string', 'default' => '' ),
				'cta'      => array( 'type' => 'string', 'default' => 'Check price' ),
				'badge'    => array( 'type' => 'string', 'default' => '' ),
				'body'     => array( 'type' => 'string', 'default' => '' ),
			),
			'render_callback' => static function ( $attrs ) {
				if ( ! shortcode_exists( 'nexora_product' ) ) {
					return '';
				}
				$atts = array(
					'name'     => $attrs['name'] ?? '',
					'url'      => $attrs['url'] ?? '',
					'image'    => $attrs['image'] ?? '',
					'pros'     => $attrs['pros'] ?? '',
					'cons'     => $attrs['cons'] ?? '',
					'features' => $attrs['features'] ?? '',
					'cta'      => $attrs['cta'] ?? 'Check price',
					'badge'    => $attrs['badge'] ?? '',
				);
				return nexora_product_shortcode( $atts, $attrs['body'] ?? '' );
			},
		)
	);

	register_block_type(
		'nexora/compare',
		array(
			'api_version'     => 2,
			'title'           => __( 'Affiliate Comparison Table', 'nexora' ),
			'category'        => 'widgets',
			'icon'            => 'editor-table',
			'editor_script'   => 'nexora-blocks-editor',
			'attributes'      => array(
				'rows' => array( 'type' => 'string', 'default' => "Product A|Why it wins|https://example.com\nProduct B|Budget pick|https://example.com" ),
			),
			'render_callback' => static function ( $attrs ) {
				if ( ! shortcode_exists( 'nexora_compare' ) ) {
					return '';
				}
				return nexora_compare_shortcode( array(), $attrs['rows'] ?? '' );
			},
		)
	);

	register_block_type(
		'nexora/disclosure',
		array(
			'api_version'     => 2,
			'title'           => __( 'Affiliate Disclosure', 'nexora' ),
			'category'        => 'widgets',
			'icon'            => 'info-outline',
			'editor_script'   => 'nexora-blocks-editor',
			'render_callback' => static function () {
				$text = function_exists( 'nexora_affiliate_block_disclosure' )
					? nexora_affiliate_block_disclosure()
					: nexora_default_disclosure();
				return '<p class="nexora-disclosure-block"><em>' . esc_html( $text ) . '</em></p>';
			},
		)
	);
}
add_action( 'init', 'nexora_register_blocks' );

/**
 * Keep legacy paulworld/* block names working in saved post HTML.
 */
function nexora_register_legacy_block_aliases() {
	if ( ! function_exists( 'register_block_type' ) || ! function_exists( 'WP_Block_Type_Registry' ) ) {
		return;
	}
	$registry = WP_Block_Type_Registry::get_instance();
	$map      = array(
		'paulworld/ad'         => 'nexora/ad',
		'paulworld/product'    => 'nexora/product',
		'paulworld/compare'    => 'nexora/compare',
		'paulworld/disclosure' => 'nexora/disclosure',
	);
	foreach ( $map as $legacy => $current ) {
		if ( $registry->is_registered( $legacy ) || ! $registry->is_registered( $current ) ) {
			continue;
		}
		$block = $registry->get_registered( $current );
		if ( ! $block ) {
			continue;
		}
		register_block_type(
			$legacy,
			array(
				'api_version'     => $block->api_version,
				'title'           => $block->title . ' (legacy)',
				'category'        => $block->category,
				'icon'            => $block->icon,
				'editor_script'   => 'nexora-blocks-editor',
				'attributes'      => $block->attributes,
				'render_callback' => $block->render_callback,
			)
		);
	}
}
add_action( 'init', 'nexora_register_legacy_block_aliases', 20 );

/**
 * Register affiliate article block patterns.
 */
function nexora_register_patterns() {
	if ( ! function_exists( 'register_block_pattern' ) ) {
		return;
	}
	register_block_pattern_category(
		'nexora-affiliate',
		array( 'label' => __( 'Nexora Affiliate', 'nexora' ) )
	);

	$disclosure = '<!-- wp:nexora/disclosure /-->';

	register_block_pattern(
		'nexora/best-products',
		array(
			'title'       => __( 'Best Products roundup', 'nexora' ),
			'categories'  => array( 'nexora-affiliate' ),
			'description' => __( 'Starter for a “best of” affiliate roundup.', 'nexora' ),
			'content'     => $disclosure . '
<!-- wp:heading {"level":2} --><h2>Quick picks</h2><!-- /wp:heading -->
<!-- wp:list --><ul><li>Best overall: </li><li>Best budget: </li><li>Best for beginners: </li></ul><!-- /wp:list -->
<!-- wp:heading {"level":2} --><h2>Best overall</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Who it fits, what you get, and who should skip it.</p><!-- /wp:paragraph -->
<!-- wp:nexora/product {"name":"Product name","url":"https://www.amazon.com/","cta":"Check price","badge":"Best overall"} /-->
<!-- wp:heading {"level":2} --><h2>How we chose</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Criteria: claims, price, fit, and what to skip.</p><!-- /wp:paragraph -->',
		)
	);

	register_block_pattern(
		'nexora/top-10',
		array(
			'title'       => __( 'Top 10 comparison', 'nexora' ),
			'categories'  => array( 'nexora-affiliate' ),
			'content'     => $disclosure . '
<!-- wp:heading {"level":2} --><h2>Top 10 at a glance</h2><!-- /wp:heading -->
<!-- wp:nexora/compare {"rows":"1. Product|Best for X|https://example.com\\n2. Product|Best for Y|https://example.com"} /-->
<!-- wp:heading {"level":2} --><h2>Detailed notes</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Expand each pick with who it fits and what to skip.</p><!-- /wp:paragraph -->',
		)
	);

	register_block_pattern(
		'nexora/product-review',
		array(
			'title'       => __( 'Product review', 'nexora' ),
			'categories'  => array( 'nexora-affiliate' ),
			'content'     => $disclosure . '
<!-- wp:heading {"level":2} --><h2>What it is</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Plain-English summary of the product.</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":2} --><h2>Pros and cons</h2><!-- /wp:heading -->
<!-- wp:nexora/product {"name":"Product name","url":"https://www.amazon.com/","pros":"Clear claim|Good fit for X","cons":"Skip if Y","cta":"See current price"} /-->
<!-- wp:heading {"level":2} --><h2>Who should buy</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>And who should skip it.</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":2} --><h2>Verdict</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Worth it if… Not worth it if…</p><!-- /wp:paragraph -->',
		)
	);

	register_block_pattern(
		'nexora/buying-guide',
		array(
			'title'       => __( 'Buying guide', 'nexora' ),
			'categories'  => array( 'nexora-affiliate' ),
			'content'     => $disclosure . '
<!-- wp:heading {"level":2} --><h2>What to check before you buy</h2><!-- /wp:heading -->
<!-- wp:list --><ul><li>Fit / use case</li><li>Price band</li><li>Support / returns</li><li>What to skip</li></ul><!-- /wp:list -->
<!-- wp:heading {"level":2} --><h2>Recommended picks</h2><!-- /wp:heading -->
<!-- wp:nexora/product {"name":"Recommended pick","url":"https://www.amazon.com/","badge":"Editor pick"} /-->
<!-- wp:heading {"level":2} --><h2>FAQ</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Answer the searches people ask before paying.</p><!-- /wp:paragraph -->',
		)
	);

	register_block_pattern(
		'nexora/vs-comparison',
		array(
			'title'       => __( 'Product A vs Product B', 'nexora' ),
			'categories'  => array( 'nexora-affiliate' ),
			'content'     => $disclosure . '
<!-- wp:heading {"level":2} --><h2>Quick verdict</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Choose A if… Choose B if…</p><!-- /wp:paragraph -->
<!-- wp:nexora/compare {"rows":"Product A|Wins on X|https://example.com\\nProduct B|Wins on Y|https://example.com"} /-->
<!-- wp:heading {"level":2} --><h2>Side-by-side</h2><!-- /wp:heading -->
<!-- wp:columns --><div class="wp-block-columns"><!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3} --><h3>Product A</h3><!-- /wp:heading --><!-- wp:nexora/product {"name":"Product A","url":"https://www.amazon.com/"} /--></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3} --><h3>Product B</h3><!-- /wp:heading --><!-- wp:nexora/product {"name":"Product B","url":"https://www.amazon.com/"} /--></div><!-- /wp:column --></div><!-- /wp:columns -->',
		)
	);
}
add_action( 'init', 'nexora_register_patterns' );
