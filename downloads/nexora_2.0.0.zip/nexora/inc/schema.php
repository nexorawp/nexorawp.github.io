<?php
/**
 * Organization, WebSite, Article, FAQPage, and BreadcrumbList JSON-LD.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Organization logo absolute URL for schema.
 *
 * @return string
 */
function nexora_schema_logo_url() {
	if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) {
		$id = (int) get_theme_mod( 'custom_logo' );
		if ( $id ) {
			$url = wp_get_attachment_image_url( $id, 'full' );
			if ( $url ) {
				return $url;
			}
		}
	}
	return '';
}

/**
 * Breadcrumb trail for the current request.
 *
 * @return array<int,array{name:string,url:string}>
 */
function nexora_breadcrumb_items() {
	$items   = array();
	$items[] = array(
		'name' => __( 'Home', 'nexora' ),
		'url'  => home_url( '/' ),
	);

	if ( is_singular( 'post' ) ) {
		$cats = get_the_category();
		if ( $cats && ! is_wp_error( $cats ) ) {
			$cat = $cats[0];
			if ( $cat && 'uncategorized' !== $cat->slug && function_exists( 'nexora_blog_filter_url' ) ) {
				$items[] = array(
					'name' => $cat->name,
					'url'  => nexora_blog_filter_url( $cat->slug ),
				);
			}
		}
		$items[] = array(
			'name' => wp_strip_all_tags( get_the_title() ),
			'url'  => get_permalink(),
		);
	} elseif ( is_page() && ! is_front_page() ) {
		$items[] = array(
			'name' => wp_strip_all_tags( get_the_title() ),
			'url'  => get_permalink(),
		);
	} elseif ( function_exists( 'nexora_current_blog_cat' ) ) {
		$slug = nexora_current_blog_cat();
		if ( $slug ) {
			$cat = get_category_by_slug( $slug );
			if ( $cat ) {
				$items[] = array(
					'name' => $cat->name,
					'url'  => function_exists( 'nexora_blog_filter_url' ) ? nexora_blog_filter_url( $cat->slug ) : home_url( '/' ),
				);
			}
		}
	}

	return $items;
}

/**
 * Visible breadcrumb nav for singles and pages.
 * Toggled in Nexora settings (default off).
 */
function nexora_breadcrumbs() {
	if ( function_exists( 'nexora_get_option' ) && ! nexora_get_option( 'article_breadcrumbs' ) ) {
		return;
	}
	if ( is_front_page() || is_home() ) {
		$slug = function_exists( 'nexora_current_blog_cat' ) ? nexora_current_blog_cat() : '';
		if ( ! $slug && ! is_singular() ) {
			return;
		}
	}
	if ( ! is_singular() && ! ( is_home() && function_exists( 'nexora_current_blog_cat' ) && nexora_current_blog_cat() ) ) {
		return;
	}

	$items = nexora_breadcrumb_items();
	if ( count( $items ) < 2 ) {
		return;
	}
	?>
	<nav class="nexora-breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'nexora' ); ?>">
		<ol class="nexora-breadcrumbs__list">
			<?php foreach ( $items as $i => $item ) : ?>
				<li class="nexora-breadcrumbs__item">
					<?php if ( $i < count( $items ) - 1 ) : ?>
						<a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['name'] ); ?></a>
					<?php else : ?>
						<span aria-current="page"><?php echo esc_html( $item['name'] ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</nav>
	<?php
}

/**
 * Print JSON-LD in the footer.
 */
function nexora_schema() {
	if ( function_exists( 'nexora_seo_plugin_active' ) && nexora_seo_plugin_active() ) {
		return;
	}
	$url  = home_url( '/' );
	$name = get_bloginfo( 'name' );
	$desc = function_exists( 'nexora_seo_blurb' ) ? nexora_seo_blurb() : get_bloginfo( 'description' );
	$logo = nexora_schema_logo_url();

	$org = array(
		'@type' => 'Organization',
		'@id'   => $url . '#organization',
		'name'  => $name,
		'url'   => $url,
		'email' => nexora_contact_email(),
	);
	if ( $logo ) {
		$org['logo'] = array(
			'@type' => 'ImageObject',
			'url'   => $logo,
		);
		$org['image'] = $logo;
	}

	$graph = array(
		$org,
		array(
			'@type'           => 'WebSite',
			'@id'             => $url . '#website',
			'url'             => $url,
			'name'            => $name,
			'description'     => $desc,
			'publisher'       => array( '@id' => $url . '#organization' ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => home_url( '/?s={search_term_string}' ),
				'query-input' => 'required name=search_term_string',
			),
		),
	);

	if ( is_singular( 'post' ) ) {
		$post_id = get_queried_object_id();
		$image   = get_the_post_thumbnail_url( $post_id, 'full' );
		if ( ! $image ) {
			$image = $logo;
		}
		$author_name = get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) );
		$article     = array(
			'@type'            => 'Article',
			'@id'              => get_permalink( $post_id ) . '#article',
			'headline'         => wp_strip_all_tags( get_the_title( $post_id ) ),
			'description'      => function_exists( 'nexora_seo_for_request' ) ? ( nexora_seo_for_request()['description'] ?? '' ) : '',
			'datePublished'    => get_the_date( DATE_W3C, $post_id ),
			'dateModified'     => get_the_modified_date( DATE_W3C, $post_id ),
			'mainEntityOfPage' => get_permalink( $post_id ),
			'author'           => array(
				'@type' => 'Person',
				'name'  => $author_name ? $author_name : $name,
			),
			'publisher'        => array( '@id' => $url . '#organization' ),
			'isPartOf'         => array( '@id' => $url . '#website' ),
		);
		if ( $image ) {
			$article['image'] = array( $image );
		}
		$graph[] = $article;

		if ( function_exists( 'nexora_faq_pairs' ) ) {
			$faqs = nexora_faq_pairs( $post_id );
			if ( count( $faqs ) >= 2 ) {
				$entities = array();
				foreach ( $faqs as $faq ) {
					$entities[] = array(
						'@type'          => 'Question',
						'name'           => $faq['question'],
						'acceptedAnswer' => array(
							'@type' => 'Answer',
							'text'  => $faq['answer'],
						),
					);
				}
				$graph[] = array(
					'@type'      => 'FAQPage',
					'@id'        => get_permalink( $post_id ) . '#faq',
					'mainEntity' => $entities,
					'isPartOf'   => array( '@id' => get_permalink( $post_id ) . '#article' ),
				);
			}
		}
	}

	$crumbs = nexora_breadcrumb_items();
	if ( count( $crumbs ) > 1 ) {
		$list = array();
		foreach ( $crumbs as $i => $item ) {
			$list[] = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'name'     => $item['name'],
				'item'     => $item['url'],
			);
		}
		$graph[] = array(
			'@type'           => 'BreadcrumbList',
			'@id'             => ( is_singular() ? get_permalink() : $url ) . '#breadcrumb',
			'itemListElement' => $list,
		);
	}

	echo '<script type="application/ld+json">' . wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	) . '</script>' . "\n";
}
add_action( 'wp_footer', 'nexora_schema', 20 );
