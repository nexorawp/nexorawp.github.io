<?php
/**
 * Lightweight cookie preference banner + Consent Mode v2 helpers.
 *
 * Not a certified CMP. For EEA/UK/CH traffic use a Google-certified CMP.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Privacy / cookie policy URLs.
 *
 * @param string $which privacy|cookie.
 * @return string
 */
function nexora_policy_url( $which = 'privacy' ) {
	$key = 'privacy' === $which ? 'privacy_policy_url' : 'cookie_policy_url';
	$url = trim( (string) nexora_get_option( $key ) );
	if ( $url ) {
		return esc_url( $url );
	}
	if ( 'privacy' === $which ) {
		return esc_url( nexora_page_url( 'privacy-policy' ) );
	}
	return esc_url( nexora_page_url( 'privacy-policy' ) );
}

/**
 * Detect a known certified / third-party CMP already managing consent.
 *
 * When true, the theme banner stays hidden to avoid double prompts.
 *
 * @return bool
 */
function nexora_certified_cmp_detected() {
	$detected = false;

	// Prefer runtime markers (safe on front-end without loading plugin.php).
	if (
		defined( 'CMP_VERSION' ) ||
		defined( 'CLI_COOKIE_BAR' ) ||
		defined( 'COOKIEBOT_PLUGIN_URL' ) ||
		defined( 'cmplz_version' ) ||
		class_exists( 'Cookiebot_WP', false ) ||
		class_exists( 'COMPLIANZ', false ) ||
		class_exists( 'Cookie_Law_Info', false ) ||
		function_exists( 'cookiebot_active' ) ||
		function_exists( 'cmplz_has_consent' ) ||
		function_exists( 'cookieyes_plugin_is_active' )
	) {
		$detected = true;
	}

	/**
	 * Filter CMP detection for coexistence with custom consent stacks.
	 *
	 * @param bool $detected Whether a CMP is present.
	 */
	return (bool) apply_filters( 'nexora_certified_cmp_detected', $detected );
}

/**
 * Print banner markup in footer.
 */
function nexora_cookie_banner() {
	if ( is_admin() || ! nexora_get_option( 'cookie_banner' ) ) {
		return;
	}
	if ( nexora_certified_cmp_detected() ) {
		return;
	}
	$privacy = nexora_policy_url( 'privacy' );
	$name    = get_bloginfo( 'name', 'display' );
	?>
	<div class="nexora-cookie" data-nexora-cookie hidden>
		<div class="nexora-cookie__inner nexora-wrap">
			<p class="nexora-cookie__text">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: site name */
						__( '%s uses essential cookies to keep the site fast and secure. Optional analytics measure what readers use; ads cookies may personalize ads — only if you allow them.', 'nexora' ),
						$name ? $name : __( 'This site', 'nexora' )
					)
				);
				?>
				<a href="<?php echo esc_url( $privacy ); ?>"><?php esc_html_e( 'Privacy policy', 'nexora' ); ?></a>
			</p>
			<div class="nexora-cookie__actions">
				<button type="button" class="nexora-btn nexora-btn--ghost" data-nexora-cookie-reject><?php esc_html_e( 'Decline', 'nexora' ); ?></button>
				<button type="button" class="nexora-btn nexora-btn--primary" data-nexora-cookie-accept><?php esc_html_e( 'Accept', 'nexora' ); ?></button>
			</div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'nexora_cookie_banner', 5 );

/**
 * Gate Analytics behind consent when banner is enabled.
 */
function nexora_google_tag_consent_aware() {
	// Replaced enqueue google tag — see enqueue.php call sites.
}
