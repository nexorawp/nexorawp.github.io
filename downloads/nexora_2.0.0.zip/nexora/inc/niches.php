<?php
/**
 * Universal niche color presets (presentation only).
 *
 * Switching niches must NEVER mutate posts, taxonomies, media, site identity,
 * SEO, ads, or affiliate configuration — only the `niche_preset` theme_mod
 * and derived CSS custom properties.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Niche preset definitions (CSS token maps).
 *
 * @return array<string,array{label:string,description:string,tokens:array<string,string>}>
 */
function nexora_niche_presets() {
	return array(
		'trades'              => array(
			'label'       => __( 'Mechanics & Fitting', 'nexora' ),
			'description' => __( 'Teal magazine — plumbing, cars, pipes, parts, and DIY repair in one place.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F4F7FB',
				'surface'    => '#FFFFFF',
				'ink'        => '#1d1d1d',
				'ink-strong' => '#151c22',
				'muted'      => '#5B677A',
				'line'       => '#D7DEE8',
				'brand'      => '#0F766E',
				'brand-2'    => '#115E59',
				'accent'     => '#F59E0B',
			),
		),
		'pets'                => array(
			'label'       => __( 'Pets & Animals', 'nexora' ),
			'description' => __( 'Warm coral and soft sand.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#FFF8F4',
				'surface'    => '#FFFFFF',
				'ink'        => '#2A211C',
				'ink-strong' => '#1A1411',
				'muted'      => '#7A655C',
				'line'       => '#E8D9D0',
				'brand'      => '#C2410C',
				'brand-2'    => '#9A3412',
				'accent'     => '#EA580C',
			),
		),
		'pregnancy'           => array(
			'label'       => __( 'Pregnancy & Parenting', 'nexora' ),
			'description' => __( 'Soft rose and calm mauve.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#FBF7FA',
				'surface'    => '#FFFFFF',
				'ink'        => '#2D2430',
				'ink-strong' => '#1C1520',
				'muted'      => '#74657A',
				'line'       => '#E6DCE8',
				'brand'      => '#9D174D',
				'brand-2'    => '#831843',
				'accent'     => '#DB2777',
			),
		),
		'technology'          => array(
			'label'       => __( 'Technology', 'nexora' ),
			'description' => __( 'Cool indigo on slate.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F5F7FC',
				'surface'    => '#FFFFFF',
				'ink'        => '#1E2433',
				'ink-strong' => '#111827',
				'muted'      => '#64748B',
				'line'       => '#D8DEEA',
				'brand'      => '#4338CA',
				'brand-2'    => '#3730A3',
				'accent'     => '#6366F1',
			),
		),
		'finance'             => array(
			'label'       => __( 'Finance', 'nexora' ),
			'description' => __( 'Deep navy with gold accent.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F5F7FA',
				'surface'    => '#FFFFFF',
				'ink'        => '#1A2332',
				'ink-strong' => '#0F172A',
				'muted'      => '#5B6B7C',
				'line'       => '#D5DCE5',
				'brand'      => '#1E3A5F',
				'brand-2'    => '#0F2744',
				'accent'     => '#CA8A04',
			),
		),
		'health'              => array(
			'label'       => __( 'Health & Wellness', 'nexora' ),
			'description' => __( 'Fresh green and clean white.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F4FAF6',
				'surface'    => '#FFFFFF',
				'ink'        => '#1C2A22',
				'ink-strong' => '#102016',
				'muted'      => '#5C7264',
				'line'       => '#D5E5DA',
				'brand'      => '#15803D',
				'brand-2'    => '#166534',
				'accent'     => '#22C55E',
			),
		),
		'food'                => array(
			'label'       => __( 'Food & Recipes', 'nexora' ),
			'description' => __( 'Tomato red and warm cream.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#FFF9F5',
				'surface'    => '#FFFFFF',
				'ink'        => '#2C211C',
				'ink-strong' => '#1A120E',
				'muted'      => '#7A6558',
				'line'       => '#EADDD3',
				'brand'      => '#B91C1C',
				'brand-2'    => '#991B1B',
				'accent'     => '#EA580C',
			),
		),
		'travel'              => array(
			'label'       => __( 'Travel', 'nexora' ),
			'description' => __( 'Ocean blue and sky.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F3F8FC',
				'surface'    => '#FFFFFF',
				'ink'        => '#1A2836',
				'ink-strong' => '#0C1929',
				'muted'      => '#5A7186',
				'line'       => '#D3E0EC',
				'brand'      => '#0369A1',
				'brand-2'    => '#075985',
				'accent'     => '#0EA5E9',
			),
		),
		'lifestyle'           => array(
			'label'       => __( 'Lifestyle', 'nexora' ),
			'description' => __( 'Soft lavender and charcoal.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F8F6FB',
				'surface'    => '#FFFFFF',
				'ink'        => '#26222E',
				'ink-strong' => '#16131C',
				'muted'      => '#6B6478',
				'line'       => '#E0DAE8',
				'brand'      => '#7C3AED',
				'brand-2'    => '#6D28D9',
				'accent'     => '#A78BFA',
			),
		),
		'home-garden'         => array(
			'label'       => __( 'Home & Garden', 'nexora' ),
			'description' => __( 'Leaf green and clay.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F6FAF5',
				'surface'    => '#FFFFFF',
				'ink'        => '#22291F',
				'ink-strong' => '#141A12',
				'muted'      => '#66705F',
				'line'       => '#D8E4D4',
				'brand'      => '#4D7C0F',
				'brand-2'    => '#3F6212',
				'accent'     => '#A16207',
			),
		),
		'education'           => array(
			'label'       => __( 'Education', 'nexora' ),
			'description' => __( 'Academic blue and amber.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F5F7FB',
				'surface'    => '#FFFFFF',
				'ink'        => '#1E2430',
				'ink-strong' => '#111827',
				'muted'      => '#5B677A',
				'line'       => '#D7DEE8',
				'brand'      => '#1D4ED8',
				'brand-2'    => '#1E40AF',
				'accent'     => '#F59E0B',
			),
		),
		'news-magazine'       => array(
			'label'       => __( 'News & Magazine', 'nexora' ),
			'description' => __( 'Ink black with crimson accent.', 'nexora' ),
			'tokens'      => array(
				'bg'         => '#F7F7F5',
				'surface'    => '#FFFFFF',
				'ink'        => '#1A1A1A',
				'ink-strong' => '#0A0A0A',
				'muted'      => '#5C5C5C',
				'line'       => '#D4D4D4',
				'brand'      => '#B91C1C',
				'brand-2'    => '#7F1D1D',
				'accent'     => '#DC2626',
			),
		),
	);
}

/**
 * Default niche slug (Mechanics & Fitting = teal trades palette).
 *
 * @return string
 */
function nexora_default_niche() {
	return 'trades';
}

/**
 * Map legacy niche slugs to current keys.
 *
 * @param string $slug Raw slug.
 * @return string
 */
function nexora_normalize_niche_slug( $slug ) {
	$slug = sanitize_key( (string) $slug );
	$aliases = array(
		'automotive' => 'trades', // pre–Mechanics & Fitting name
	);
	if ( isset( $aliases[ $slug ] ) ) {
		return $aliases[ $slug ];
	}
	return $slug;
}

/**
 * Active niche slug (sanitized).
 *
 * @return string
 */
function nexora_active_niche() {
	$slug    = nexora_normalize_niche_slug( (string) nexora_get_option( 'niche_preset' ) );
	$presets = nexora_niche_presets();
	if ( isset( $presets[ $slug ] ) ) {
		return $slug;
	}
	return nexora_default_niche();
}

/**
 * Token map for the active niche.
 *
 * @return array<string,string>
 */
function nexora_active_niche_tokens() {
	$presets = nexora_niche_presets();
	$slug    = nexora_active_niche();
	return isset( $presets[ $slug ]['tokens'] ) ? $presets[ $slug ]['tokens'] : $presets[ nexora_default_niche() ]['tokens'];
}

/**
 * Inline CSS custom properties for the active niche.
 * Layout CSS stays identical — only colors change.
 */
function nexora_niche_inline_css() {
	$tokens = nexora_active_niche_tokens();
	$map    = array(
		'bg'         => '--bg',
		'surface'    => '--surface',
		'ink'        => '--ink',
		'ink-strong' => '--ink-strong',
		'muted'      => '--muted',
		'line'       => '--line',
		'brand'      => '--brand',
		'brand-2'    => '--brand-2',
		'accent'     => '--accent',
	);
	$rules = array();
	foreach ( $map as $key => $var ) {
		if ( empty( $tokens[ $key ] ) ) {
			continue;
		}
		$color = sanitize_hex_color( $tokens[ $key ] );
		if ( ! $color ) {
			continue;
		}
		$rules[] = $var . ':' . $color;
	}
	if ( ! $rules ) {
		return;
	}
	$css = ':root{' . implode( ';', $rules ) . '}';
	wp_add_inline_style( 'nexora-main', $css );
}
add_action( 'wp_enqueue_scripts', 'nexora_niche_inline_css', 20 );

/**
 * Body class for the active niche (hooks / QA).
 *
 * @param string[] $classes Classes.
 * @return string[]
 */
function nexora_niche_body_class( $classes ) {
	$classes[] = 'nexora-niche-' . sanitize_html_class( nexora_active_niche() );
	return $classes;
}
add_filter( 'body_class', 'nexora_niche_body_class' );
