<?php
/**
 * Native contact form → wp_mail (webmail / SMTP).
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handle public contact submissions.
 */
function nexora_handle_contact() {
	$redirect = wp_get_referer() ? wp_get_referer() : home_url( '/contact/' );
	$redirect = remove_query_arg( 'contact', $redirect );

	if ( ! isset( $_POST['nexora_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nexora_contact_nonce'] ) ), 'nexora_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'contact', 'error', $redirect ) );
		exit;
	}

	// Honeypot: bots fill this; humans never see it.
	if ( ! empty( $_POST['nexora_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'contact', 'sent', $redirect ) );
		exit;
	}

	$ip_key = 'nexora_cf_' . md5( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown' );
	if ( get_transient( $ip_key ) ) {
		wp_safe_redirect( add_query_arg( 'contact', 'error', $redirect ) );
		exit;
	}

	$name    = isset( $_POST['nexora_name'] ) ? sanitize_text_field( wp_unslash( $_POST['nexora_name'] ) ) : '';
	$email   = isset( $_POST['nexora_email'] ) ? sanitize_email( wp_unslash( $_POST['nexora_email'] ) ) : '';
	$subject = isset( $_POST['nexora_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['nexora_subject'] ) ) : '';
	$message = isset( $_POST['nexora_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['nexora_message'] ) ) : '';

	if ( ! $name || ! $email || ! is_email( $email ) || ! $subject || ! $message ) {
		wp_safe_redirect( add_query_arg( 'contact', 'invalid', $redirect ) );
		exit;
	}

	if ( strlen( $name ) > 120 || strlen( $subject ) > 180 || strlen( $message ) > 5000 ) {
		wp_safe_redirect( add_query_arg( 'contact', 'invalid', $redirect ) );
		exit;
	}

	$to      = nexora_contact_email();
	$prefix  = '[' . wp_parse_url( home_url(), PHP_URL_HOST ) . '] ';
	$body    = sprintf(
		"Name: %s\nEmail: %s\nSubject: %s\n\n%s\n",
		$name,
		$email,
		$subject,
		$message
	);
	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'Reply-To: ' . $name . ' <' . $email . '>',
	);

	$sent = wp_mail( $to, $prefix . $subject, $body, $headers );

	if ( $sent ) {
		set_transient( $ip_key, 1, 60 );
		wp_safe_redirect( add_query_arg( 'contact', 'sent', $redirect ) );
		exit;
	}

	wp_safe_redirect( add_query_arg( 'contact', 'error', $redirect ) );
	exit;
}
add_action( 'admin_post_nopriv_nexora_contact', 'nexora_handle_contact' );
add_action( 'admin_post_nexora_contact', 'nexora_handle_contact' );

/**
 * Same-page status from the redirect query arg.
 *
 * @return string sent|error|invalid|''
 */
function nexora_contact_status() {
	if ( empty( $_GET['contact'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return '';
	}
	$status = sanitize_key( wp_unslash( $_GET['contact'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	return in_array( $status, array( 'sent', 'error', 'invalid' ), true ) ? $status : '';
}
