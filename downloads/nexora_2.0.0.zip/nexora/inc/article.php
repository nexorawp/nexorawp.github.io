<?php
/**
 * Article reading aids: time, TOC, author box.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Estimated reading time in minutes.
 *
 * @param int|null $post_id Post ID.
 * @return int
 */
function nexora_reading_time( $post_id = null ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	$text    = (string) get_post_field( 'post_content', $post_id );
	$words   = str_word_count( wp_strip_all_tags( $text ) );
	return max( 1, (int) ceil( $words / 220 ) );
}

/**
 * Build TOC from main (h2) headings; injects ids.
 *
 * @param string $content Content.
 * @return string
 */
function nexora_toc_prepare_content( $content ) {
	if ( ! nexora_get_option( 'article_toc' ) || ! is_singular( 'post' ) || ! in_the_loop() ) {
		return $content;
	}
	if ( false !== strpos( $content, 'id="nexora-toc-' ) ) {
		return $content;
	}

	$index = 0;
	$content = preg_replace_callback(
		'/<h2([^>]*)>(.*?)<\/h2>/is',
		static function ( $m ) use ( &$index ) {
			$index++;
			$id    = 'nexora-toc-' . $index;
			$attrs = $m[1];
			if ( preg_match( '/\sid=(["\']).+?\1/i', $attrs ) ) {
				return $m[0];
			}
			return '<h2' . $attrs . ' id="' . esc_attr( $id ) . '">' . $m[2] . '</h2>';
		},
		$content
	);
	return $content;
}
add_filter( 'the_content', 'nexora_toc_prepare_content', 8 );

/**
 * Whether heading text is a FAQ section title (any post wording).
 *
 * @param string $text Plain heading text.
 * @return bool
 */
function nexora_is_faq_heading_text( $text ) {
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $text ) ) );
	if ( '' === $text ) {
		return false;
	}
	return (bool) preg_match( '/^(faqs?|frequently\s+asked\s+questions?\b)/i', $text );
}

/**
 * Extract Q/A pairs from a FAQ section body (h3, details, or bold questions).
 *
 * @param string $body FAQ section HTML after the h2.
 * @return array<int,array{question:string,answer:string}>
 */
function nexora_faq_extract_pairs( $body ) {
	$body  = trim( (string) $body );
	$pairs = array();
	if ( '' === $body ) {
		return $pairs;
	}

	// Native / block details already in the section.
	if ( preg_match_all( '/<details\b[^>]*>\s*<summary\b[^>]*>(.*?)<\/summary>(.*?)<\/details>/is', $body, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $m ) {
			$question = trim( wp_strip_all_tags( $m[1] ) );
			$answer   = trim( $m[2] );
			if ( '' === $question || '' === $answer ) {
				continue;
			}
			$pairs[] = array(
				'question' => $question,
				'answer'   => $answer,
			);
		}
		if ( $pairs ) {
			return $pairs;
		}
	}

	// Standard review pattern: h3 question + following blocks until next h3.
	if ( preg_match_all( '/<h3\b[^>]*>(.*?)<\/h3>(.*?)(?=<h3\b|$)/is', $body, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $m ) {
			$question = trim( wp_strip_all_tags( $m[1] ) );
			$answer   = trim( $m[2] );
			if ( '' === $question || '' === $answer ) {
				continue;
			}
			$pairs[] = array(
				'question' => $question,
				'answer'   => $answer,
			);
		}
		if ( $pairs ) {
			return $pairs;
		}
	}

	// Fallback: <p><strong>Question?</strong></p> + following paragraphs.
	if ( preg_match_all(
		'/<p\b[^>]*>\s*(?:<strong>|<b>)(.*?)(?:<\/strong>|<\/b>)\s*<\/p>(.*?)(?=<p\b[^>]*>\s*(?:<strong>|<b>)|$)/is',
		$body,
		$matches,
		PREG_SET_ORDER
	) ) {
		foreach ( $matches as $m ) {
			$question = trim( wp_strip_all_tags( $m[1] ) );
			$answer   = trim( $m[2] );
			if ( '' === $question || '' === $answer ) {
				continue;
			}
			$pairs[] = array(
				'question' => $question,
				'answer'   => $answer,
			);
		}
	}

	return $pairs;
}

/**
 * Build the shared accordion markup used on every single post FAQ.
 *
 * @param string                                              $heading_html Original h2 HTML.
 * @param array<int,array{question:string,answer:string}> $pairs         Q/A pairs.
 * @return string
 */
function nexora_faq_render_accordion( $heading_html, $pairs ) {
	$items = '';
	foreach ( $pairs as $i => $pair ) {
		$question = trim( (string) $pair['question'] );
		$answer   = trim( (string) $pair['answer'] );
		if ( '' === $question || '' === $answer ) {
			continue;
		}
		$open   = 0 === (int) $i ? ' open' : '';
		$items .= '<details class="nexora-article-faq__item"' . $open . '>';
		$items .= '<summary class="nexora-article-faq__q">' . esc_html( $question ) . '</summary>';
		$items .= '<div class="nexora-article-faq__a">' . $answer . '</div>';
		$items .= '</details>';
	}
	if ( '' === $items ) {
		return '';
	}

	return '<section class="nexora-article-faq" aria-label="' . esc_attr__( 'Frequently asked questions', 'nexora' ) . '">'
		. $heading_html
		. '<div class="nexora-article-faq__list">' . $items . '</div>'
		. '</section>';
}

/**
 * Turn any FAQ heading + Q/A pairs into the same accordion on every post.
 *
 * @param string $content Content.
 * @return string
 */
function nexora_faq_prepare_content( $content ) {
	if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	if ( ! is_string( $content ) || false !== strpos( $content, 'nexora-article-faq' ) ) {
		return $content;
	}

	return (string) preg_replace_callback(
		'/(<h2\b[^>]*>)(.*?)(<\/h2>)(.*?)(?=<h2\b|$)/is',
		static function ( $section ) {
			$inner = $section[2];
			if ( ! nexora_is_faq_heading_text( $inner ) ) {
				return $section[0];
			}

			$heading = $section[1] . $inner . $section[3];
			$pairs   = nexora_faq_extract_pairs( $section[4] );
			if ( ! $pairs ) {
				return $section[0];
			}

			$built = nexora_faq_render_accordion( $heading, $pairs );
			return '' !== $built ? $built : $section[0];
		},
		$content
	);
}
add_filter( 'the_content', 'nexora_faq_prepare_content', 9 );

/**
 * FAQ question/answer pairs from post content (for FAQPage schema).
 *
 * @param int|null $post_id Post ID.
 * @return array<int,array{question:string,answer:string}>
 */
function nexora_faq_pairs( $post_id = null ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	$content = (string) get_post_field( 'post_content', $post_id );
	$pairs   = array();
	if ( ! preg_match_all( '/<h2\b[^>]*>(.*?)<\/h2>(.*?)(?=<h2\b|$)/is', $content, $sections, PREG_SET_ORDER ) ) {
		return array();
	}
	foreach ( $sections as $section ) {
		if ( ! nexora_is_faq_heading_text( $section[1] ) ) {
			continue;
		}
		$extracted = nexora_faq_extract_pairs( $section[2] );
		foreach ( $extracted as $row ) {
			$pairs[] = array(
				'question' => $row['question'],
				'answer'   => trim( wp_strip_all_tags( $row['answer'] ) ),
			);
		}
		break;
	}
	return array_values(
		array_filter(
			$pairs,
			static function ( $row ) {
				return '' !== $row['question'] && '' !== $row['answer'];
			}
		)
	);
}

/**
 * Collect TOC items from current post content (h2 only).
 *
 * @return array<int,array{id:string,text:string}>
 */
function nexora_toc_items() {
	if ( ! nexora_get_option( 'article_toc' ) ) {
		return array();
	}
	$content = (string) get_post_field( 'post_content', get_the_ID() );
	$items   = array();
	if ( ! preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/is', $content, $matches, PREG_SET_ORDER ) ) {
		return array();
	}
	$i = 0;
	foreach ( $matches as $m ) {
		$i++;
		$text = wp_strip_all_tags( $m[1] );
		if ( '' === $text ) {
			continue;
		}
		$items[] = array(
			'id'   => 'nexora-toc-' . $i,
			'text' => $text,
		);
	}
	return $items;
}

/**
 * Print TOC nav (collapsible).
 */
function nexora_toc() {
	$items = nexora_toc_items();
	if ( count( $items ) < 2 ) {
		return;
	}
	$count = count( $items );
	?>
	<details class="nexora-toc" data-nexora-toc open>
		<summary class="nexora-toc__summary">
			<span class="nexora-toc__summary-text">
				<span class="nexora-toc__label"><?php esc_html_e( 'Table of contents', 'nexora' ); ?></span>
				<span class="nexora-toc__count"><?php echo esc_html( (string) $count ); ?></span>
			</span>
			<span class="nexora-toc__chev" aria-hidden="true"></span>
		</summary>
		<nav class="nexora-toc__nav" aria-label="<?php esc_attr_e( 'Table of contents', 'nexora' ); ?>">
			<ol class="nexora-toc__list">
				<?php foreach ( $items as $i => $item ) : ?>
					<li class="nexora-toc__item">
						<a class="nexora-toc__link" href="#<?php echo esc_attr( $item['id'] ); ?>" data-nexora-toc-link>
							<span class="nexora-toc__num" aria-hidden="true"><?php echo esc_html( (string) ( $i + 1 ) ); ?></span>
							<span class="nexora-toc__text"><?php echo esc_html( $item['text'] ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ol>
		</nav>
	</details>
	<?php
}

/**
 * Make an image URL absolute for Pinterest.
 *
 * @param string $url Image src.
 * @return string
 */
function nexora_absolute_media_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url || 0 === strpos( $url, 'data:' ) ) {
		return '';
	}
	if ( 0 === strpos( $url, '//' ) ) {
		return ( is_ssl() ? 'https:' : 'http:' ) . $url;
	}
	if ( preg_match( '#^https?://#i', $url ) ) {
		return $url;
	}
	return home_url( $url );
}

/**
 * Pinterest “Pin it” create URL for a page + image.
 *
 * @param string $image_url Absolute image URL.
 * @param string $page_url  Page URL (defaults to current permalink).
 * @param string $description Share text.
 * @return string
 */
function nexora_pinterest_create_url( $image_url, $page_url = '', $description = '' ) {
	$image_url = nexora_absolute_media_url( $image_url );
	if ( ! $image_url ) {
		return '';
	}
	if ( ! $page_url ) {
		$page_url = get_permalink();
	}
	if ( ! $description ) {
		$description = wp_strip_all_tags( get_the_title() );
	}
	return add_query_arg(
		array(
			'url'         => $page_url,
			'media'       => $image_url,
			'description' => $description,
		),
		'https://www.pinterest.com/pin/create/button/'
	);
}

/**
 * Official-style Pinterest “P” mark for the Save pill (Simple Icons path).
 *
 * @return string SVG markup (unescaped; static).
 */
function nexora_pinterest_mark_svg() {
	return '<svg width="12" height="12" viewBox="0 0 24 24" focusable="false" aria-hidden="true"><path fill="currentColor" d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/></svg>';
}

/**
 * Markup for the Save / Pin button overlay (official red pill + white P badge).
 *
 * @param string $image_url Image to pin.
 * @return string HTML or empty.
 */
function nexora_pinterest_button_html( $image_url ) {
	$href = nexora_pinterest_create_url( $image_url );
	if ( ! $href ) {
		return '';
	}
	return sprintf(
		'<a class="nexora-pin__btn" href="%1$s" target="_blank" rel="noopener noreferrer"><span class="nexora-pin__icon" aria-hidden="true">%2$s</span><span class="nexora-pin__label">%3$s</span></a>',
		esc_url( $href ),
		nexora_pinterest_mark_svg(), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG.
		esc_html__( 'Save', 'nexora' )
	);
}

/**
 * Resolve an img element’s usable source URL (src, data-src, or first srcset candidate).
 *
 * @param DOMElement $img Image node.
 * @return string
 */
function nexora_img_source_url( $img ) {
	if ( ! $img instanceof DOMElement ) {
		return '';
	}
	$src = trim( (string) $img->getAttribute( 'src' ) );
	if ( '' === $src || 0 === strpos( $src, 'data:' ) ) {
		$src = trim( (string) $img->getAttribute( 'data-src' ) );
	}
	if ( ( '' === $src || 0 === strpos( $src, 'data:' ) ) && $img->hasAttribute( 'srcset' ) ) {
		$parts = preg_split( '/\s*,\s*/', (string) $img->getAttribute( 'srcset' ) );
		if ( $parts && isset( $parts[0] ) ) {
			$chunk = preg_split( '/\s+/', trim( $parts[0] ) );
			$src   = isset( $chunk[0] ) ? $chunk[0] : '';
		}
	}
	return nexora_absolute_media_url( $src );
}

/**
 * Build a Pinterest Save button DOM node.
 *
 * @param DOMDocument $dom  Document.
 * @param string      $href Pin create URL.
 * @return DOMElement
 */
function nexora_pinterest_button_node( DOMDocument $dom, $href ) {
	$btn = $dom->createElement( 'a' );
	$btn->setAttribute( 'class', 'nexora-pin__btn' );
	$btn->setAttribute( 'href', $href );
	$btn->setAttribute( 'target', '_blank' );
	$btn->setAttribute( 'rel', 'noopener noreferrer' );
	$btn->setAttribute( 'aria-label', __( 'Save to Pinterest', 'nexora' ) );

	$icon = $dom->createElement( 'span' );
	$icon->setAttribute( 'class', 'nexora-pin__icon' );
	$icon->setAttribute( 'aria-hidden', 'true' );
	$tmp = new DOMDocument();
	@$tmp->loadHTML( // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		'<!DOCTYPE html><html><body><div id="nexora-svg">' . nexora_pinterest_mark_svg() . '</div></body></html>'
	);
	$svg_wrap = $tmp->getElementById( 'nexora-svg' );
	if ( $svg_wrap && $svg_wrap->firstChild ) {
		$icon->appendChild( $dom->importNode( $svg_wrap->firstChild, true ) );
	}
	$btn->appendChild( $icon );

	$label = $dom->createElement( 'span' );
	$label->setAttribute( 'class', 'nexora-pin__label' );
	$label->appendChild( $dom->createTextNode( __( 'Save', 'nexora' ) ) );
	$btn->appendChild( $label );

	return $btn;
}

/**
 * Add Pinterest Save overlays on images inside the post body.
 *
 * Featured image is handled in single.php; this covers in-content images.
 * Some post HTML already has a bare `nexora-pin` class (no button) from earlier
 * runs — those must still get a Save control.
 *
 * @param string $content Post content.
 * @return string
 */
function nexora_content_pinterest_pins( $content ) {
	if ( is_admin() || wp_doing_ajax() || ! is_singular( 'post' ) ) {
		return $content;
	}
	if ( '' === trim( $content ) ) {
		return $content;
	}
	if ( ! class_exists( 'DOMDocument' ) ) {
		return $content;
	}

	$page    = (string) get_permalink();
	$desc    = wp_strip_all_tags( get_the_title() );
	$wrapped = '<div id="nexora-pin-root">' . $content . '</div>';
	$dom     = new DOMDocument();
	$prev    = libxml_use_internal_errors( true );
	$html    = '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' . $wrapped . '</body></html>';
	$dom->loadHTML( $html );
	libxml_clear_errors();
	libxml_use_internal_errors( $prev );

	$root = $dom->getElementById( 'nexora-pin-root' );
	if ( ! $root ) {
		return $content;
	}

	$xpath = new DOMXPath( $dom );
	// All content images except ads (include bare .nexora-pin wraps that lack a button).
	$imgs = $xpath->query(
		'.//img[not(ancestor::*[contains(concat(" ", normalize-space(@class), " "), " nexora-ad ")])]',
		$root
	);
	if ( ! $imgs || 0 === $imgs->length ) {
		return $content;
	}

	$changed = false;
	foreach ( iterator_to_array( $imgs ) as $img ) {
		if ( ! $img instanceof DOMElement ) {
			continue;
		}

		// Skip if this image already has a Save button in its pin container.
		$pin_host = null;
		$figure   = null;
		$node     = $img;
		while ( $node && $node !== $root ) {
			if ( $node instanceof DOMElement ) {
				$class = ' ' . $node->getAttribute( 'class' ) . ' ';
				if ( false !== strpos( $class, ' nexora-pin ' ) ) {
					$pin_host = $node;
				}
				if ( 'figure' === strtolower( $node->tagName ) ) {
					$figure = $node;
				}
			}
			$node = $node->parentNode;
		}
		if ( $pin_host ) {
			$has_btn = false;
			foreach ( $pin_host->getElementsByTagName( 'a' ) as $a ) {
				if ( $a instanceof DOMElement && false !== strpos( ' ' . $a->getAttribute( 'class' ) . ' ', ' nexora-pin__btn ' ) ) {
					$has_btn = true;
					break;
				}
			}
			if ( $has_btn ) {
				continue;
			}
		}

		$abs = nexora_img_source_url( $img );
		if ( ! $abs ) {
			continue;
		}
		$w = (int) $img->getAttribute( 'width' );
		$h = (int) $img->getAttribute( 'height' );
		if ( ( $w > 0 && $w < 120 ) || ( $h > 0 && $h < 120 ) ) {
			continue;
		}

		$href = nexora_pinterest_create_url( $abs, $page, $desc );
		if ( ! $href ) {
			continue;
		}

		$btn = nexora_pinterest_button_node( $dom, $href );

		if ( $pin_host ) {
			$pin_host->appendChild( $btn );
			$changed = true;
			continue;
		}

		if ( $figure ) {
			$class = $figure->getAttribute( 'class' );
			$figure->setAttribute( 'class', trim( $class . ' nexora-pin' ) );
			$figure->appendChild( $btn );
			$changed = true;
			continue;
		}

		$parent      = $img->parentNode;
		$wrap_target = ( $parent instanceof DOMElement && 'a' === strtolower( $parent->tagName ) ) ? $parent : $img;
		$wrap        = $dom->createElement( 'span' );
		$wrap->setAttribute( 'class', 'nexora-pin' );
		if ( $wrap_target->parentNode ) {
			$wrap_target->parentNode->insertBefore( $wrap, $wrap_target );
			$wrap->appendChild( $wrap_target );
			$wrap->appendChild( $btn );
			$changed = true;
		}
	}

	if ( ! $changed ) {
		return $content;
	}

	$out = '';
	foreach ( $root->childNodes as $child ) {
		$out .= $dom->saveHTML( $child );
	}
	return $out ? $out : $content;
}
add_filter( 'the_content', 'nexora_content_pinterest_pins', 14 );

/**
 * Share network definitions for posts (Facebook, Instagram, Threads, Pinterest).
 * Instagram has no web share URL — button copies the permalink for pasting in the app.
 *
 * @return array<int, array<string, string>>
 */
function nexora_share_networks() {
	$permalink = (string) get_permalink();
	$title     = wp_strip_all_tags( get_the_title() );
	$text      = $title . ' ' . $permalink;

	$pin_media = '';
	if ( has_post_thumbnail() ) {
		$pin_media = (string) get_the_post_thumbnail_url( null, 'full' );
	}
	$pin_href = $pin_media ? nexora_pinterest_create_url( $pin_media, $permalink, $title ) : '';

	$networks = array(
		array(
			'id'    => 'facebook',
			'label' => __( 'Share on Facebook', 'nexora' ),
			'url'   => 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( $permalink ),
			'svg'   => '<path fill="currentColor" d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z"/>',
		),
		array(
			'id'    => 'instagram',
			'label' => __( 'Copy link for Instagram', 'nexora' ),
			'url'   => '',
			'copy'  => $permalink,
			'svg'   => '<path fill="currentColor" d="M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"/>',
		),
		array(
			'id'      => 'threads',
			'label'   => __( 'Share on Threads', 'nexora' ),
			'url'     => 'https://www.threads.net/intent/post?text=' . rawurlencode( $text ),
			// Phosphor Threads @ (viewBox 256) — stays readable at 16px; Simple Icons fill reads as a blob.
			'viewBox' => '0 0 256 256',
			'svg'     => '<path fill="currentColor" d="M186.42,123.65a63.81,63.81,0,0,0-11.13-6.72c-4-29.89-24-39.31-33.1-42.07-19.78-6-42.51,1.19-52.85,16.7a8,8,0,0,0,13.32,8.88c6.37-9.56,22-14.16,34.89-10.27,9.95,3,16.82,10.3,20.15,21a81.05,81.05,0,0,0-15.29-1.43c-13.92,0-26.95,3.59-36.67,10.1C94.3,127.57,88,139,88,152c0,20.58,15.86,35.52,37.71,35.52a48,48,0,0,0,34.35-14.81c6.44-6.7,14-18.36,15.61-37.1.38.26.74.53,1.1.8C186.88,144.05,192,154.68,192,168c0,19.36-20.34,48-64,48-26.73,0-45.48-8.65-57.34-26.44C60.93,175,56,154.26,56,128s4.93-47,14.66-61.56C82.52,48.65,101.27,40,128,40c32.93,0,54,13.25,64.53,40.52a8,8,0,1,0,14.93-5.75C194.68,41.56,167.2,24,128,24,96,24,72.19,35.29,57.34,57.56,45.83,74.83,40,98.52,40,128s5.83,53.17,17.34,70.44C72.19,220.71,96,232,128,232c30.07,0,48.9-11.48,59.4-21.1C200.3,199.08,208,183,208,168,208,149.66,200.54,134.32,186.42,123.65Zm-37.89,38a31.94,31.94,0,0,1-22.82,9.9c-10.81,0-21.71-6-21.71-19.52,0-12.63,12-26.21,38.41-26.21A63.88,63.88,0,0,1,160,128.24C160,142.32,156,153.86,148.53,161.62Z"/>',
		),
	);

	if ( $pin_href ) {
		$networks[] = array(
			'id'    => 'pinterest',
			'label' => __( 'Save to Pinterest', 'nexora' ),
			'url'   => $pin_href,
			'svg'   => '<path fill="currentColor" d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/>',
		);
	}

	return $networks;
}

/**
 * Render share icon list (Facebook, Instagram, Threads, Pinterest).
 *
 * @param string $list_class Extra class on the <ul>.
 */
function nexora_share_list( $list_class = '' ) {
	$networks = nexora_share_networks();
	$class    = trim( 'nexora-article__share ' . $list_class );
	?>
	<ul class="<?php echo esc_attr( $class ); ?>">
		<?php foreach ( $networks as $net ) : ?>
			<?php $view_box = ! empty( $net['viewBox'] ) ? $net['viewBox'] : '0 0 24 24'; ?>
			<li>
				<?php if ( ! empty( $net['copy'] ) ) : ?>
					<button
						type="button"
						class="nexora-article__share-btn"
						data-nexora-copy="<?php echo esc_url( $net['copy'] ); ?>"
						data-nexora-copy-done="<?php echo esc_attr__( 'Link copied — paste in Instagram', 'nexora' ); ?>"
					>
						<span class="nexora-visually-hidden"><?php echo esc_html( $net['label'] ); ?></span>
						<svg width="24" height="24" viewBox="<?php echo esc_attr( $view_box ); ?>" aria-hidden="true" focusable="false"><?php echo $net['svg']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG paths. ?></svg>
					</button>
				<?php else : ?>
					<a class="nexora-article__share-btn" href="<?php echo esc_url( $net['url'] ); ?>" target="_blank" rel="noopener noreferrer">
						<span class="nexora-visually-hidden"><?php echo esc_html( $net['label'] ); ?></span>
						<svg width="24" height="24" viewBox="<?php echo esc_attr( $view_box ); ?>" aria-hidden="true" focusable="false"><?php echo $net['svg']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG paths. ?></svg>
					</a>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
}

/**
 * Inline share row after article content.
 */
function nexora_share_block() {
	?>
	<div class="nexora-article__share-block">
		<p class="nexora-article__share-label"><?php esc_html_e( 'Share', 'nexora' ); ?></p>
		<?php nexora_share_list(); ?>
	</div>
	<?php
}

/**
 * Fixed right-side share bar on single posts (desktop).
 */
function nexora_floating_share() {
	if ( ! is_singular( 'post' ) ) {
		return;
	}
	?>
	<aside class="nexora-share-float" aria-label="<?php esc_attr_e( 'Share this guide', 'nexora' ); ?>">
		<p class="nexora-share-float__label"><?php esc_html_e( 'Share', 'nexora' ); ?></p>
		<?php nexora_share_list( 'nexora-share-float__list' ); ?>
	</aside>
	<?php
}

/**
 * Author box.
 */
function nexora_author_box() {
	if ( ! nexora_get_option( 'article_author_box' ) || ! is_singular( 'post' ) ) {
		return;
	}
	$id   = (int) get_the_author_meta( 'ID' );
	$name = get_the_author();
	$bio  = get_the_author_meta( 'description' );
	$url  = get_author_posts_url( $id );
	?>
	<aside class="nexora-author-box" aria-label="<?php esc_attr_e( 'About the author', 'nexora' ); ?>">
		<?php echo get_avatar( $id, 72, '', $name, array( 'class' => 'nexora-author-box__avatar' ) ); ?>
		<div class="nexora-author-box__body">
			<p class="nexora-author-box__by"><?php esc_html_e( 'Written by', 'nexora' ); ?></p>
			<p class="nexora-author-box__name"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $name ); ?></a></p>
			<?php if ( $bio ) : ?>
				<p class="nexora-author-box__bio"><?php echo esc_html( $bio ); ?></p>
			<?php endif; ?>
		</div>
	</aside>
	<?php
}
