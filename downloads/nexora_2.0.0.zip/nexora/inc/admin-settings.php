<?php
/**
 * Appearance → Nexora — tabbed theme dashboard (niche, ads, privacy, etc.).
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin page slug (under Appearance).
 *
 * @return string
 */
function nexora_settings_page_slug() {
	return 'nexora';
}

/**
 * Display name for the theme admin hub.
 *
 * @return string
 */
function nexora_settings_menu_label() {
	return defined( 'NEXORA_THEME_NAME' ) ? NEXORA_THEME_NAME : 'Nexora';
}

/**
 * Register Appearance → Nexora (all theme features & settings).
 */
function nexora_admin_menu() {
	$label = nexora_settings_menu_label();
	add_theme_page(
		$label,
		$label,
		'edit_theme_options',
		nexora_settings_page_slug(),
		'nexora_render_settings_page'
	);
}
add_action( 'admin_menu', 'nexora_admin_menu' );

/**
 * Media library for Branding logo / Site Icon pickers.
 *
 * @param string $hook Current admin screen.
 */
function nexora_admin_settings_assets( $hook ) {
	if ( 'appearance_page_' . nexora_settings_page_slug() !== $hook ) {
		return;
	}
	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'branding' !== $tab ) {
		return;
	}
	wp_enqueue_media();
	wp_register_script( 'nexora-admin-branding', false, array( 'jquery' ), defined( 'NEXORA_VERSION' ) ? NEXORA_VERSION : '1', true );
	wp_enqueue_script( 'nexora-admin-branding' );
	/* Single-quoted: jQuery `$` must not be PHP-interpolated (parse fatal). */
	$branding_js = '(function($){function bind(btn,input,preview){$(document).on("click",btn,function(e){e.preventDefault();var frame=wp.media({title:$(this).data("title")||"Select",button:{text:$(this).data("button")||"Use"},multiple:false});frame.on("select",function(){var att=frame.state().get("selection").first().toJSON();$(input).val(att.id);if(preview){var url=(att.sizes&&att.sizes.medium)?att.sizes.medium.url:att.url;$(preview).attr("src",url).show();}});frame.open();});}$(function(){bind("#nexora-pick-logo","#custom_logo_id","#nexora-logo-preview");bind("#nexora-pick-icon","#site_icon_id","#nexora-icon-preview");$(document).on("click","#nexora-clear-logo",function(e){e.preventDefault();$("#custom_logo_id").val("0");$("#nexora-logo-preview").hide().attr("src","");});$(document).on("click","#nexora-clear-icon",function(e){e.preventDefault();$("#site_icon_id").val("0");$("#nexora-icon-preview").hide().attr("src","");});});})(jQuery);';
	wp_add_inline_script( 'nexora-admin-branding', $branding_js );
}
add_action( 'admin_enqueue_scripts', 'nexora_admin_settings_assets' );

/**
 * Keep old Theme Settings URL working (bookmarks / docs).
 */
function nexora_settings_legacy_redirect() {
	if ( ! is_admin() ) {
		return;
	}
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'nexora-settings' !== $page ) {
		return;
	}
	$args = array( 'page' => nexora_settings_page_slug() );
	if ( ! empty( $_GET['tab'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$args['tab'] = sanitize_key( wp_unslash( $_GET['tab'] ) );
	}
	if ( ! empty( $_GET['updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$args['updated'] = '1';
	}
	if ( ! empty( $_GET['nexora_gh'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$args['nexora_gh'] = '1';
	}
	wp_safe_redirect( add_query_arg( $args, admin_url( 'themes.php' ) ) );
	exit;
}
add_action( 'admin_init', 'nexora_settings_legacy_redirect', 1 );

/**
 * Settings tab map (universal IA; package slug unchanged until rename).
 *
 * @return array<string,string>
 */
function nexora_settings_tabs() {
	return array(
		'dashboard'   => __( 'Overview', 'nexora' ),
		'niche'       => __( 'Niche', 'nexora' ),
		'branding'    => __( 'Branding', 'nexora' ),
		'homepage'    => __( 'Homepage', 'nexora' ),
		'article'     => __( 'Article', 'nexora' ),
		'performance' => __( 'SEO', 'nexora' ),
		'ads'         => __( 'Advertising', 'nexora' ),
		'affiliate'   => __( 'Affiliate', 'nexora' ),
		'redirects'   => __( '301', 'nexora' ),
		'privacy'     => __( 'Cookie & Privacy', 'nexora' ),
		'ai'          => __( 'AI Agents', 'nexora' ),
		'advanced'    => __( 'Advanced', 'nexora' ),
		'revenue'     => __( 'Revenue', 'nexora' ),
	);
}

/**
 * Redirect after settings save.
 *
 * @param string $tab Tab key.
 */
function nexora_settings_redirect( $tab ) {
	wp_safe_redirect(
		add_query_arg(
			array(
				'page'    => nexora_settings_page_slug(),
				'tab'     => $tab,
				'updated' => '1',
			),
			admin_url( 'themes.php' )
		)
	);
	exit;
}

/**
 * Save theme settings (tab-scoped — never wipe mods from other tabs).
 */
function nexora_handle_settings_save() {
	if ( ! isset( $_POST['nexora_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nexora_settings_nonce'] ) ), 'nexora_settings' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$tab  = isset( $_POST['nexora_tab'] ) ? sanitize_key( wp_unslash( $_POST['nexora_tab'] ) ) : 'dashboard';
	$tabs = nexora_settings_tabs();
	if ( ! isset( $tabs[ $tab ] ) ) {
		$tab = 'dashboard';
	}

	/*
	 * Niche tab: presentation ONLY. Do not create/delete content, taxonomies,
	 * media, site identity, SEO, ads, or affiliate settings here.
	 */
	if ( 'niche' === $tab ) {
		if ( isset( $_POST['niche_preset'] ) ) {
			$slug = sanitize_key( wp_unslash( $_POST['niche_preset'] ) );
			if ( function_exists( 'nexora_normalize_niche_slug' ) ) {
				$slug = nexora_normalize_niche_slug( $slug );
			}
			$presets = function_exists( 'nexora_niche_presets' ) ? nexora_niche_presets() : array();
			if ( isset( $presets[ $slug ] ) ) {
				set_theme_mod( 'niche_preset', $slug );
			}
		}
		if ( isset( $_POST['developer_contact_url'] ) ) {
			set_theme_mod( 'developer_contact_url', esc_url_raw( wp_unslash( $_POST['developer_contact_url'] ) ) );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'homepage' === $tab ) {
		if ( isset( $_POST['home_h1'] ) ) {
			set_theme_mod( 'home_h1', sanitize_text_field( wp_unslash( $_POST['home_h1'] ) ) );
		}
		if ( isset( $_POST['home_lede'] ) ) {
			set_theme_mod( 'home_lede', sanitize_textarea_field( wp_unslash( $_POST['home_lede'] ) ) );
		}
		if ( isset( $_POST['footer_blurb'] ) ) {
			set_theme_mod( 'footer_blurb', sanitize_textarea_field( wp_unslash( $_POST['footer_blurb'] ) ) );
		}
		if ( isset( $_POST['footer_disclosure'] ) ) {
			set_theme_mod( 'footer_disclosure', sanitize_textarea_field( wp_unslash( $_POST['footer_disclosure'] ) ) );
		}
		if ( isset( $_POST['newsletter_eyebrow'] ) ) {
			set_theme_mod( 'newsletter_eyebrow', sanitize_text_field( wp_unslash( $_POST['newsletter_eyebrow'] ) ) );
		}
		if ( isset( $_POST['newsletter_lede'] ) ) {
			set_theme_mod( 'newsletter_lede', sanitize_textarea_field( wp_unslash( $_POST['newsletter_lede'] ) ) );
		}
		if ( isset( $_POST['newsletter_placeholder'] ) ) {
			set_theme_mod( 'newsletter_placeholder', sanitize_text_field( wp_unslash( $_POST['newsletter_placeholder'] ) ) );
		}
		if ( isset( $_POST['contact_email'] ) ) {
			$email = sanitize_email( wp_unslash( $_POST['contact_email'] ) );
			set_theme_mod( 'contact_email', $email ? $email : '' );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'branding' === $tab ) {
		if ( isset( $_POST['blogname'] ) && current_user_can( 'manage_options' ) ) {
			update_option( 'blogname', sanitize_text_field( wp_unslash( $_POST['blogname'] ) ) );
		}
		if ( isset( $_POST['blogdescription'] ) && current_user_can( 'manage_options' ) ) {
			update_option( 'blogdescription', sanitize_text_field( wp_unslash( $_POST['blogdescription'] ) ) );
		}
		if ( isset( $_POST['seo_home_title'] ) ) {
			set_theme_mod( 'seo_home_title', sanitize_text_field( wp_unslash( $_POST['seo_home_title'] ) ) );
		}
		if ( isset( $_POST['seo_home_description'] ) ) {
			set_theme_mod( 'seo_home_description', sanitize_textarea_field( wp_unslash( $_POST['seo_home_description'] ) ) );
		}
		if ( isset( $_POST['custom_logo_id'] ) && current_user_can( 'manage_options' ) ) {
			$logo_id = absint( $_POST['custom_logo_id'] );
			if ( $logo_id && wp_attachment_is_image( $logo_id ) ) {
				set_theme_mod( 'custom_logo', $logo_id );
			} else {
				remove_theme_mod( 'custom_logo' );
			}
		}
		if ( isset( $_POST['site_icon_id'] ) && current_user_can( 'manage_options' ) ) {
			$icon_id = absint( $_POST['site_icon_id'] );
			if ( $icon_id && wp_attachment_is_image( $icon_id ) ) {
				update_option( 'site_icon', $icon_id );
			} else {
				delete_option( 'site_icon' );
			}
		}
		if ( isset( $_POST['ghl_affiliate_url'] ) ) {
			set_theme_mod( 'ghl_affiliate_url', esc_url_raw( wp_unslash( $_POST['ghl_affiliate_url'] ) ) );
		}
		set_theme_mod( 'preloader_enabled', ! empty( $_POST['preloader_enabled'] ) );
		nexora_settings_redirect( $tab );
	}

	if ( 'article' === $tab ) {
		set_theme_mod( 'article_reading_time', ! empty( $_POST['article_reading_time'] ) );
		set_theme_mod( 'article_meta_author', ! empty( $_POST['article_meta_author'] ) );
		set_theme_mod( 'article_meta_date', ! empty( $_POST['article_meta_date'] ) );
		set_theme_mod( 'article_toc', ! empty( $_POST['article_toc'] ) );
		set_theme_mod( 'article_author_box', ! empty( $_POST['article_author_box'] ) );
		set_theme_mod( 'article_breadcrumbs', ! empty( $_POST['article_breadcrumbs'] ) );
		set_theme_mod( 'article_updated_date', ! empty( $_POST['article_updated_date'] ) );
		nexora_settings_redirect( $tab );
	}

	if ( 'performance' === $tab ) {
		if ( isset( $_POST['ga4_measurement_id'] ) ) {
			$ga = strtoupper( sanitize_text_field( wp_unslash( $_POST['ga4_measurement_id'] ) ) );
			$ga = preg_match( '/^G-[A-Z0-9]+$/', $ga ) ? $ga : '';
			set_theme_mod( 'ga4_measurement_id', $ga );
		}
		if ( isset( $_POST['gsc_verification'] ) ) {
			set_theme_mod( 'gsc_verification', sanitize_text_field( wp_unslash( $_POST['gsc_verification'] ) ) );
		}
		if ( isset( $_POST['bing_verification'] ) ) {
			set_theme_mod( 'bing_verification', sanitize_text_field( wp_unslash( $_POST['bing_verification'] ) ) );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'ads' === $tab ) {
		set_theme_mod( 'ads_enabled', ! empty( $_POST['ads_enabled'] ) );
		if ( isset( $_POST['adsense_client'] ) ) {
			$client = function_exists( 'nexora_sanitize_adsense_client' )
				? nexora_sanitize_adsense_client( wp_unslash( $_POST['adsense_client'] ) )
				: '';
			set_theme_mod( 'adsense_client', $client );
		}
		set_theme_mod( 'adsense_auto_ads', ! empty( $_POST['adsense_auto_ads'] ) );
		set_theme_mod( 'adsense_in_article', ! empty( $_POST['adsense_in_article'] ) );
		if ( isset( $_POST['adsense_slot_in_article'] ) ) {
			set_theme_mod( 'adsense_slot_in_article', sanitize_text_field( wp_unslash( $_POST['adsense_slot_in_article'] ) ) );
		}
		if ( isset( $_POST['adsense_in_article_after'] ) ) {
			set_theme_mod( 'adsense_in_article_after', max( 1, min( 8, absint( $_POST['adsense_in_article_after'] ) ) ) );
		}
		if ( isset( $_POST['ad_placements'] ) && is_array( $_POST['ad_placements'] ) ) {
			$clean = array();
			$defs  = nexora_ad_placement_defs();
			foreach ( $defs as $key => $def ) {
				$row  = isset( $_POST['ad_placements'][ $key ] ) ? wp_unslash( $_POST['ad_placements'][ $key ] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$code = '';
				if ( ! empty( $row['code'] ) && current_user_can( 'unfiltered_html' ) ) {
					$code = (string) $row['code'];
				}
				$clean[ $key ] = array(
					'enabled' => ! empty( $row['enabled'] ),
					'desktop' => ! empty( $row['desktop'] ),
					'mobile'  => ! empty( $row['mobile'] ),
					'slot'    => isset( $row['slot'] ) ? preg_replace( '/\D+/', '', (string) $row['slot'] ) : '',
					'code'    => $code,
				);
			}
			set_theme_mod( 'ad_placements', $clean );
		}
		if ( isset( $_POST['ads_exclude_categories'] ) && is_array( $_POST['ads_exclude_categories'] ) ) {
			$ids = array_map( 'absint', wp_unslash( $_POST['ads_exclude_categories'] ) );
			set_theme_mod( 'ads_exclude_categories', array_values( array_filter( $ids ) ) );
		} else {
			set_theme_mod( 'ads_exclude_categories', array() );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'affiliate' === $tab ) {
		if ( isset( $_POST['amazon_tracking_id'] ) ) {
			$tag = sanitize_text_field( wp_unslash( $_POST['amazon_tracking_id'] ) );
			$tag = preg_match( '/^[A-Za-z0-9_-]*$/', $tag ) ? $tag : '';
			set_theme_mod( 'amazon_tracking_id', $tag );
			if ( function_exists( 'pwa_set_affiliate_tracking_id' ) ) {
				pwa_set_affiliate_tracking_id( $tag );
			}
		}
		if ( isset( $_POST['amazon_marketplace'] ) ) {
			set_theme_mod( 'amazon_marketplace', sanitize_text_field( wp_unslash( $_POST['amazon_marketplace'] ) ) );
		}
		if ( isset( $_POST['affiliate_disclosure'] ) ) {
			set_theme_mod( 'affiliate_disclosure', sanitize_textarea_field( wp_unslash( $_POST['affiliate_disclosure'] ) ) );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'privacy' === $tab ) {
		set_theme_mod( 'cookie_banner', ! empty( $_POST['cookie_banner'] ) );
		if ( isset( $_POST['privacy_policy_url'] ) ) {
			set_theme_mod( 'privacy_policy_url', esc_url_raw( wp_unslash( $_POST['privacy_policy_url'] ) ) );
		}
		if ( isset( $_POST['cookie_policy_url'] ) ) {
			set_theme_mod( 'cookie_policy_url', esc_url_raw( wp_unslash( $_POST['cookie_policy_url'] ) ) );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'revenue' === $tab ) {
		set_theme_mod( 'aff_track_clicks', ! empty( $_POST['aff_track_clicks'] ) );
		if ( isset( $_POST['adsense_manual_revenue'] ) ) {
			set_theme_mod( 'adsense_manual_revenue', sanitize_text_field( wp_unslash( $_POST['adsense_manual_revenue'] ) ) );
		}
		if ( isset( $_POST['adsense_manual_rpm'] ) ) {
			set_theme_mod( 'adsense_manual_rpm', sanitize_text_field( wp_unslash( $_POST['adsense_manual_rpm'] ) ) );
		}
		if ( isset( $_POST['adsense_manual_note'] ) ) {
			set_theme_mod( 'adsense_manual_note', sanitize_textarea_field( wp_unslash( $_POST['adsense_manual_note'] ) ) );
		}
		nexora_settings_redirect( $tab );
	}

	if ( 'advanced' === $tab ) {
		// Prefer wp-config; only save Theme Settings token when constant is absent.
		if ( ! function_exists( 'nexora_github_token_from_wp_config' ) || ! nexora_github_token_from_wp_config() ) {
			if ( ! empty( $_POST['nexora_github_token_clear'] ) ) {
				delete_option( 'nexora_github_token' );
			} elseif ( isset( $_POST['nexora_github_token'] ) ) {
				$raw = trim( sanitize_text_field( wp_unslash( $_POST['nexora_github_token'] ) ) );
				if ( '' !== $raw ) {
					// GitHub PATs: ghp_ / github_pat_ / gho_ etc.
					$raw = preg_replace( '/\s+/', '', $raw );
					update_option( 'nexora_github_token', $raw, false );
				}
			}
		}
		if ( function_exists( 'nexora_github_clear_cache' ) ) {
			nexora_github_clear_cache();
		}
		nexora_settings_redirect( $tab );
	}

	// AI / Overview: no form fields that mutate content.
	nexora_settings_redirect( $tab );
}
add_action( 'admin_post_nexora_save_settings', 'nexora_handle_settings_save' );

/**
 * Render settings UI.
 */
function nexora_render_settings_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$tabs = nexora_settings_tabs();
	if ( ! isset( $tabs[ $tab ] ) ) {
		$tab = 'dashboard';
	}

	$url     = get_theme_mod( 'ghl_affiliate_url', nexora_default_affiliate_url() );
	$email   = nexora_contact_email();
	$ads     = nexora_adsense_client();
	$active  = function_exists( 'nexora_active_niche' ) ? nexora_active_niche() : 'trades';
	$presets = function_exists( 'nexora_niche_presets' ) ? nexora_niche_presets() : array();
	$dev_url = (string) nexora_get_option( 'developer_contact_url' );
	$exclude = (array) nexora_get_option( 'ads_exclude_categories' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( nexora_settings_menu_label() ); ?></h1>
		<p class="description" style="margin-top:0"><?php esc_html_e( 'Theme features and settings — niche colors, homepage, ads, affiliate, privacy, and more.', 'nexora' ); ?></p>
		<?php if ( ! empty( $_GET['updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'nexora' ); ?></p></div>
		<?php endif; ?>

		<nav class="nav-tab-wrapper" style="margin-bottom:16px">
			<?php
			$base = admin_url( 'themes.php?page=' . nexora_settings_page_slug() );
			foreach ( $tabs as $key => $label ) :
				?>
				<a class="nav-tab <?php echo $tab === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tab', $key, $base ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>

		<?php
		$standalone_tabs = array( 'dashboard', 'ai', 'redirects' );
		$standalone      = in_array( $tab, $standalone_tabs, true );
		?>
		<?php if ( ! $standalone ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="nexora_save_settings">
			<input type="hidden" name="nexora_tab" value="<?php echo esc_attr( $tab ); ?>">
			<?php wp_nonce_field( 'nexora_settings', 'nexora_settings_nonce' ); ?>
		<?php endif; ?>

			<?php if ( 'dashboard' === $tab ) : ?>
				<table class="form-table" role="presentation">
					<tr><th><?php esc_html_e( 'Theme version', 'nexora' ); ?></th><td><?php echo esc_html( NEXORA_VERSION ); ?></td></tr>
					<tr>
						<th><?php esc_html_e( 'Niche preset', 'nexora' ); ?></th>
						<td>
							<?php
							$label = isset( $presets[ $active ]['label'] ) ? $presets[ $active ]['label'] : $active;
							echo esc_html( $label );
							?>
							· <a href="<?php echo esc_url( admin_url( 'themes.php?page=' . nexora_settings_page_slug() . '&tab=niche' ) ); ?>"><?php esc_html_e( 'Change', 'nexora' ); ?></a>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Updates', 'nexora' ); ?></th>
						<td>
							<?php
							esc_html_e( 'To get a theme update: add your license update token under Advanced (or in wp-config.php), check for updates, then install from Appearance → Themes.', 'nexora' );
							?>
							<br>
							<a href="<?php echo esc_url( admin_url( 'themes.php' ) ); ?>"><?php esc_html_e( 'Appearance → Themes', 'nexora' ); ?></a>
							·
							<a href="<?php echo esc_url( admin_url( 'themes.php?page=' . nexora_settings_page_slug() . '&tab=advanced' ) ); ?>"><?php esc_html_e( 'Setup guide', 'nexora' ); ?></a>
							<?php
							$probe = get_transient( 'nexora_github_probe' );
							if ( ! is_array( $probe ) && function_exists( 'nexora_github_probe' ) && ! empty( $_GET['nexora_gh'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
								$probe = nexora_github_probe();
							}
							?>
							<p class="description" style="margin-top:8px">
								<?php
								$has_tok = function_exists( 'nexora_github_token' ) && nexora_github_token();
								$from_cfg = function_exists( 'nexora_github_token_from_wp_config' ) && nexora_github_token_from_wp_config();
								if ( $has_tok && $from_cfg ) {
									esc_html_e( 'Update access: ready (wp-config.php)', 'nexora' );
								} elseif ( $has_tok ) {
									esc_html_e( 'Update access: ready (saved under Advanced)', 'nexora' );
								} else {
									esc_html_e( 'Update access: add your token under Advanced to continue.', 'nexora' );
								}
								?>
							</p>
							<?php if ( is_array( $probe ) && ! empty( $probe['message'] ) ) : ?>
								<p><strong><?php echo esc_html( (string) $probe['message'] ); ?></strong>
								<?php if ( ! empty( $probe['code'] ) ) : ?>
									<code><?php echo esc_html( 'HTTP ' . (int) $probe['code'] ); ?></code>
								<?php endif; ?>
								</p>
							<?php endif; ?>
							<p>
								<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nexora_github_check' ), 'nexora_github_check' ) ); ?>"><?php esc_html_e( 'Check for updates', 'nexora' ); ?></a>
							</p>
						</td>
					</tr>
					<tr><th><?php esc_html_e( 'Site name', 'nexora' ); ?></th><td><?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?> · <a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=title_tagline' ) ); ?>"><?php esc_html_e( 'Site Identity', 'nexora' ); ?></a></td></tr>
					<tr><th><?php esc_html_e( 'AdSense', 'nexora' ); ?></th><td><?php echo $ads ? esc_html__( 'Configured', 'nexora' ) : esc_html__( 'Add publisher ID in Advertising', 'nexora' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Amazon tag', 'nexora' ); ?></th><td><?php echo nexora_amazon_tag() ? esc_html( nexora_amazon_tag() ) : esc_html__( 'Not set', 'nexora' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'SEO plugins', 'nexora' ); ?></th><td><?php echo function_exists( 'nexora_seo_plugin_active' ) && nexora_seo_plugin_active() ? esc_html__( 'Detected — theme skips duplicate meta', 'nexora' ) : esc_html__( 'Theme SEO active', 'nexora' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Quick links', 'nexora' ); ?></th><td>
						<a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>"><?php esc_html_e( 'Customizer', 'nexora' ); ?></a> ·
						<a href="<?php echo esc_url( admin_url( 'themes.php?page=' . nexora_settings_page_slug() . '&tab=redirects' ) ); ?>"><?php esc_html_e( '301', 'nexora' ); ?></a>
						<?php if ( defined( 'PWA_VERSION' ) ) : ?>
							· <a href="<?php echo esc_url( admin_url( 'admin.php?page=nexora-agents' ) ); ?>"><?php esc_html_e( 'AI Agents', 'nexora' ); ?></a>
						<?php else : ?>
							· <span><?php esc_html_e( 'Install Nexora Agents plugin for AI connections', 'nexora' ); ?></span>
						<?php endif; ?>
					</td></tr>
				</table>
				<p class="description"><?php esc_html_e( 'This theme stays lightweight. Cookie banner is a preference UI, not a certified CMP for EEA/UK/CH.', 'nexora' ); ?></p>

			<?php elseif ( 'niche' === $tab ) : ?>
				<p><?php esc_html_e( 'Niche presets change colors only. Posts, categories, site name, SEO, ads, and affiliate settings stay untouched.', 'nexora' ); ?></p>
				<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;max-width:960px;margin:16px 0">
					<?php foreach ( $presets as $slug => $preset ) :
						$tokens = isset( $preset['tokens'] ) ? $preset['tokens'] : array();
						$brand  = isset( $tokens['brand'] ) ? $tokens['brand'] : '#0F766E';
						$bg     = isset( $tokens['bg'] ) ? $tokens['bg'] : '#F4F7FB';
						?>
						<label style="display:block;border:2px solid <?php echo $active === $slug ? esc_attr( $brand ) : '#c3c4c7'; ?>;border-radius:10px;padding:14px;background:<?php echo esc_attr( $bg ); ?>;cursor:pointer">
							<input type="radio" name="niche_preset" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $active, $slug ); ?> style="margin-right:6px">
							<strong style="color:<?php echo esc_attr( isset( $tokens['ink'] ) ? $tokens['ink'] : '#1d1d1d' ); ?>"><?php echo esc_html( $preset['label'] ); ?></strong>
							<span style="display:flex;gap:4px;margin:10px 0 6px" aria-hidden="true">
								<span style="width:18px;height:18px;border-radius:4px;background:<?php echo esc_attr( $brand ); ?>"></span>
								<span style="width:18px;height:18px;border-radius:4px;background:<?php echo esc_attr( isset( $tokens['brand-2'] ) ? $tokens['brand-2'] : $brand ); ?>"></span>
								<span style="width:18px;height:18px;border-radius:4px;background:<?php echo esc_attr( isset( $tokens['accent'] ) ? $tokens['accent'] : $brand ); ?>"></span>
							</span>
							<span style="display:block;font-size:12px;color:<?php echo esc_attr( isset( $tokens['muted'] ) ? $tokens['muted'] : '#5B677A' ); ?>"><?php echo esc_html( $preset['description'] ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="developer_contact_url"><?php esc_html_e( 'Request a niche (contact URL)', 'nexora' ); ?></label></th>
						<td>
							<input name="developer_contact_url" id="developer_contact_url" type="url" class="regular-text" value="<?php echo esc_attr( $dev_url ); ?>" placeholder="https://">
							<p class="description"><?php esc_html_e( 'Optional. Shown as a link when empty niches are not listed. Leave blank to hide.', 'nexora' ); ?></p>
							<?php if ( $dev_url ) : ?>
								<p><a href="<?php echo esc_url( $dev_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Request a custom niche palette', 'nexora' ); ?></a></p>
							<?php endif; ?>
						</td>
					</tr>
				</table>

			<?php elseif ( 'branding' === $tab ) : ?>
				<?php
				$logo_id  = (int) get_theme_mod( 'custom_logo' );
				$icon_id  = (int) get_option( 'site_icon' );
				$logo_src = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
				$icon_src = $icon_id ? get_site_icon_url( 112 ) : '';
				$seo_title_ph = sprintf(
					/* translators: 1: tagline, 2: site name */
					__( '%1$s | %2$s', 'nexora' ),
					get_bloginfo( 'description', 'display' ) ?: __( 'Practical guides for curious readers.', 'nexora' ),
					get_bloginfo( 'name', 'display' )
				);
				$seo_desc_ph = function_exists( 'nexora_seo_blurb' ) ? nexora_seo_blurb() : get_bloginfo( 'description', 'display' );
				?>
				<p class="description"><?php esc_html_e( 'One place for site name, tagline, search snippet, logo, and favicon. Homepage hero and footer copy live under the Homepage tab — no duplicates.', 'nexora' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="blogname"><?php esc_html_e( 'Site name', 'nexora' ); ?></label></th>
						<td>
							<input name="blogname" id="blogname" type="text" class="regular-text" value="<?php echo esc_attr( get_option( 'blogname' ) ); ?>">
							<p class="description"><?php esc_html_e( 'Header wordmark (when no logo) and © line. Same as Settings → General → Site Title.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="blogdescription"><?php esc_html_e( 'Tagline', 'nexora' ); ?></label></th>
						<td>
							<input name="blogdescription" id="blogdescription" type="text" class="large-text" value="<?php echo esc_attr( get_option( 'blogdescription' ) ); ?>">
							<p class="description"><?php esc_html_e( 'Site Identity tagline. Used for SEO fallback and as footer brand text when Homepage → Footer brand info is empty.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="seo_home_title"><?php esc_html_e( 'SEO title (homepage)', 'nexora' ); ?></label></th>
						<td>
							<input name="seo_home_title" id="seo_home_title" type="text" class="large-text" value="<?php echo esc_attr( (string) nexora_get_option( 'seo_home_title' ) ); ?>" placeholder="<?php echo esc_attr( $seo_title_ph ); ?>">
							<p class="description"><?php esc_html_e( 'Browser tab / Google title for the homepage. Empty = Tagline | Site name. Skipped when Yoast/Rank Math is active.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="seo_home_description"><?php esc_html_e( 'SEO description (homepage)', 'nexora' ); ?></label></th>
						<td>
							<textarea name="seo_home_description" id="seo_home_description" class="large-text" rows="3" placeholder="<?php echo esc_attr( (string) $seo_desc_ph ); ?>"><?php echo esc_textarea( (string) nexora_get_option( 'seo_home_description' ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Meta description for the homepage. Empty = tagline. Verification tokens stay under the SEO tab.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Logo', 'nexora' ); ?></th>
						<td>
							<input type="hidden" name="custom_logo_id" id="custom_logo_id" value="<?php echo esc_attr( (string) $logo_id ); ?>">
							<p>
								<img id="nexora-logo-preview" src="<?php echo $logo_src ? esc_url( $logo_src ) : ''; ?>" alt="" style="max-height:48px;width:auto;max-width:240px;<?php echo $logo_src ? '' : 'display:none;'; ?>background:#fff;border:1px solid #ccd0d4;border-radius:6px;padding:6px;object-fit:contain;vertical-align:middle;margin-right:8px">
								<button type="button" class="button" id="nexora-pick-logo" data-title="<?php esc_attr_e( 'Select logo', 'nexora' ); ?>" data-button="<?php esc_attr_e( 'Use logo', 'nexora' ); ?>"><?php esc_html_e( 'Select logo', 'nexora' ); ?></button>
								<button type="button" class="button button-link-delete" id="nexora-clear-logo"><?php esc_html_e( 'Remove', 'nexora' ); ?></button>
							</p>
							<p class="description"><?php esc_html_e( 'Header and footer. Wide wordmarks keep natural aspect — not forced square.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Site Icon (favicon)', 'nexora' ); ?></th>
						<td>
							<input type="hidden" name="site_icon_id" id="site_icon_id" value="<?php echo esc_attr( (string) $icon_id ); ?>">
							<p>
								<img id="nexora-icon-preview" src="<?php echo $icon_src ? esc_url( $icon_src ) : ''; ?>" alt="" width="48" height="48" style="<?php echo $icon_src ? '' : 'display:none;'; ?>background:#fff;border:1px solid #ccd0d4;border-radius:6px;padding:4px;object-fit:contain;vertical-align:middle;margin-right:8px">
								<button type="button" class="button" id="nexora-pick-icon" data-title="<?php esc_attr_e( 'Select Site Icon', 'nexora' ); ?>" data-button="<?php esc_attr_e( 'Use icon', 'nexora' ); ?>"><?php esc_html_e( 'Select icon', 'nexora' ); ?></button>
								<button type="button" class="button button-link-delete" id="nexora-clear-icon"><?php esc_html_e( 'Remove', 'nexora' ); ?></button>
							</p>
							<p class="description"><?php esc_html_e( 'Browser tab favicon. Prefer a square image (at least 512×512).', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="ghl_affiliate_url"><?php esc_html_e( 'Primary CTA / affiliate URL', 'nexora' ); ?></label></th>
						<td><input name="ghl_affiliate_url" id="ghl_affiliate_url" type="url" class="regular-text" value="<?php echo esc_attr( $url ); ?>"></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Preloader', 'nexora' ); ?></th>
						<td><label><input type="checkbox" name="preloader_enabled" value="1" <?php checked( nexora_get_option( 'preloader_enabled' ) ); ?>> <?php esc_html_e( 'Brand mark loader (optional — off by default for faster first paint)', 'nexora' ); ?></label></td>
					</tr>
				</table>

			<?php elseif ( 'homepage' === $tab ) : ?>
				<p class="description"><?php esc_html_e( 'Homepage hero plus footer brand, disclaimer, newsletter, and contact email — everything visitors see on the home/footer chrome. Site name, tagline, SEO title/description, and logo live under Branding.', 'nexora' ); ?></p>
				<h2 class="title"><?php esc_html_e( 'Hero', 'nexora' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="home_h1"><?php esc_html_e( 'Homepage H1', 'nexora' ); ?></label></th>
						<td>
							<input name="home_h1" id="home_h1" type="text" class="large-text" value="<?php echo esc_attr( (string) nexora_get_option( 'home_h1' ) ); ?>" placeholder="<?php echo esc_attr( nexora_home_h1() ); ?>">
							<p class="description"><?php esc_html_e( 'Large homepage headline. Empty → Branding tagline → generic.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="home_lede"><?php esc_html_e( 'Homepage description', 'nexora' ); ?></label></th>
						<td>
							<textarea name="home_lede" id="home_lede" class="large-text" rows="4" placeholder="<?php echo esc_attr( nexora_home_lede() ); ?>"><?php echo esc_textarea( (string) nexora_get_option( 'home_lede' ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Paragraph under the H1.', 'nexora' ); ?></p>
						</td>
					</tr>
				</table>
				<h2 class="title"><?php esc_html_e( 'Footer', 'nexora' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="footer_blurb"><?php esc_html_e( 'Footer brand info', 'nexora' ); ?></label></th>
						<td>
							<textarea name="footer_blurb" id="footer_blurb" class="large-text" rows="2" placeholder="<?php echo esc_attr( nexora_footer_blurb() ); ?>"><?php echo esc_textarea( (string) nexora_get_option( 'footer_blurb' ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Text under the footer logo. Empty → Branding tagline.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="footer_disclosure"><?php esc_html_e( 'Disclaimer', 'nexora' ); ?></label></th>
						<td>
							<textarea name="footer_disclosure" id="footer_disclosure" class="large-text" rows="3"><?php echo esc_textarea( (string) get_theme_mod( 'footer_disclosure', nexora_default_disclosure() ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Footer Disclaimer column (also used on the Disclosure page).', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="newsletter_eyebrow"><?php esc_html_e( 'Newsletter label', 'nexora' ); ?></label></th>
						<td>
							<input name="newsletter_eyebrow" id="newsletter_eyebrow" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'newsletter_eyebrow' ) ); ?>" placeholder="<?php echo esc_attr( nexora_newsletter_eyebrow() ); ?>">
						</td>
					</tr>
					<tr>
						<th><label for="newsletter_lede"><?php esc_html_e( 'Newsletter copy', 'nexora' ); ?></label></th>
						<td>
							<textarea name="newsletter_lede" id="newsletter_lede" class="large-text" rows="3" placeholder="<?php echo esc_attr( nexora_newsletter_lede() ); ?>"><?php echo esc_textarea( (string) nexora_get_option( 'newsletter_lede' ) ); ?></textarea>
						</td>
					</tr>
					<tr>
						<th><label for="newsletter_placeholder"><?php esc_html_e( 'Newsletter placeholder', 'nexora' ); ?></label></th>
						<td>
							<input name="newsletter_placeholder" id="newsletter_placeholder" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'newsletter_placeholder' ) ); ?>" placeholder="<?php echo esc_attr( nexora_newsletter_placeholder() ); ?>">
							<p class="description"><?php esc_html_e( 'Email field placeholder (e.g. Your email).', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="contact_email"><?php esc_html_e( 'Contact email', 'nexora' ); ?></label></th>
						<td>
							<input name="contact_email" id="contact_email" type="email" class="regular-text" value="<?php echo esc_attr( $email ); ?>">
							<p class="description"><?php esc_html_e( 'Shown in the footer and used as the contact-form inbox.', 'nexora' ); ?></p>
						</td>
					</tr>
				</table>

			<?php elseif ( 'article' === $tab ) : ?>
				<table class="form-table" role="presentation">
					<tr><th><?php esc_html_e( 'Article meta line', 'nexora' ); ?></th><td>
						<label><input type="checkbox" name="article_meta_author" value="1" <?php checked( nexora_get_option( 'article_meta_author' ) ); ?>> <?php esc_html_e( 'Author name (“By …”)', 'nexora' ); ?></label><br>
						<label><input type="checkbox" name="article_meta_date" value="1" <?php checked( nexora_get_option( 'article_meta_date' ) ); ?>> <?php esc_html_e( 'Published date', 'nexora' ); ?></label><br>
						<label><input type="checkbox" name="article_updated_date" value="1" <?php checked( nexora_get_option( 'article_updated_date' ) ); ?>> <?php esc_html_e( 'Prefer “Last updated” when different from published', 'nexora' ); ?></label><br>
						<label><input type="checkbox" name="article_reading_time" value="1" <?php checked( nexora_get_option( 'article_reading_time' ) ); ?>> <?php esc_html_e( 'Reading time', 'nexora' ); ?></label>
					</td></tr>
					<tr><th><?php esc_html_e( 'Article features', 'nexora' ); ?></th><td>
						<label><input type="checkbox" name="article_toc" value="1" <?php checked( nexora_get_option( 'article_toc' ) ); ?>> <?php esc_html_e( 'Table of contents', 'nexora' ); ?></label><br>
						<label><input type="checkbox" name="article_author_box" value="1" <?php checked( nexora_get_option( 'article_author_box' ) ); ?>> <?php esc_html_e( 'Author box', 'nexora' ); ?></label><br>
						<label><input type="checkbox" name="article_breadcrumbs" value="1" <?php checked( nexora_get_option( 'article_breadcrumbs' ) ); ?>> <?php esc_html_e( 'Breadcrumbs', 'nexora' ); ?></label>
					</td></tr>
				</table>

			<?php elseif ( 'performance' === $tab ) : ?>
				<p class="description"><?php esc_html_e( 'Homepage SEO title and description are under Branding. This tab is for verification tokens and analytics reference.', 'nexora' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="ga4_measurement_id"><?php esc_html_e( 'GA4 measurement ID', 'nexora' ); ?></label></th>
						<td>
							<input name="ga4_measurement_id" id="ga4_measurement_id" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'ga4_measurement_id' ) ); ?>" placeholder="G-XXXXXXXXXX" pattern="G-[A-Za-z0-9]+">
							<p class="description"><?php esc_html_e( 'Optional reference only — paste this into Yoast / Site Kit. Nexora does not load Google Analytics itself.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="gsc_verification"><?php esc_html_e( 'Google Search Console', 'nexora' ); ?></label></th>
						<td>
							<input name="gsc_verification" id="gsc_verification" type="text" class="large-text" value="<?php echo esc_attr( (string) nexora_get_option( 'gsc_verification' ) ); ?>" placeholder="<?php esc_attr_e( 'Verification content token', 'nexora' ); ?>">
							<p class="description"><?php esc_html_e( 'Optional Google site verification meta token. Leave empty if Yoast already verifies the site.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="bing_verification"><?php esc_html_e( 'Bing Webmaster Tools', 'nexora' ); ?></label></th>
						<td>
							<input name="bing_verification" id="bing_verification" type="text" class="large-text" value="<?php echo esc_attr( (string) nexora_get_option( 'bing_verification' ) ); ?>" placeholder="<?php esc_attr_e( 'msvalidate.01 content token', 'nexora' ); ?>">
							<p class="description"><?php esc_html_e( 'Optional Bing Webmaster verification meta token.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Notes', 'nexora' ); ?></th>
						<td><p class="description"><?php esc_html_e( 'Critical CSS, lazy images, and font loading stay in theme code. Measure Lighthouse on staging only — do not invent scores.', 'nexora' ); ?></p></td>
					</tr>
				</table>

			<?php elseif ( 'ads' === $tab ) : ?>
				<table class="form-table" role="presentation">
					<tr><th><?php esc_html_e( 'Global', 'nexora' ); ?></th><td>
						<label><input type="checkbox" name="ads_enabled" value="1" <?php checked( nexora_get_option( 'ads_enabled' ) ); ?>> <?php esc_html_e( 'Enable advertising', 'nexora' ); ?></label>
					</td></tr>
					<tr>
						<th><label for="adsense_client"><?php esc_html_e( 'AdSense publisher ID', 'nexora' ); ?></label></th>
						<td><input name="adsense_client" id="adsense_client" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'adsense_client' ) ); ?>" placeholder="ca-pub-xxxxxxxxxxxxxxxx"></td>
					</tr>
					<tr><th><?php esc_html_e( 'Auto ads', 'nexora' ); ?></th><td>
						<label><input type="checkbox" name="adsense_auto_ads" value="1" <?php checked( nexora_get_option( 'adsense_auto_ads' ) ); ?>> <?php esc_html_e( 'Enable AdSense Auto ads', 'nexora' ); ?></label>
					</td></tr>
					<tr>
						<th><label for="adsense_slot_in_article"><?php esc_html_e( 'Default in-article slot', 'nexora' ); ?></label></th>
						<td><input name="adsense_slot_in_article" id="adsense_slot_in_article" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'adsense_slot_in_article' ) ); ?>"></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Exclude categories', 'nexora' ); ?></th>
						<td>
							<?php
							$cats = get_categories( array( 'hide_empty' => false ) );
							if ( $cats ) :
								foreach ( $cats as $cat ) :
									?>
									<label style="display:inline-block;margin:0 12px 8px 0">
										<input type="checkbox" name="ads_exclude_categories[]" value="<?php echo esc_attr( (string) (int) $cat->term_id ); ?>" <?php checked( in_array( (int) $cat->term_id, array_map( 'intval', $exclude ), true ) ); ?>>
										<?php echo esc_html( $cat->name ); ?>
									</label>
									<?php
								endforeach;
							else :
								esc_html_e( 'No categories yet.', 'nexora' );
							endif;
							?>
							<p class="description"><?php esc_html_e( 'Hide theme ad slots on posts in these categories. Per-post “Disable ads” meta still applies.', 'nexora' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Visual placement map', 'nexora' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Green = enabled. Toggle On plus Desktop / Mobile per slot. Preview is schematic, not a live page render.', 'nexora' ); ?></p>
				<div style="max-width:520px;border:1px solid #c3c4c7;border-radius:8px;padding:12px;background:#f6f7f7;font-size:12px;line-height:1.4">
					<?php
					$map_order  = array( 'below_nav', 'hero_left', 'hero_right', 'below_title', 'after_image', 'rail_before_toc', 'rail_after_toc', 'rail_after_newsletter', 'rail_right_top', 'rail_right_bottom', 'before_content', 'after_p2', 'after_p4', 'end_content', 'between_cards', 'footer' );
					$placements = nexora_ad_placements();
					foreach ( $map_order as $key ) :
						if ( empty( $placements[ $key ] ) ) {
							continue;
						}
						$row = $placements[ $key ];
						$on  = ! empty( $row['enabled'] );
						$bg  = $on ? '#d1fae5' : '#fff';
						$bd  = $on ? '#059669' : '#d0d5dd';
						?>
						<div style="margin:6px 0;padding:8px 10px;border:1px solid <?php echo esc_attr( $bd ); ?>;background:<?php echo esc_attr( $bg ); ?>;border-radius:6px">
							<strong><?php echo esc_html( $row['label'] ); ?></strong>
							<span style="color:#667085"> · <code><?php echo esc_html( $key ); ?></code></span>
						</div>
					<?php endforeach; ?>
				</div>

				<h2><?php esc_html_e( 'Placement rules', 'nexora' ); ?></h2>
				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Slot', 'nexora' ); ?></th>
							<th><?php esc_html_e( 'On', 'nexora' ); ?></th>
							<th><?php esc_html_e( 'Desktop', 'nexora' ); ?></th>
							<th><?php esc_html_e( 'Mobile', 'nexora' ); ?></th>
							<th><?php esc_html_e( 'Ad unit ID', 'nexora' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( nexora_ad_placements() as $key => $row ) : ?>
						<tr>
							<td><?php echo esc_html( $row['label'] ); ?><br><code><?php echo esc_html( $key ); ?></code></td>
							<td><input type="checkbox" name="ad_placements[<?php echo esc_attr( $key ); ?>][enabled]" value="1" <?php checked( ! empty( $row['enabled'] ) ); ?>></td>
							<td><input type="checkbox" name="ad_placements[<?php echo esc_attr( $key ); ?>][desktop]" value="1" <?php checked( ! empty( $row['desktop'] ) ); ?>></td>
							<td><input type="checkbox" name="ad_placements[<?php echo esc_attr( $key ); ?>][mobile]" value="1" <?php checked( ! empty( $row['mobile'] ) ); ?>></td>
							<td><input type="text" class="regular-text" name="ad_placements[<?php echo esc_attr( $key ); ?>][slot]" value="<?php echo esc_attr( $row['slot'] ); ?>"></td>
						</tr>
						<?php if ( current_user_can( 'unfiltered_html' ) ) : ?>
						<tr>
							<td colspan="5">
								<label><?php esc_html_e( 'Optional custom ad HTML', 'nexora' ); ?></label>
								<textarea class="large-text code" rows="2" name="ad_placements[<?php echo esc_attr( $key ); ?>][code]"><?php echo esc_textarea( $row['code'] ); ?></textarea>
							</td>
						</tr>
						<?php endif; ?>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Blocks: Ad placement. Shortcode: [nexora_ad placement="end_content"].', 'nexora' ); ?></p>

			<?php elseif ( 'revenue' === $tab ) : ?>
				<?php
				$stats = function_exists( 'nexora_aff_click_stats' ) ? nexora_aff_click_stats( 30 ) : array( 'total' => 0, 'by_url' => array(), 'by_post' => array(), 'by_device' => array(), 'days' => 30 );
				?>
				<p><?php esc_html_e( 'Affiliate clicks below are measured on this site. Amazon commissions and AdSense earnings are not invented from clicks — enter AdSense figures from your AdSense reports, or connect GA4 for event analysis.', 'nexora' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th><?php esc_html_e( 'Affiliate click tracking', 'nexora' ); ?></th>
						<td><label><input type="checkbox" name="aff_track_clicks" value="1" <?php checked( nexora_get_option( 'aff_track_clicks' ) ); ?>> <?php esc_html_e( 'Record outbound affiliate clicks + send GA4 event affiliate_click when analytics consent is granted', 'nexora' ); ?></label></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Clicks (last 30 days)', 'nexora' ); ?></th>
						<td><strong style="font-size:1.5rem"><?php echo esc_html( (string) (int) $stats['total'] ); ?></strong></td>
					</tr>
					<tr>
						<th><label for="adsense_manual_revenue"><?php esc_html_e( 'AdSense revenue (manual)', 'nexora' ); ?></label></th>
						<td><input name="adsense_manual_revenue" id="adsense_manual_revenue" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'adsense_manual_revenue' ) ); ?>" placeholder="e.g. 128.40 USD">
						<p class="description"><?php esc_html_e( 'Paste from AdSense → Reports. Not calculated from pageviews.', 'nexora' ); ?></p></td>
					</tr>
					<tr>
						<th><label for="adsense_manual_rpm"><?php esc_html_e( 'Page RPM (manual)', 'nexora' ); ?></label></th>
						<td><input name="adsense_manual_rpm" id="adsense_manual_rpm" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'adsense_manual_rpm' ) ); ?>" placeholder="e.g. 4.20"></td>
					</tr>
					<tr>
						<th><label for="adsense_manual_note"><?php esc_html_e( 'Report note', 'nexora' ); ?></label></th>
						<td><textarea name="adsense_manual_note" id="adsense_manual_note" class="large-text" rows="2"><?php echo esc_textarea( (string) nexora_get_option( 'adsense_manual_note' ) ); ?></textarea></td>
					</tr>
				</table>
				<?php if ( ! empty( $stats['by_url'] ) ) : ?>
					<h2><?php esc_html_e( 'Top affiliate destinations', 'nexora' ); ?></h2>
					<table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Label / URL', 'nexora' ); ?></th><th><?php esc_html_e( 'Clicks', 'nexora' ); ?></th></tr></thead><tbody>
					<?php foreach ( $stats['by_url'] as $row ) : ?>
						<tr>
							<td><?php echo esc_html( $row['label'] ? $row['label'] : $row['url'] ); ?><br><code style="font-size:11px"><?php echo esc_html( $row['url'] ); ?></code></td>
							<td><?php echo esc_html( (string) $row['clicks'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody></table>
				<?php endif; ?>
				<?php if ( ! empty( $stats['by_post'] ) ) : ?>
					<h2><?php esc_html_e( 'Clicks by post', 'nexora' ); ?></h2>
					<table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Post', 'nexora' ); ?></th><th><?php esc_html_e( 'Clicks', 'nexora' ); ?></th></tr></thead><tbody>
					<?php foreach ( $stats['by_post'] as $row ) : ?>
						<tr>
							<td><?php echo esc_html( get_the_title( (int) $row['post_id'] ) ?: ( '#' . $row['post_id'] ) ); ?></td>
							<td><?php echo esc_html( (string) $row['clicks'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody></table>
				<?php endif; ?>

			<?php elseif ( 'affiliate' === $tab ) : ?>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="amazon_tracking_id"><?php esc_html_e( 'Amazon Associates tag', 'nexora' ); ?></label></th>
						<td>
							<input name="amazon_tracking_id" id="amazon_tracking_id" type="text" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'amazon_tracking_id' ) ); ?>" placeholder="yourtag-20">
							<?php if ( function_exists( 'pwa_get_affiliate_tracking_id' ) ) : ?>
								<p class="description"><?php esc_html_e( 'Also synced to the Agents companion plugin so the tag survives a theme swap.', 'nexora' ); ?></p>
							<?php else : ?>
								<p class="description"><?php esc_html_e( 'Install Nexora Agents to store this tag in a durable plugin option.', 'nexora' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><label for="affiliate_disclosure"><?php esc_html_e( 'Product-card disclosure', 'nexora' ); ?></label></th>
						<td>
							<textarea name="affiliate_disclosure" id="affiliate_disclosure" class="large-text" rows="3"><?php echo esc_textarea( (string) nexora_get_option( 'affiliate_disclosure' ) ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Shown on product cards. Site-wide footer disclaimer is under Homepage → Disclaimer.', 'nexora' ); ?></p>
						</td>
					</tr>
				</table>
				<p><strong><?php esc_html_e( 'Shortcodes', 'nexora' ); ?></strong></p>
				<p><code>[nexora_product name="Product" url="https://www.amazon.com/dp/ASIN" image="" pros="A|B" cons="C" features="X|Y" cta="Check price" badge="Editor's pick"]Description[/nexora_product]</code></p>
				<p><code>[nexora_compare]Name|Why it matters|https://...[/nexora_compare]</code></p>
				<p class="description"><?php esc_html_e( 'No Amazon scraping. Enter your own product copy and approved assets. Links use rel="sponsored".', 'nexora' ); ?></p>

			<?php elseif ( 'privacy' === $tab ) : ?>
				<?php
				$cmp = function_exists( 'nexora_certified_cmp_detected' ) && nexora_certified_cmp_detected();
				?>
				<table class="form-table" role="presentation">
					<tr><th><?php esc_html_e( 'Cookie banner', 'nexora' ); ?></th><td>
						<label><input type="checkbox" name="cookie_banner" value="1" <?php checked( nexora_get_option( 'cookie_banner' ) ); ?>> <?php esc_html_e( 'Show preference banner (Consent Mode v2 defaults denied until accept)', 'nexora' ); ?></label>
						<?php if ( $cmp ) : ?>
							<p class="notice notice-info inline" style="margin:8px 0 0;padding:8px 12px"><strong><?php esc_html_e( 'Certified CMP detected.', 'nexora' ); ?></strong> <?php esc_html_e( 'Theme banner stays hidden so the CMP can own consent.', 'nexora' ); ?></p>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'Not a Google-certified CMP. For EEA/UK/Switzerland publisher traffic, install a certified CMP — the theme banner will hide automatically when one is detected.', 'nexora' ); ?></p>
						<?php endif; ?>
					</td></tr>
					<tr>
						<th><label for="privacy_policy_url"><?php esc_html_e( 'Privacy policy URL override', 'nexora' ); ?></label></th>
						<td><input name="privacy_policy_url" id="privacy_policy_url" type="url" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'privacy_policy_url' ) ); ?>"></td>
					</tr>
					<tr>
						<th><label for="cookie_policy_url"><?php esc_html_e( 'Cookie policy URL override', 'nexora' ); ?></label></th>
						<td><input name="cookie_policy_url" id="cookie_policy_url" type="url" class="regular-text" value="<?php echo esc_attr( (string) nexora_get_option( 'cookie_policy_url' ) ); ?>"></td>
					</tr>
				</table>

			<?php elseif ( 'ai' === $tab ) : ?>
				<?php if ( defined( 'PWA_VERSION' ) ) : ?>
					<p><?php esc_html_e( 'AI connections, permissions, approval queue, and activity logs live in the companion plugin. The theme only deep-links here.', 'nexora' ); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=nexora-agents' ) ); ?>"><?php esc_html_e( 'Open AI Agents', 'nexora' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=nexora-agents&tab=approval' ) ); ?>"><?php esc_html_e( 'Approval queue', 'nexora' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=nexora-agents&tab=logs' ) ); ?>"><?php esc_html_e( 'Activity logs', 'nexora' ); ?></a></p>
					<p class="description"><?php printf( /* translators: %s: plugin version */ esc_html__( 'Plugin version %s', 'nexora' ), esc_html( PWA_VERSION ) ); ?></p>
				<?php else : ?>
					<p><?php esc_html_e( 'Install and activate the Nexora Agents plugin to connect AI agents with granular permissions, an approval queue, and activity logs.', 'nexora' ); ?></p>
					<p class="description"><?php esc_html_e( 'Companion plugin display name: Nexora Agents.', 'nexora' ); ?></p>
				<?php endif; ?>

			<?php elseif ( 'advanced' === $tab ) : ?>
				<?php
				$from_cfg   = function_exists( 'nexora_github_token_from_wp_config' ) && nexora_github_token_from_wp_config();
				$has_token  = function_exists( 'nexora_github_token' ) && (bool) nexora_github_token();
				$stored_tok = (string) get_option( 'nexora_github_token', '' );
				$mask       = '';
				if ( $stored_tok && ! $from_cfg ) {
					$len  = strlen( $stored_tok );
					$mask = $len > 8 ? ( substr( $stored_tok, 0, 4 ) . str_repeat( '•', max( 8, $len - 8 ) ) . substr( $stored_tok, -4 ) ) : '••••••••';
				}
				?>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="nexora_github_token"><?php esc_html_e( 'Theme updates', 'nexora' ); ?></label></th>
						<td>
							<p>
								<?php if ( $from_cfg ) : ?>
									<strong style="color:#008a20"><?php esc_html_e( 'Using token from wp-config.php (overrides the field below).', 'nexora' ); ?></strong>
								<?php elseif ( $has_token ) : ?>
									<strong style="color:#008a20"><?php esc_html_e( 'Update token saved — you can check for new theme versions.', 'nexora' ); ?></strong>
									<?php if ( $mask ) : ?>
										<code style="margin-left:6px"><?php echo esc_html( $mask ); ?></code>
									<?php endif; ?>
								<?php else : ?>
									<strong style="color:#b32d2e"><?php esc_html_e( 'No update token yet — paste the token from your license email and Save.', 'nexora' ); ?></strong>
								<?php endif; ?>
							</p>
							<p class="description" style="max-width:40rem">
								<?php esc_html_e( 'Your Nexora purchase / license email includes the update token. Paste it below — do not invent a token yourself.', 'nexora' ); ?>
							</p>
							<ol style="margin:12px 0 12px 1.25em; max-width:40rem; line-height:1.55">
								<li><?php esc_html_e( 'Open your Nexora purchase / license email and copy the update token.', 'nexora' ); ?></li>
								<li><?php esc_html_e( 'Paste it in the field below → Save settings.', 'nexora' ); ?></li>
								<li><?php esc_html_e( 'Click “Check for updates”. When a newer release exists: Appearance → Themes → Update.', 'nexora' ); ?></li>
								<li><?php esc_html_e( 'Lost the email? Contact the theme seller for a replacement token.', 'nexora' ); ?></li>
							</ol>
							<p>
								<input
									name="nexora_github_token"
									id="nexora_github_token"
									type="password"
									class="regular-text code"
									value=""
									autocomplete="off"
									spellcheck="false"
									<?php disabled( $from_cfg ); ?>
									placeholder="<?php echo $has_token && ! $from_cfg ? esc_attr__( 'Leave blank to keep the saved token', 'nexora' ) : esc_attr__( 'Paste token from your purchase email', 'nexora' ); ?>"
								>
							</p>
							<?php if ( $has_token && ! $from_cfg ) : ?>
								<p><label><input type="checkbox" name="nexora_github_token_clear" value="1"> <?php esc_html_e( 'Remove saved token', 'nexora' ); ?></label></p>
							<?php endif; ?>
							<p class="description"><?php esc_html_e( 'Optional (advanced hosts): put the same token in wp-config.php as NEXORA_UPDATE_TOKEN — that overrides this field.', 'nexora' ); ?></p>
							<p>
								<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nexora_github_check' ), 'nexora_github_check' ) ); ?>"><?php esc_html_e( 'Check for updates', 'nexora' ); ?></a>
								<a class="button" href="<?php echo esc_url( admin_url( 'themes.php' ) ); ?>"><?php esc_html_e( 'Appearance → Themes', 'nexora' ); ?></a>
							</p>
							<?php
							$probe = get_transient( 'nexora_github_probe' );
							if ( is_array( $probe ) && ! empty( $probe['message'] ) ) :
								?>
								<p><strong><?php echo esc_html( (string) $probe['message'] ); ?></strong>
								<?php if ( ! empty( $probe['code'] ) ) : ?>
									<code><?php echo esc_html( 'HTTP ' . (int) $probe['code'] ); ?></code>
								<?php endif; ?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Package identity', 'nexora' ); ?></th>
						<td>
							<strong><?php echo esc_html( nexora_settings_menu_label() ); ?></strong>
							· admin <code>Appearance → Nexora</code>
							· stylesheet <code>nexora</code>
							<p class="description"><?php esc_html_e( 'All theme features live under Appearance → Nexora.', 'nexora' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Content protection', 'nexora' ); ?></th>
						<td><?php esc_html_e( 'Niche switches write only niche_preset (+ developer contact URL). Live page content is never overwritten by theme updates.', 'nexora' ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( '301', 'nexora' ); ?></th>
						<td><a href="<?php echo esc_url( admin_url( 'themes.php?page=' . nexora_settings_page_slug() . '&tab=redirects' ) ); ?>"><?php esc_html_e( 'Appearance → Nexora → 301', 'nexora' ); ?></a></td>
					</tr>
				</table>

			<?php elseif ( 'redirects' === $tab ) : ?>
				<?php
				if ( function_exists( 'nexora_cta_admin_page' ) ) {
					nexora_cta_admin_page( true );
				}
				?>
			<?php endif; ?>

			<?php if ( ! $standalone ) : ?>
				<?php submit_button( __( 'Save settings', 'nexora' ) ); ?>
		</form>
			<?php endif; ?>
	</div>
	<?php
}
