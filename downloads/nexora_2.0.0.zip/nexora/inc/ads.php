<?php
/**
 * Google AdSense placements and script loading.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Publisher client ID.
 *
 * @return string
 */
function nexora_adsense_client() {
	$client = trim( (string) nexora_get_option( 'adsense_client' ) );
	return preg_match( '/^ca-pub-\d+$/', $client ) ? $client : '';
}

/**
 * Whether AdSense script may print (theme settings only; consent gated in JS).
 *
 * @return bool
 */
function nexora_adsense_enabled() {
	return function_exists( 'nexora_ads_allowed' ) && nexora_ads_allowed();
}

/**
 * Head script + Consent Mode defaults. Ads wait for consent when banner is on.
 */
function nexora_adsense_head() {
	if ( is_admin() || ! nexora_adsense_enabled() ) {
		return;
	}
	if ( nexora_ads_category_excluded() ) {
		return;
	}
	if ( nexora_adsense_script_already_present() ) {
		return;
	}
	$client = nexora_adsense_client();
	// Consent Mode v2 defaults when theme banner is on and no certified CMP owns consent.
	$consent = (bool) nexora_get_option( 'cookie_banner' );
	if ( function_exists( 'nexora_certified_cmp_detected' ) && nexora_certified_cmp_detected() ) {
		$consent = false;
	}

	echo "<script>\n";
	echo "window.dataLayer = window.dataLayer || [];\n";
	echo "function gtag(){dataLayer.push(arguments);}\n";
	if ( $consent ) {
		echo "gtag('consent', 'default', { ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', analytics_storage: 'denied', wait_for_update: 500 });\n";
	}
	echo "</script>\n";

	printf(
		'<script async src="%s" crossorigin="anonymous" data-nexora-adsense="1"></script>' . "\n",
		esc_url( 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . rawurlencode( $client ) )
	);

	if ( nexora_get_option( 'adsense_auto_ads' ) ) {
		echo '<script>window.nexoraLoadAutoAds = function () { (adsbygoogle = window.adsbygoogle || []).push({ google_ad_client: "' . esc_js( $client ) . '", enable_page_level_ads: true }); };</script>' . "\n";
		if ( ! $consent ) {
			echo '<script>window.nexoraLoadAutoAds && window.nexoraLoadAutoAds();</script>' . "\n";
		}
	}
}
add_action( 'wp_head', 'nexora_adsense_head', 6 );

/**
 * Render a placement by key.
 *
 * @param string $key Placement key.
 * @return string
 */
/**
 * Whether the current view is excluded from theme ads (category list).
 *
 * @return bool
 */
function nexora_ads_category_excluded() {
	$ids = array_map( 'intval', (array) nexora_get_option( 'ads_exclude_categories' ) );
	$ids = array_filter( $ids );
	if ( ! $ids ) {
		return false;
	}
	if ( is_singular( 'post' ) ) {
		return has_category( $ids );
	}
	if ( is_category( $ids ) ) {
		return true;
	}
	return false;
}

/**
 * Prevent duplicate AdSense loader if another plugin already printed it.
 *
 * @return bool
 */
function nexora_adsense_script_already_present() {
	return (bool) apply_filters( 'nexora_adsense_script_already_present', false );
}

function nexora_render_ad_placement( $key ) {
	if ( ! nexora_adsense_enabled() ) {
		return '';
	}
	if ( nexora_ads_category_excluded() ) {
		return '';
	}
	if ( is_singular() && nexora_post_meta_with_legacy( get_queried_object_id(), '_nexora_disable_ads', '_paulworld_disable_ads' ) ) {
		return '';
	}

	$placements = nexora_ad_placements();
	if ( empty( $placements[ $key ] ) || empty( $placements[ $key ]['enabled'] ) ) {
		// Backward-compat: after_p2 uses legacy in-article toggle.
		if ( 'after_p2' === $key && nexora_get_option( 'adsense_in_article' ) ) {
			$slot = (string) nexora_get_option( 'adsense_slot_in_article' );
			return nexora_adsense_unit_html( $slot, 'fluid' );
		}
		return '';
	}

	$row = $placements[ $key ];
	if ( function_exists( 'nexora_ad_device_ok' ) && ! nexora_ad_device_ok( $row ) ) {
		return '';
	}
	$device_class = ' nexora-ad--' . ( wp_is_mobile() ? 'mobile' : 'desktop' );
	if ( ! empty( $row['code'] ) ) {
		// Code is only stored when an admin with unfiltered_html saved it.
		return '<div class="nexora-ad' . $device_class . '" data-ad="custom" data-placement="' . esc_attr( $key ) . '">' . $row['code'] . '</div>';
	}

	$slot = ! empty( $row['slot'] ) ? $row['slot'] : '';
	if ( 'after_p2' === $key && ! $slot ) {
		$slot = (string) nexora_get_option( 'adsense_slot_in_article' );
	}
	$html = nexora_adsense_unit_html( $slot, 'auto' );
	if ( '' === $html ) {
		return '';
	}
	$html = str_replace( 'class="nexora-ad"', 'class="nexora-ad' . $device_class . '"', $html );
	return str_replace( 'data-ad="adsense"', 'data-ad="adsense" data-placement="' . esc_attr( $key ) . '"', $html );
}

/**
 * Echo a placement.
 *
 * @param string $key Placement key.
 */
function nexora_ad_slot( $key ) {
	echo nexora_render_ad_placement( $key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ad HTML from admin/unit builder.
}

/**
 * Build a responsive AdSense unit.
 *
 * @param string $slot   Slot ID.
 * @param string $format Format.
 * @return string
 */
function nexora_adsense_unit_html( $slot = '', $format = 'auto' ) {
	if ( ! nexora_adsense_enabled() ) {
		return '';
	}
	$client = nexora_adsense_client();
	$slot   = preg_replace( '/\D+/', '', (string) $slot );
	$format = in_array( $format, array( 'auto', 'fluid', 'rectangle' ), true ) ? $format : 'auto';

	ob_start();
	?>
	<div class="nexora-ad" data-ad="adsense">
		<ins class="adsbygoogle"
			style="display:block;min-height:90px"
			data-ad-client="<?php echo esc_attr( $client ); ?>"
			<?php if ( $slot ) : ?>
				data-ad-slot="<?php echo esc_attr( $slot ); ?>"
			<?php endif; ?>
			data-ad-format="<?php echo esc_attr( $format ); ?>"
			data-full-width-responsive="true"></ins>
		<script>
		(function(){
			function push(){ try { (adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {} }
			if (window.nexoraAdsConsent === false) { window.nexoraPendingAds = window.nexoraPendingAds || []; window.nexoraPendingAds.push(push); return; }
			push();
		})();
		</script>
	</div>
	<?php
	return (string) ob_get_clean();
}

/**
 * Shortcode [nexora_ad placement="end_content"] or [nexora_ad slot="123"].
 *
 * @param array $atts Attributes.
 * @return string
 */
function nexora_ad_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'placement' => '',
			'slot'      => '',
			'format'    => 'auto',
		),
		$atts,
		'nexora_ad'
	);
	if ( $atts['placement'] ) {
		return nexora_render_ad_placement( sanitize_key( $atts['placement'] ) );
	}
	return nexora_adsense_unit_html( $atts['slot'], $atts['format'] );
}
add_shortcode( 'nexora_ad', 'nexora_ad_shortcode' );

/**
 * Insert after paragraph N without breaking nested blocks (DOMDocument).
 *
 * @param string $content Content.
 * @param int    $after   Paragraph index (1-based).
 * @param string $html    Ad HTML.
 * @return string
 */
function nexora_insert_after_paragraph( $content, $after, $html ) {
	if ( '' === $html || '' === trim( $content ) ) {
		return $content;
	}
	if ( false !== strpos( $content, 'data-placement="after_p' ) || false !== strpos( $content, 'data-ad="adsense"' ) ) {
		// Still allow second placement if not already that key — check later per call.
	}

	if ( ! class_exists( 'DOMDocument' ) ) {
		$parts = preg_split( '/(<\/p>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( ! is_array( $parts ) ) {
			return $content . $html;
		}
		$out = '';
		$p   = 0;
		$n   = count( $parts );
		for ( $i = 0; $i < $n; $i++ ) {
			$out .= $parts[ $i ];
			if ( 0 === strcasecmp( trim( $parts[ $i ] ), '</p>' ) ) {
				$p++;
				if ( $p === (int) $after ) {
					$out .= $html;
				}
			}
		}
		return $out;
	}

	$wrapped = '<div id="nexora-ad-root">' . $content . '</div>';
	$dom     = new DOMDocument();
	$prev    = libxml_use_internal_errors( true );
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	libxml_use_internal_errors( $prev );

	$root = $dom->getElementById( 'nexora-ad-root' );
	if ( ! $root ) {
		return $content . $html;
	}

	$xpath = new DOMXPath( $dom );
	$paras = $xpath->query( './/p[not(ancestor::blockquote) and not(ancestor::table) and not(ancestor::pre) and not(ancestor::figure)]', $root );
	if ( ! $paras || 0 === $paras->length ) {
		return $content . $html;
	}

	$index = max( 1, (int) $after ) - 1;
	if ( $index >= $paras->length ) {
		$index = $paras->length - 1;
	}
	$target = $paras->item( $index );
	if ( ! $target || ! $target->parentNode ) {
		return $content . $html;
	}

	$frag = $dom->createDocumentFragment();
	$tmp  = new DOMDocument();
	$tmp->loadHTML( '<?xml encoding="utf-8" ?><div id="x">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	$x = $tmp->getElementById( 'x' );
	if ( $x ) {
		foreach ( iterator_to_array( $x->childNodes ) as $child ) {
			$frag->appendChild( $dom->importNode( $child, true ) );
		}
	}
	if ( $target->nextSibling ) {
		$target->parentNode->insertBefore( $frag, $target->nextSibling );
	} else {
		$target->parentNode->appendChild( $frag );
	}

	$out = '';
	foreach ( $root->childNodes as $child ) {
		$out .= $dom->saveHTML( $child );
	}
	return $out ? $out : $content . $html;
}

/**
 * In-content placement filter.
 *
 * @param string $content Post content.
 * @return string
 */
function nexora_adsense_in_content( $content ) {
	if ( is_admin() || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	if ( ! nexora_adsense_enabled() ) {
		return $content;
	}
	if ( nexora_post_meta_with_legacy( get_the_ID(), '_nexora_disable_ads', '_paulworld_disable_ads' ) ) {
		return $content;
	}

	$word_count = str_word_count( wp_strip_all_tags( $content ) );
	if ( $word_count < 120 ) {
		return $content;
	}

	$p2 = nexora_render_ad_placement( 'after_p2' );
	if ( $p2 && false === strpos( $content, 'data-placement="after_p2"' ) ) {
		$content = nexora_insert_after_paragraph( $content, 2, $p2 );
	}
	$p4 = nexora_render_ad_placement( 'after_p4' );
	if ( $p4 && false === strpos( $content, 'data-placement="after_p4"' ) ) {
		$content = nexora_insert_after_paragraph( $content, 4, $p4 );
	}
	$end = nexora_render_ad_placement( 'end_content' );
	if ( $end && false === strpos( $content, 'data-placement="end_content"' ) ) {
		$content .= $end;
	}
	return $content;
}
add_filter( 'the_content', 'nexora_adsense_in_content', 12 );

/**
 * Post meta: disable ads on this post.
 */
function nexora_ads_meta_box() {
	add_meta_box( 'nexora_ads', __( 'Advertising', 'nexora' ), 'nexora_ads_meta_box_render', 'post', 'side', 'default' );
}
add_action( 'add_meta_boxes', 'nexora_ads_meta_box' );

/**
 * Meta box HTML.
 *
 * @param WP_Post $post Post.
 */
function nexora_ads_meta_box_render( $post ) {
	wp_nonce_field( 'nexora_ads_meta', 'nexora_ads_meta_nonce' );
	$off = (bool) nexora_post_meta_with_legacy( $post->ID, '_nexora_disable_ads', '_paulworld_disable_ads' );
	echo '<label><input type="checkbox" name="nexora_disable_ads" value="1" ' . checked( $off, true, false ) . '> ';
	esc_html_e( 'Disable ads on this post', 'nexora' );
	echo '</label>';
}

/**
 * Save meta.
 *
 * @param int $post_id Post ID.
 */
function nexora_ads_meta_save( $post_id ) {
	if ( ! isset( $_POST['nexora_ads_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nexora_ads_meta_nonce'] ) ), 'nexora_ads_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( ! empty( $_POST['nexora_disable_ads'] ) ) {
		update_post_meta( $post_id, '_nexora_disable_ads', 1 );
	} else {
		delete_post_meta( $post_id, '_nexora_disable_ads' );
	}
}
add_action( 'save_post_post', 'nexora_ads_meta_save' );
