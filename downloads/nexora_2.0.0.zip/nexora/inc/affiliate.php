<?php
/**
 * Amazon Associates + affiliate product shortcodes.
 *
 * Manual product data only — no Amazon scraping.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Amazon tracking ID (tag=).
 *
 * @return string
 */
function nexora_amazon_tag() {
	$tag = trim( (string) nexora_get_option( 'amazon_tracking_id' ) );
	if ( ! $tag && function_exists( 'pwa_get_affiliate_tracking_id' ) ) {
		$tag = trim( (string) pwa_get_affiliate_tracking_id() );
	}
	return preg_match( '/^[A-Za-z0-9_-]+$/', $tag ) ? $tag : '';
}

/**
 * Append Amazon tag when missing.
 *
 * @param string $url Destination.
 * @return string
 */
function nexora_affiliate_link( $url ) {
	$url = esc_url_raw( $url );
	if ( ! $url ) {
		return '';
	}
	$tag = nexora_amazon_tag();
	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( $tag && $host && false !== stripos( $host, 'amazon.' ) ) {
		$parts = wp_parse_url( $url );
		$query = array();
		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $query );
		}
		if ( empty( $query['tag'] ) ) {
			$query['tag'] = $tag;
		}
		$url = ( isset( $parts['scheme'] ) ? $parts['scheme'] . '://' : 'https://' )
			. ( $parts['host'] ?? '' )
			. ( isset( $parts['path'] ) ? $parts['path'] : '' )
			. '?' . http_build_query( $query );
	}
	return esc_url( $url );
}

/**
 * Disclosure line for affiliate blocks.
 *
 * @return string
 */
function nexora_affiliate_block_disclosure() {
	$custom = trim( (string) nexora_get_option( 'affiliate_disclosure' ) );
	if ( $custom ) {
		return $custom;
	}
	return nexora_default_disclosure();
}

/**
 * [nexora_product name="" url="" image="" pros="" cons="" cta="Check price" features="a|b|c"]
 *
 * @param array       $atts    Attributes.
 * @param string|null $content Inner.
 * @return string
 */
function nexora_product_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'name'     => '',
			'url'      => '',
			'image'    => '',
			'pros'     => '',
			'cons'     => '',
			'features' => '',
			'cta'      => __( 'Check price', 'nexora' ),
			'badge'    => '',
		),
		$atts,
		'nexora_product'
	);

	$name = sanitize_text_field( $atts['name'] );
	$url  = nexora_affiliate_link( $atts['url'] );
	if ( ! $name || ! $url ) {
		return '';
	}

	$pros = array_filter( array_map( 'sanitize_text_field', explode( '|', $atts['pros'] ) ) );
	$cons = array_filter( array_map( 'sanitize_text_field', explode( '|', $atts['cons'] ) ) );
	$feat = array_filter( array_map( 'sanitize_text_field', explode( '|', $atts['features'] ) ) );
	$img  = esc_url( $atts['image'] );
	$desc = $content ? wp_kses_post( $content ) : '';

	ob_start();
	?>
	<aside class="nexora-product" data-affiliate="1">
		<?php if ( $atts['badge'] ) : ?>
			<p class="nexora-product__badge"><?php echo esc_html( $atts['badge'] ); ?></p>
		<?php endif; ?>
		<div class="nexora-product__grid">
			<?php if ( $img ) : ?>
				<div class="nexora-product__media">
					<img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $name ); ?>" width="320" height="320" loading="lazy" decoding="async">
				</div>
			<?php endif; ?>
			<div class="nexora-product__body">
				<h3 class="nexora-product__title"><?php echo esc_html( $name ); ?></h3>
				<?php if ( $desc ) : ?>
					<div class="nexora-product__desc"><?php echo $desc; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<?php endif; ?>
				<?php if ( $feat ) : ?>
					<ul class="nexora-product__features">
						<?php foreach ( $feat as $f ) : ?>
							<li><?php echo esc_html( $f ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php if ( $pros || $cons ) : ?>
					<div class="nexora-product__pc">
						<?php if ( $pros ) : ?>
							<div>
								<p class="nexora-product__pc-label"><?php esc_html_e( 'Pros', 'nexora' ); ?></p>
								<ul><?php foreach ( $pros as $p ) : ?><li><?php echo esc_html( $p ); ?></li><?php endforeach; ?></ul>
							</div>
						<?php endif; ?>
						<?php if ( $cons ) : ?>
							<div>
								<p class="nexora-product__pc-label"><?php esc_html_e( 'Cons', 'nexora' ); ?></p>
								<ul><?php foreach ( $cons as $c ) : ?><li><?php echo esc_html( $c ); ?></li><?php endforeach; ?></ul>
							</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<p class="nexora-product__actions">
					<a class="nexora-btn nexora-btn--primary nexora-aff-link" data-nexora-aff="1" data-nexora-aff-label="<?php echo esc_attr( $name ); ?>" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="sponsored noopener noreferrer"><?php echo esc_html( $atts['cta'] ); ?></a>
				</p>
				<p class="nexora-product__disc"><?php echo esc_html( nexora_affiliate_block_disclosure() ); ?></p>
			</div>
		</div>
	</aside>
	<?php
	return (string) ob_get_clean();
}
add_shortcode( 'nexora_product', 'nexora_product_shortcode' );

/**
 * [nexora_compare] row|row [/nexora_compare] — rows: Name|Feature|URL
 *
 * @param array       $atts    Attrs.
 * @param string|null $content Rows.
 * @return string
 */
function nexora_compare_shortcode( $atts, $content = null ) {
	$content = trim( (string) $content );
	if ( '' === $content ) {
		return '';
	}
	$lines = preg_split( '/\r\n|\r|\n/', $content );
	$rows  = array();
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = array_map( 'trim', explode( '|', $line ) );
		if ( count( $parts ) < 2 ) {
			continue;
		}
		$rows[] = array(
			'name' => sanitize_text_field( $parts[0] ),
			'note' => sanitize_text_field( $parts[1] ),
			'url'  => isset( $parts[2] ) ? nexora_affiliate_link( $parts[2] ) : '',
		);
	}
	if ( ! $rows ) {
		return '';
	}
	ob_start();
	?>
	<div class="nexora-compare" role="region" aria-label="<?php esc_attr_e( 'Product comparison', 'nexora' ); ?>">
		<table class="nexora-compare__table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Product', 'nexora' ); ?></th>
					<th><?php esc_html_e( 'Why it matters', 'nexora' ); ?></th>
					<th><?php esc_html_e( 'Link', 'nexora' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<tr>
						<td><?php echo esc_html( $row['name'] ); ?></td>
						<td><?php echo esc_html( $row['note'] ); ?></td>
						<td>
							<?php if ( $row['url'] ) : ?>
								<a class="nexora-btn nexora-btn--ghost nexora-aff-link" data-nexora-aff="1" data-nexora-aff-label="<?php echo esc_attr( $row['name'] ); ?>" href="<?php echo esc_url( $row['url'] ); ?>" target="_blank" rel="sponsored noopener noreferrer"><?php esc_html_e( 'View', 'nexora' ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="nexora-product__disc"><?php echo esc_html( nexora_affiliate_block_disclosure() ); ?></p>
	</div>
	<?php
	return (string) ob_get_clean();
}
add_shortcode( 'nexora_compare', 'nexora_compare_shortcode' );
