<?php
/**
 * Short affiliate URLs and the in-article CTA button.
 *
 * Appearance → Nexora → 301: site.com/slug 301-redirects to a partner URL.
 * In a post: [nexora_cta slug="ghl"]Try it[/nexora_cta]
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Saved redirects. Key is the public slug.
 *
 * @return array<string,array{url:string,label:string}>
 */
function nexora_cta_links() {
	$links = nexora_option_with_legacy( 'nexora_cta_links', 'paulworld_cta_links', array() );
	return is_array( $links ) ? $links : array();
}

/**
 * Slugs that must stay as real pages.
 *
 * @return string[]
 */
function nexora_cta_reserved_slugs() {
	return array(
		'about',
		'about-us',
		'contact',
		'blog',
		'home',
		'privacy-policy',
		'terms',
		'affiliate-disclosure',
		'gohighlevel-review',
		'wp-admin',
		'wp-login',
		'wp-json',
		'feed',
		'comments',
		'category',
		'tag',
		'author',
		'page',
		'search',
		'embed',
		'xmlrpc',
	);
}

/**
 * Public URL for a slug.
 *
 * @param string $slug Slug.
 * @return string
 */
function nexora_cta_public_url( $slug ) {
	return home_url( '/' . sanitize_title( $slug ) . '/' );
}

/**
 * Register /slug/ → ?nexora_go=slug
 */
function nexora_cta_rewrites() {
	$links = nexora_cta_links();
	foreach ( $links as $slug => $row ) {
		$slug = sanitize_title( $slug );
		if ( '' === $slug || empty( $row['url'] ) ) {
			continue;
		}
		add_rewrite_rule( '^' . $slug . '/?$', 'index.php?nexora_go=' . $slug, 'top' );
	}
}
add_action( 'init', 'nexora_cta_rewrites' );

/**
 * @param string[] $vars Query vars.
 * @return string[]
 */
function nexora_cta_query_vars( $vars ) {
	$vars[] = 'nexora_go';
	return $vars;
}
add_filter( 'query_vars', 'nexora_cta_query_vars' );

/**
 * 301 the short URL to the partner.
 */
function nexora_cta_redirect() {
	$slug = get_query_var( 'nexora_go' );
	if ( ! is_string( $slug ) || '' === $slug ) {
		return;
	}
	$slug  = sanitize_title( $slug );
	$links = nexora_cta_links();
	if ( empty( $links[ $slug ]['url'] ) ) {
		return;
	}
	wp_redirect( $links[ $slug ]['url'], 301 ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
	exit;
}
add_action( 'template_redirect', 'nexora_cta_redirect', 0 );

/**
 * In-article button.
 *
 * [nexora_cta slug="ghl"]Try GoHighLevel[/nexora_cta]
 * [nexora_cta url="https://example.com"]See pricing[/nexora_cta]
 *
 * @param array  $atts    Attributes.
 * @param string $content Label.
 * @return string
 */
function nexora_cta_shortcode( $atts, $content = '' ) {
	$atts = shortcode_atts(
		array(
			'slug' => '',
			'url'  => '',
		),
		$atts,
		'nexora_cta'
	);

	$href = '';
	$slug = sanitize_title( $atts['slug'] );
	if ( $slug ) {
		$links = nexora_cta_links();
		if ( empty( $links[ $slug ]['url'] ) ) {
			return '';
		}
		$href = nexora_cta_public_url( $slug );
	} elseif ( $atts['url'] ) {
		$href = esc_url( $atts['url'] );
	}
	if ( ! $href ) {
		return '';
	}

	$label = trim( wp_strip_all_tags( (string) $content ) );
	if ( '' === $label ) {
		$label = __( 'Continue', 'nexora' );
	}

	$html  = '<div class="nexora-cta">';
	$html .= '<a class="nexora-btn nexora-btn--primary nexora-cta__btn nexora-aff-link" data-nexora-aff="1" data-nexora-aff-label="' . esc_attr( wp_strip_all_tags( $label ) ) . '" href="' . esc_url( $href ) . '" target="_blank" rel="sponsored noopener noreferrer">';
	$html .= esc_html( $label );
	$html .= '<span class="nexora-cta__arrow" aria-hidden="true"></span>';
	$html .= '</a>';
	$html .= '</div>';

	return $html;
}
add_shortcode( 'nexora_cta', 'nexora_cta_shortcode' );

/**
 * Remove per-CTA affiliate notes baked into older post HTML.
 *
 * @param string $content Post content.
 * @return string
 */
function nexora_strip_cta_notes( $content ) {
	if ( ! is_string( $content ) ) {
		return $content;
	}
	if ( false === stripos( $content, 'nexora-cta__note' ) && false === stripos( $content, 'pw-cta__note' ) ) {
		return $content;
	}
	$stripped = preg_replace( '/<span\b[^>]*\bclass=("|\')[^"\']*\b(?:nexora|pw)-cta__note\b[^"\']*\1[^>]*>.*?<\/span>/is', '', $content );
	return is_string( $stripped ) ? $stripped : $content;
}
add_filter( 'the_content', 'nexora_strip_cta_notes', 9 );

/**
 * Admin URL for the 301 tab.
 *
 * @param array<string,string> $extra Query args.
 * @return string
 */
function nexora_redirects_admin_url( $extra = array() ) {
	$args = array_merge(
		array(
			'page' => function_exists( 'nexora_settings_page_slug' ) ? nexora_settings_page_slug() : 'nexora',
			'tab'  => 'redirects',
		),
		$extra
	);
	return add_query_arg( $args, admin_url( 'themes.php' ) );
}

/**
 * Old Tools → CTA links bookmarks → Nexora 301.
 */
function nexora_cta_tools_legacy_redirect() {
	if ( ! is_admin() ) {
		return;
	}
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'nexora-cta-links' !== $page && 'paulworld-cta-links' !== $page ) {
		return;
	}
	$extra = array();
	foreach ( array( 'saved', 'deleted', 'cta_error' ) as $key ) {
		if ( ! empty( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$extra[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
		}
	}
	wp_safe_redirect( nexora_redirects_admin_url( $extra ) );
	exit;
}
add_action( 'admin_init', 'nexora_cta_tools_legacy_redirect', 2 );

/**
 * Save or delete a redirect (Appearance → Nexora → 301).
 */
function nexora_cta_handle_post() {
	if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	if ( empty( $_POST['nexora_cta_action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return;
	}
	check_admin_referer( 'nexora_cta_links' );

	$action = sanitize_key( wp_unslash( $_POST['nexora_cta_action'] ) );
	$links  = nexora_cta_links();

	if ( 'delete' === $action ) {
		$slug = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';
		unset( $links[ $slug ] );
		update_option( 'nexora_cta_links', $links );
		flush_rewrite_rules( false );
		wp_safe_redirect( nexora_redirects_admin_url( array( 'deleted' => '1' ) ) );
		exit;
	}

	if ( 'save' !== $action ) {
		return;
	}

	$slug  = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';
	$url   = isset( $_POST['destination'] ) ? esc_url_raw( wp_unslash( $_POST['destination'] ) ) : '';
	$label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
	$note  = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '';

	$error = '';
	if ( ! preg_match( '/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug ) || strlen( $slug ) < 2 || strlen( $slug ) > 40 ) {
		$error = 'slug';
	} elseif ( in_array( $slug, nexora_cta_reserved_slugs(), true ) || get_page_by_path( $slug, OBJECT, array( 'page', 'post' ) ) ) {
		$error = 'reserved';
	} elseif ( ! $url || ! wp_http_validate_url( $url ) || ! preg_match( '#^https?://#i', $url ) ) {
		$error = 'url';
	} else {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		$path = is_string( $path ) ? untrailingslashit( $path ) : '';
		if ( '/' . $slug === $path ) {
			$error = 'url';
		}
	}

	if ( $error ) {
		wp_safe_redirect( nexora_redirects_admin_url( array( 'cta_error' => $error ) ) );
		exit;
	}

	if ( '' === $note && ! empty( $links[ $slug ]['note'] ) ) {
		$note = $links[ $slug ]['note'];
	}

	$links[ $slug ] = array(
		'url'   => $url,
		'label' => $label,
		'note'  => $note,
	);
	update_option( 'nexora_cta_links', $links );
	flush_rewrite_rules( false );
	wp_safe_redirect( nexora_redirects_admin_url( array( 'saved' => '1' ) ) );
	exit;
}
add_action( 'load-appearance_page_nexora', 'nexora_cta_handle_post' );

/**
 * Admin screen (embedded under Appearance → Nexora → 301).
 *
 * @param bool $embedded When true, omit outer wrap/h1 (Nexora hub supplies them).
 */
function nexora_cta_admin_page( $embedded = false ) {
	if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$links = nexora_cta_links();
	$error = isset( $_GET['cta_error'] ) ? sanitize_key( wp_unslash( $_GET['cta_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$form_action = nexora_redirects_admin_url();
	if ( ! $embedded ) {
		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( '301', 'nexora' ) . '</h1>';
	}
	?>
		<p><?php esc_html_e( 'Create a short address on this site that 301-redirects to any destination URL. Use the short URL in buttons or the [nexora_cta] shortcode.', 'nexora' ); ?></p>
		<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Redirect saved. Visit the short URL once to confirm.', 'nexora' ); ?></p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Redirect removed.', 'nexora' ); ?></p></div>
		<?php endif; ?>
		<?php if ( 'slug' === $error ) : ?>
			<div class="notice notice-error"><p><?php esc_html_e( 'Use a short slug: letters, numbers, and hyphens only. Example: offer', 'nexora' ); ?></p></div>
		<?php elseif ( 'reserved' === $error ) : ?>
			<div class="notice notice-error"><p><?php esc_html_e( 'That slug is already a page or a reserved address. Pick another.', 'nexora' ); ?></p></div>
		<?php elseif ( 'url' === $error ) : ?>
			<div class="notice notice-error"><p><?php esc_html_e( 'Destination must be a full http or https URL.', 'nexora' ); ?></p></div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Add or update a redirect', 'nexora' ); ?></h2>
		<form method="post" action="<?php echo esc_url( $form_action ); ?>">
			<?php wp_nonce_field( 'nexora_cta_links' ); ?>
			<input type="hidden" name="nexora_cta_action" value="save">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="nexora-cta-slug"><?php esc_html_e( 'Slug', 'nexora' ); ?></label></th>
					<td>
						<code><?php echo esc_html( home_url( '/' ) ); ?></code>
						<input name="slug" id="nexora-cta-slug" type="text" class="regular-text" placeholder="offer" required pattern="[a-z0-9]+(-[a-z0-9]+)*">
						<p class="description"><?php esc_html_e( 'Example: offer becomes yoursite.com/offer/', 'nexora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nexora-cta-url"><?php esc_html_e( 'Destination URL', 'nexora' ); ?></label></th>
					<td><input name="destination" id="nexora-cta-url" type="url" class="large-text" placeholder="https://example.com/your-link" required></td>
				</tr>
				<tr>
					<th scope="row"><label for="nexora-cta-label"><?php esc_html_e( 'Name', 'nexora' ); ?></label></th>
					<td>
						<input name="label" id="nexora-cta-label" type="text" class="regular-text" placeholder="<?php esc_attr_e( 'Partner offer', 'nexora' ); ?>">
						<p class="description"><?php esc_html_e( 'Short name for this list and the default button label. Visitors do not see this field.', 'nexora' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nexora-cta-note"><?php esc_html_e( 'Private note', 'nexora' ); ?></label></th>
					<td>
						<textarea name="note" id="nexora-cta-note" class="large-text" rows="3" placeholder="<?php esc_attr_e( 'Network + offer notes for your team only.', 'nexora' ); ?>"></textarea>
						<p class="description"><?php esc_html_e( 'Private. Visitors never see it. Leave blank when updating a slug to keep the existing note.', 'nexora' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save redirect', 'nexora' ) ); ?>
		</form>

		<h2><?php esc_html_e( 'Your redirects', 'nexora' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Short URL', 'nexora' ); ?></th>
					<th><?php esc_html_e( 'Redirects to', 'nexora' ); ?></th>
					<th><?php esc_html_e( 'Note', 'nexora' ); ?></th>
					<th><?php esc_html_e( 'Button shortcode', 'nexora' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! $links ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'No redirects yet.', 'nexora' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $links as $slug => $row ) : ?>
						<tr>
							<td>
								<a href="<?php echo esc_url( nexora_cta_public_url( $slug ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( nexora_cta_public_url( $slug ) ); ?></a>
								<?php if ( ! empty( $row['label'] ) ) : ?>
									<br><span class="description"><?php echo esc_html( $row['label'] ); ?></span>
								<?php endif; ?>
							</td>
							<td><code><?php echo esc_html( $row['url'] ); ?></code></td>
							<td><?php echo ! empty( $row['note'] ) ? esc_html( $row['note'] ) : '—'; ?></td>
							<td><code>[nexora_cta slug="<?php echo esc_attr( $slug ); ?>"]<?php echo esc_html( $row['label'] ? $row['label'] : __( 'Try it', 'nexora' ) ); ?>[/nexora_cta]</code></td>
							<td>
								<form method="post" action="<?php echo esc_url( $form_action ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Remove this redirect?', 'nexora' ) ); ?>');">
									<?php wp_nonce_field( 'nexora_cta_links' ); ?>
									<input type="hidden" name="nexora_cta_action" value="delete">
									<input type="hidden" name="slug" value="<?php echo esc_attr( $slug ); ?>">
									<button type="submit" class="button-link-delete"><?php esc_html_e( 'Delete', 'nexora' ); ?></button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'In the post editor, add a Shortcode block and paste the shortcode. Saving the same slug again updates the destination. Browsers may cache a 301 — test in a private window after changes.', 'nexora' ); ?></p>
	<?php
	if ( ! $embedded ) {
		echo '</div>';
	}
}

/**
 * Remind the editor how to insert the button.
 */
function nexora_cta_meta_box() {
	add_meta_box(
		'nexora-cta',
		__( 'Article CTA button', 'nexora' ),
		'nexora_cta_meta_box_render',
		'post',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'nexora_cta_meta_box' );

/**
 * Meta box body.
 */
function nexora_cta_meta_box_render() {
	$links = nexora_cta_links();
	echo '<p>' . esc_html__( 'Add a Shortcode block in the article and paste one of these:', 'nexora' ) . '</p>';
	if ( ! $links ) {
		echo '<p><a href="' . esc_url( nexora_redirects_admin_url() ) . '">' . esc_html__( 'Create a redirect first', 'nexora' ) . '</a></p>';
		return;
	}
	echo '<ul style="margin-left:1em;list-style:disc">';
	foreach ( $links as $slug => $row ) {
		$label = ! empty( $row['label'] ) ? $row['label'] : __( 'Try it', 'nexora' );
		echo '<li style="margin:0 0 10px"><code style="white-space:normal">[nexora_cta slug="' . esc_attr( $slug ) . '"]' . esc_html( $label ) . '[/nexora_cta]</code>';
		if ( ! empty( $row['note'] ) ) {
			echo '<br><span class="description">' . esc_html( $row['note'] ) . '</span>';
		}
		echo '</li>';
	}
	echo '</ul>';
}
