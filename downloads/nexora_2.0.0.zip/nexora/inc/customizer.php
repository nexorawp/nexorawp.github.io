<?php
/**
 * Customizer: affiliate URL, contact email, footer disclosure.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Nexora Customizer section.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 */
function nexora_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'nexora_funnel', array(
		'title'       => __( 'Theme Funnel', 'nexora' ),
		'description' => __( 'Affiliate CTA, contact inbox, and disclosure. Prefer Appearance → Nexora for the full dashboard.', 'nexora' ),
		'priority'    => 30,
	) );

	$wp_customize->add_setting( 'ghl_affiliate_url', array(
		'default'           => nexora_default_affiliate_url(),
		'sanitize_callback' => 'esc_url_raw',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'ghl_affiliate_url', array(
		'label'       => __( 'Primary CTA / affiliate click URL', 'nexora' ),
		'description' => __( 'Explicit CTA buttons open this URL in a new tab. Homepage body clicks stay on the site.', 'nexora' ),
		'section'     => 'nexora_funnel',
		'type'        => 'url',
	) );

	$wp_customize->add_setting( 'contact_email', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_email',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'contact_email', array(
		'label'       => __( 'Contact email (webmail inbox)', 'nexora' ),
		'description' => __( 'Form submissions are sent here via wp_mail. Reply from your webmail using the visitor Reply-To address.', 'nexora' ),
		'section'     => 'nexora_funnel',
		'type'        => 'email',
	) );

	$wp_customize->add_setting( 'footer_disclosure', array(
		'default'           => nexora_default_disclosure(),
		'sanitize_callback' => 'sanitize_textarea_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'footer_disclosure', array(
		'label'       => __( 'Affiliate disclosure', 'nexora' ),
		'description' => __( 'Commission disclaimer for the footer Disclaimer column and legal Disclosure page — not in the homepage body.', 'nexora' ),
		'section'     => 'nexora_funnel',
		'type'        => 'textarea',
	) );

	$wp_customize->add_setting( 'adsense_client', array(
		'default'           => '',
		'sanitize_callback' => 'nexora_sanitize_adsense_client',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'adsense_client', array(
		'label'       => __( 'AdSense publisher ID', 'nexora' ),
		'description' => __( 'Example: ca-pub-1234567890123456. Leave blank to disable ads.', 'nexora' ),
		'section'     => 'nexora_funnel',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'adsense_auto_ads', array(
		'default'           => true,
		'sanitize_callback' => 'nexora_sanitize_checkbox',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'adsense_auto_ads', array(
		'label'   => __( 'Enable AdSense Auto ads', 'nexora' ),
		'section' => 'nexora_funnel',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'adsense_in_article', array(
		'default'           => true,
		'sanitize_callback' => 'nexora_sanitize_checkbox',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'adsense_in_article', array(
		'label'   => __( 'Show an in-article ad on reviews', 'nexora' ),
		'section' => 'nexora_funnel',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'adsense_slot_in_article', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'adsense_slot_in_article', array(
		'label'       => __( 'In-article ad slot ID', 'nexora' ),
		'description' => __( 'Optional. Numeric AdSense ad unit slot. Leave blank for a responsive unit.', 'nexora' ),
		'section'     => 'nexora_funnel',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'adsense_in_article_after', array(
		'default'           => 2,
		'sanitize_callback' => 'absint',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'adsense_in_article_after', array(
		'label'       => __( 'Insert in-article ad after paragraph', 'nexora' ),
		'description' => __( 'Usually 2. Keeps the first screen clear for readers and AdSense policy.', 'nexora' ),
		'section'     => 'nexora_funnel',
		'type'        => 'number',
		'input_attrs' => array(
			'min' => 1,
			'max' => 8,
		),
	) );
}
add_action( 'customize_register', 'nexora_customize_register' );

/**
 * Sanitize AdSense client ID.
 *
 * @param string $value Raw.
 * @return string
 */
function nexora_sanitize_adsense_client( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}
	return preg_match( '/^ca-pub-\d+$/', $value ) ? $value : '';
}

/**
 * Sanitize checkbox theme mods.
 *
 * @param mixed $value Raw.
 * @return bool
 */
function nexora_sanitize_checkbox( $value ) {
	return (bool) $value;
}
