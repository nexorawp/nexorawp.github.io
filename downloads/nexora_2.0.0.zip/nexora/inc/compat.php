<?php
/**
 * Backward compatibility + one-time migrations onto the Nexora stylesheet.
 *
 * Site brand stays in Site Identity / content. Theme product name is Nexora only.
 * This file only bridges old package keys → Nexora.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* —— wp-config constants (live sites may still define PAULWORLD_*) —— */
if ( ! defined( 'NEXORA_GITHUB_TOKEN' ) && defined( 'PAULWORLD_GITHUB_TOKEN' ) ) {
	define( 'NEXORA_GITHUB_TOKEN', PAULWORLD_GITHUB_TOKEN );
}
if ( ! defined( 'NEXORA_GITHUB_REPO' ) && defined( 'PAULWORLD_GITHUB_REPO' ) ) {
	define( 'NEXORA_GITHUB_REPO', PAULWORLD_GITHUB_REPO );
}

/**
 * One-time: copy theme_mods_paulworld → theme_mods_{stylesheet} when switching package folder to nexora.
 */
function nexora_maybe_migrate_theme_mods() {
	if ( get_option( 'nexora_theme_mods_migrated_v1' ) ) {
		return;
	}
	$stylesheet = get_stylesheet();
	if ( ! $stylesheet ) {
		return;
	}
	$dest_key = 'theme_mods_' . $stylesheet;
	$dest     = get_option( $dest_key );
	$src      = get_option( 'theme_mods_paulworld' );

	$dest_empty = ! is_array( $dest ) || count( array_diff_key( $dest, array( 'nav_menu_locations' => 1, 'custom_css_post_id' => 1 ) ) ) < 1;
	if ( $dest_empty && is_array( $src ) && $src ) {
		update_option( $dest_key, $src );
	}

	// Drop obsolete tracker mods if present.
	remove_theme_mod( 'bemob_landing_src' );

	update_option( 'nexora_theme_mods_migrated_v1', '1', false );
}
add_action( 'after_setup_theme', 'nexora_maybe_migrate_theme_mods', 1 );
add_action( 'after_switch_theme', 'nexora_maybe_migrate_theme_mods', 1 );

/**
 * Read option with legacy paulworld_* fallback; migrate to nexora_* when found.
 *
 * @param string $new_key New option name.
 * @param string $old_key Legacy option name.
 * @param mixed  $default Default.
 * @return mixed
 */
function nexora_option_with_legacy( $new_key, $old_key, $default = false ) {
	$val = get_option( $new_key, null );
	if ( null !== $val && false !== $val ) {
		return $val;
	}
	$legacy = get_option( $old_key, null );
	if ( null !== $legacy && false !== $legacy ) {
		update_option( $new_key, $legacy, false );
		return $legacy;
	}
	return $default;
}

/**
 * Post meta with legacy _paulworld_* fallback.
 *
 * @param int    $post_id Post ID.
 * @param string $new_key New meta key.
 * @param string $old_key Legacy meta key.
 * @return mixed
 */
function nexora_post_meta_with_legacy( $post_id, $new_key, $old_key ) {
	$val = get_post_meta( $post_id, $new_key, true );
	if ( '' !== $val && false !== $val && null !== $val ) {
		return $val;
	}
	$legacy = get_post_meta( $post_id, $old_key, true );
	if ( '' !== $legacy && false !== $legacy && null !== $legacy ) {
		update_post_meta( $post_id, $new_key, $legacy );
		return $legacy;
	}
	return $val;
}

/* —— Shortcodes used in existing posts —— */
add_action(
	'init',
	static function () {
		if ( shortcode_exists( 'nexora_ad' ) && ! shortcode_exists( 'pw_ad' ) ) {
			add_shortcode( 'pw_ad', 'nexora_ad_shortcode' );
		}
		if ( shortcode_exists( 'nexora_product' ) && ! shortcode_exists( 'pw_product' ) ) {
			add_shortcode( 'pw_product', 'nexora_product_shortcode' );
		}
		if ( shortcode_exists( 'nexora_compare' ) && ! shortcode_exists( 'pw_compare' ) ) {
			add_shortcode( 'pw_compare', 'nexora_compare_shortcode' );
		}
		if ( shortcode_exists( 'nexora_cta' ) && ! shortcode_exists( 'pw_cta' ) ) {
			add_shortcode( 'pw_cta', 'nexora_cta_shortcode' );
		}
	},
	20
);

/* —— Legacy admin-post / query actions —— */
add_action( 'admin_post_nopriv_paulworld_contact', 'nexora_handle_contact' );
add_action( 'admin_post_paulworld_contact', 'nexora_handle_contact' );
add_action( 'admin_post_paulworld_save_settings', 'nexora_handle_settings_save' );
add_action( 'admin_post_paulworld_github_check', 'nexora_handle_github_check' );

/* —— Legacy image size names (regenerated thumbs keep old names) —— */
add_action(
	'after_setup_theme',
	static function () {
		add_image_size( 'paulworld-wide', 630, 400, false );
		add_image_size( 'paulworld-card', 380, 240, false );
		add_image_size( 'paulworld-mid', 343, 218, false );
		add_image_size( 'paulworld-thumb', 178, 113, false );
	},
	20
);

/* —— Legacy ?pw_cat= still registered —— */
add_filter(
	'query_vars',
	static function ( $vars ) {
		$vars[] = 'pw_cat';
		return $vars;
	}
);
