<?php
/**
 * Affiliate click tracking (local counts + GA4 events when consented).
 *
 * Does not invent Amazon commissions. Sales require Amazon Associates reports.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clicks table.
 *
 * @return string
 */
function nexora_aff_clicks_table() {
	global $wpdb;
	$new = $wpdb->prefix . 'nexora_aff_clicks';
	$old = $wpdb->prefix . 'paulworld_aff_clicks';
	// Prefer existing legacy table so click history is not orphaned.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$old_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $old ) );
	if ( $old_ok === $old ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$new_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $new ) );
		if ( $new_ok !== $new ) {
			return $old;
		}
	}
	return $new;
}

/**
 * Ensure table exists.
 */
function nexora_aff_clicks_install() {
	if ( '1' === (string) nexora_option_with_legacy( 'nexora_aff_clicks_db', 'paulworld_aff_clicks_db', '' ) ) {
		return;
	}
	global $wpdb;
	$table   = nexora_aff_clicks_table();
	$charset = $wpdb->get_charset_collate();
	$sql     = "CREATE TABLE {$table} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		url text NOT NULL,
		label varchar(191) NOT NULL DEFAULT '',
		post_id bigint(20) unsigned NOT NULL DEFAULT 0,
		device varchar(20) NOT NULL DEFAULT '',
		created_at datetime NOT NULL,
		PRIMARY KEY (id),
		KEY created_at (created_at),
		KEY post_id (post_id)
	) {$charset};";
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	update_option( 'nexora_aff_clicks_db', '1' );
}
add_action( 'init', 'nexora_aff_clicks_install', 5 );

/**
 * REST: record click (public, rate-limited lightly via nonce optional).
 */
function nexora_aff_register_rest() {
	register_rest_route(
		'nexora/v1',
		'/aff-click',
		array(
			'methods'             => 'POST',
			'callback'            => 'nexora_aff_record_click',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'nexora_aff_register_rest' );

/**
 * Record outbound affiliate click.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function nexora_aff_record_click( $request ) {
	if ( ! nexora_get_option( 'aff_track_clicks' ) ) {
		return new WP_Error( 'nexora_off', 'Tracking disabled', array( 'status' => 403 ) );
	}
	$url   = esc_url_raw( (string) $request->get_param( 'url' ) );
	$label = sanitize_text_field( (string) $request->get_param( 'label' ) );
	$post  = absint( $request->get_param( 'post_id' ) );
	if ( ! $url ) {
		return new WP_Error( 'nexora_url', 'URL required', array( 'status' => 400 ) );
	}
	// Only track http(s) outbound-looking links.
	if ( 0 !== strpos( $url, 'http' ) ) {
		return new WP_Error( 'nexora_url', 'Invalid URL', array( 'status' => 400 ) );
	}

	global $wpdb;
	$wpdb->insert(
		nexora_aff_clicks_table(),
		array(
			'url'        => $url,
			'label'      => substr( $label, 0, 191 ),
			'post_id'    => $post,
			'device'     => wp_is_mobile() ? 'mobile' : 'desktop',
			'created_at' => current_time( 'mysql', true ),
		),
		array( '%s', '%s', '%d', '%s', '%s' )
	);

	return rest_ensure_response( array( 'ok' => true ) );
}

/**
 * Stats for dashboard.
 *
 * @param int $days Days.
 * @return array
 */
function nexora_aff_click_stats( $days = 30 ) {
	global $wpdb;
	nexora_aff_clicks_install();
	$table  = nexora_aff_clicks_table();
	$since  = gmdate( 'Y-m-d H:i:s', time() - max( 1, $days ) * DAY_IN_SECONDS );
	$total  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", $since ) ); // phpcs:ignore
	$by_url = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT url, label, COUNT(*) AS clicks FROM {$table} WHERE created_at >= %s GROUP BY url, label ORDER BY clicks DESC LIMIT 20", // phpcs:ignore
			$since
		),
		ARRAY_A
	);
	$by_post = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT post_id, COUNT(*) AS clicks FROM {$table} WHERE created_at >= %s AND post_id > 0 GROUP BY post_id ORDER BY clicks DESC LIMIT 15", // phpcs:ignore
			$since
		),
		ARRAY_A
	);
	$by_device = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT device, COUNT(*) AS clicks FROM {$table} WHERE created_at >= %s GROUP BY device", // phpcs:ignore
			$since
		),
		ARRAY_A
	);
	return array(
		'total'     => $total,
		'by_url'    => is_array( $by_url ) ? $by_url : array(),
		'by_post'   => is_array( $by_post ) ? $by_post : array(),
		'by_device' => is_array( $by_device ) ? $by_device : array(),
		'days'      => (int) $days,
	);
}
