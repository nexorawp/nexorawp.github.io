<?php
/**
 * Fallback loop — magazine grid (same as Blog).
 *
 * @package Nexora
 */

get_header();
?>

<main id="main" class="nexora-main">
	<header class="nexora-page__hero">
		<div class="nexora-page__atmosphere" aria-hidden="true"></div>
		<div class="nexora-wrap">
			<h1><?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?></h1>
		</div>
	</header>
	<div class="nexora-wrap nexora-magazine">
		<?php if ( have_posts() ) : ?>
			<?php nexora_magazine_loop_with_ads(); ?>
			<nav class="nexora-pagination" aria-label="<?php esc_attr_e( 'Posts', 'nexora' ); ?>">
				<?php
				the_posts_pagination(
					array(
						'mid_size'  => 1,
						'prev_text' => __( 'Newer', 'nexora' ),
						'next_text' => __( 'Older', 'nexora' ),
					)
				);
				?>
			</nav>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>
</main>

<?php
get_footer();
