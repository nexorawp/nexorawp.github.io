<?php
/**
 * Category archive — magazine grid with title + category description.
 *
 * @package Nexora
 */

get_header();

$term = get_queried_object();
$desc = ( $term && ! is_wp_error( $term ) ) ? trim( wp_strip_all_tags( (string) $term->description ) ) : '';
?>

<main id="main" class="nexora-main nexora-main--magazine">
	<div class="nexora-mag-atmosphere" aria-hidden="true"></div>

	<header class="nexora-mag-hero nexora-mag-hero--compact">
		<div class="nexora-wrap">
			<h1><?php single_cat_title(); ?></h1>
			<?php if ( $desc ) : ?>
				<p class="nexora-mag-hero__lede"><?php echo esc_html( $desc ); ?></p>
			<?php endif; ?>
		</div>
	</header>

	<div class="nexora-wrap nexora-magazine">
		<?php nexora_blog_filters( array( 'search' => true ) ); ?>

		<?php if ( have_posts() ) : ?>
			<?php nexora_magazine_loop_with_ads(); ?>
			<?php
			global $wp_query;
			if ( $wp_query->max_num_pages > 1 ) :
				?>
			<nav class="nexora-pagination" aria-label="<?php esc_attr_e( 'Category pages', 'nexora' ); ?>">
				<?php
				the_posts_pagination(
					array(
						'mid_size'  => 2,
						'prev_text' => __( 'Newer', 'nexora' ),
						'next_text' => __( 'Older', 'nexora' ),
					)
				);
				?>
			</nav>
			<?php endif; ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>

</main>

<?php
get_footer();
