<?php
/**
 * Single post — centered hero, left TOC + subscribe, body, related.
 *
 * @package Nexora
 */

get_header();
?>

<main id="main" class="nexora-main">
	<?php
	while ( have_posts() ) :
		the_post();
		$cats        = get_the_category();
		$cats        = array_values(
			array_filter(
				$cats,
				static function ( $c ) {
					return $c && 'uncategorized' !== $c->slug;
				}
			)
		);
		$published     = get_the_date( DATE_W3C );
		$modified      = get_the_modified_date( DATE_W3C );
		$author_name   = trim( (string) get_the_author() );
		$show_author   = $author_name
			&& function_exists( 'nexora_get_option' )
			&& nexora_get_option( 'article_meta_author' );
		$show_date     = function_exists( 'nexora_get_option' ) && nexora_get_option( 'article_meta_date' );
		$show_read     = function_exists( 'nexora_get_option' ) && nexora_get_option( 'article_reading_time' ) && function_exists( 'nexora_reading_time' );
		$show_update   = $show_date && function_exists( 'nexora_get_option' ) && nexora_get_option( 'article_updated_date' ) && $modified && $modified !== $published;
		$show_meta     = $show_author || $show_date || $show_read;
		$tags          = get_the_tags();
		$meta_parts    = 0;
		?>
		<article <?php post_class( 'nexora-article' ); ?>>
			<?php if ( function_exists( 'nexora_floating_share' ) ) : ?>
				<?php nexora_floating_share(); ?>
			<?php endif; ?>
			<header class="nexora-article__hero">
				<div class="nexora-wrap nexora-article__intro-grid">
					<div class="nexora-article__side nexora-article__side--left">
						<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
							<?php nexora_ad_slot( 'hero_left' ); ?>
						<?php endif; ?>
					</div>
					<div class="nexora-article__intro">
						<?php if ( function_exists( 'nexora_breadcrumbs' ) ) : ?>
							<?php nexora_breadcrumbs(); ?>
						<?php endif; ?>
						<h1><?php the_title(); ?></h1>
						<?php if ( has_excerpt() ) : ?>
							<p class="nexora-article__deck"><?php echo esc_html( get_the_excerpt() ); ?></p>
						<?php endif; ?>
						<?php if ( $show_meta ) : ?>
						<p class="nexora-article__meta">
							<?php if ( $show_author ) : ?>
								<?php $meta_parts++; ?>
								<span class="nexora-article__by">
									<?php
									printf(
										/* translators: %s: author name */
										esc_html__( 'By %s', 'nexora' ),
										esc_html( $author_name )
									);
									?>
								</span>
							<?php endif; ?>
							<?php if ( $show_date ) : ?>
								<?php if ( $meta_parts > 0 ) : ?><span class="nexora-article__sep" aria-hidden="true">|</span><?php endif; ?>
								<?php $meta_parts++; ?>
								<?php if ( $show_update ) : ?>
									<span><?php esc_html_e( 'Last updated:', 'nexora' ); ?>
										<time datetime="<?php echo esc_attr( $modified ); ?>"><?php echo esc_html( get_the_modified_date() ); ?></time>
									</span>
								<?php else : ?>
									<span><?php esc_html_e( 'Published:', 'nexora' ); ?>
										<time datetime="<?php echo esc_attr( $published ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
									</span>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( $show_read ) : ?>
								<?php if ( $meta_parts > 0 ) : ?><span class="nexora-article__sep" aria-hidden="true">|</span><?php endif; ?>
								<span class="nexora-article__read">
									<?php
									$mins = (int) nexora_reading_time();
									echo esc_html(
										sprintf(
											/* translators: %d: minutes */
											_n( '%d minute read', '%d minutes read', $mins, 'nexora' ),
											$mins
										)
									);
									?>
								</span>
							<?php endif; ?>
						</p>
						<?php endif; ?>
						<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
							<?php nexora_ad_slot( 'below_title' ); ?>
						<?php endif; ?>
					</div>
					<div class="nexora-article__side nexora-article__side--right">
						<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
							<?php nexora_ad_slot( 'hero_right' ); ?>
						<?php endif; ?>
					</div>
				</div>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="nexora-wrap nexora-article__media nexora-pin">
					<?php
					the_post_thumbnail(
						'nexora-wide',
						nexora_post_thumbnail_attrs(
							null,
							array(
								'loading'       => 'eager',
								'decoding'      => 'async',
								'fetchpriority' => 'high',
								'sizes'         => '(max-width: 700px) calc(100vw - 40px), 624px',
								'class'         => 'nexora-article__img',
							)
						)
					);
					$pin_src = get_the_post_thumbnail_url( null, 'full' );
					if ( $pin_src && function_exists( 'nexora_pinterest_button_html' ) ) {
						echo nexora_pinterest_button_html( $pin_src ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper.
					}
					?>
				</div>
				<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
					<div class="nexora-wrap"><?php nexora_ad_slot( 'after_image' ); ?></div>
				<?php endif; ?>
			<?php endif; ?>

			<div class="nexora-wrap nexora-article__layout">
				<aside class="nexora-article__rail nexora-article__rail--left" aria-label="<?php esc_attr_e( 'Article tools', 'nexora' ); ?>">
					<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
						<?php nexora_ad_slot( 'rail_before_toc' ); ?>
					<?php endif; ?>
					<?php if ( function_exists( 'nexora_toc' ) ) : ?>
						<?php nexora_toc(); ?>
					<?php endif; ?>
					<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
						<?php nexora_ad_slot( 'rail_after_toc' ); ?>
					<?php endif; ?>
					<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
						<?php nexora_ad_slot( 'rail_after_newsletter' ); ?>
					<?php endif; ?>
				</aside>

				<div class="nexora-prose nexora-article__content">
					<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
						<?php nexora_ad_slot( 'before_content' ); ?>
					<?php endif; ?>
					<?php the_content(); ?>

					<?php if ( $tags || $cats ) : ?>
						<div class="nexora-article__tax">
							<?php if ( $cats ) : ?>
								<p class="nexora-article__tax-label"><?php esc_html_e( 'Categories', 'nexora' ); ?></p>
								<ul class="nexora-article__tags">
									<?php foreach ( $cats as $cat ) : ?>
										<li><a class="nexora-article__tag" href="<?php echo esc_url( nexora_blog_filter_url( $cat->slug ) ); ?>"><?php echo esc_html( $cat->name ); ?></a></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
							<?php if ( $tags ) : ?>
								<p class="nexora-article__tax-label"><?php esc_html_e( 'Tags', 'nexora' ); ?></p>
								<ul class="nexora-article__tags">
									<?php foreach ( $tags as $tag ) : ?>
										<li><a class="nexora-article__tag" href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>"><?php echo esc_html( $tag->name ); ?></a></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						</div>
					<?php endif; ?>

				</div>

				<aside class="nexora-article__rail nexora-article__rail--right" aria-label="<?php esc_attr_e( 'Sponsored', 'nexora' ); ?>">
					<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
						<?php nexora_ad_slot( 'rail_right_top' ); ?>
						<?php nexora_ad_slot( 'rail_right_bottom' ); ?>
					<?php endif; ?>
				</aside>
			</div>

			<?php
			$related = nexora_related_posts( get_the_ID(), 3 );
			if ( $related ) :
				?>
				<section class="nexora-wrap nexora-related" aria-labelledby="nexora-related-heading">
					<h2 id="nexora-related-heading" class="nexora-related__heading"><?php esc_html_e( 'Related topics', 'nexora' ); ?></h2>
					<div class="nexora-magazine__grid nexora-magazine__grid--related">
						<?php
						global $post;
						foreach ( $related as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
							setup_postdata( $post );
							?>
							<div class="nexora-magazine__cell">
								<?php get_template_part( 'template-parts/content', 'post' ); ?>
							</div>
							<?php
						}
						wp_reset_postdata();
						?>
					</div>
				</section>
			<?php endif; ?>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
