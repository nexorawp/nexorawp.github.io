<?php
/**
 * Not found.
 *
 * @package Nexora
 */

get_header();
?>

<main id="main" class="nexora-main">
	<div class="nexora-wrap nexora-empty">
		<h1><?php esc_html_e( 'Page not found', 'nexora' ); ?></h1>
		<p class="nexora-lede"><?php esc_html_e( 'That URL does not exist. Head home or send a note if a link broke.', 'nexora' ); ?></p>
		<p>
			<a class="nexora-btn nexora-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to home', 'nexora' ); ?></a>
			<a class="nexora-btn nexora-btn--secondary" href="<?php echo esc_url( nexora_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact', 'nexora' ); ?></a>
		</p>
	</div>
</main>

<?php
get_footer();
