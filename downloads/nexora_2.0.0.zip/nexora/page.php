<?php
/**
 * Default page (fallback for simple pages).
 *
 * @package Nexora
 */

get_header();
?>

<main id="main" class="nexora-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'nexora-page' ); ?>>
			<header class="nexora-page__hero">
				<div class="nexora-page__atmosphere" aria-hidden="true"></div>
				<div class="nexora-wrap nexora-page__intro">
					<h1><?php the_title(); ?></h1>
				</div>
			</header>
			<div class="nexora-wrap nexora-prose">
				<?php the_content(); ?>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
