<?php
/**
 * Template Name: About
 *
 * @package Nexora
 */

get_header();
$contact = nexora_page_url( 'contact' );
?>

<main id="main" class="nexora-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'nexora-page nexora-page--about' ); ?>>
			<header class="nexora-page__hero">
				<div class="nexora-page__atmosphere" aria-hidden="true"></div>
				<div class="nexora-wrap nexora-page__intro">
					<p class="nexora-eyebrow">
						<span class="nexora-eyebrow__ico" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.75"/><path d="M5 19c1.5-3.2 4-5 7-5s5.5 1.8 7 5" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/></svg>
						</span>
						<?php esc_html_e( 'About', 'nexora' ); ?>
					</p>
					<h1><?php the_title(); ?></h1>
					<p class="nexora-lede"><?php esc_html_e( 'Practical guides for everyday repairs — fitting, parts, plumbing, cars, and DIY.', 'nexora' ); ?></p>
				</div>
			</header>

			<div class="nexora-wrap nexora-about">
				<div class="nexora-about__body nexora-prose">
					<?php the_content(); ?>
				</div>

				<aside class="nexora-about__aside">
					<div class="nexora-about__card">
						<p class="nexora-about__card-title"><?php esc_html_e( 'How I write', 'nexora' ); ?></p>
						<ul class="nexora-about__points">
							<li><?php esc_html_e( 'Beginner-friendly steps before advanced jargon', 'nexora' ); ?></li>
							<li><?php esc_html_e( 'Safety and limits called out when it matters', 'nexora' ); ?></li>
							<li><?php esc_html_e( 'No fake credentials or invented shop stories', 'nexora' ); ?></li>
							<li><?php esc_html_e( 'Affiliate links disclosed when a guide includes them', 'nexora' ); ?></li>
						</ul>
						<a class="nexora-btn nexora-btn--secondary" href="<?php echo esc_url( $contact ); ?>"><?php esc_html_e( 'Contact', 'nexora' ); ?></a>
					</div>
				</aside>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
