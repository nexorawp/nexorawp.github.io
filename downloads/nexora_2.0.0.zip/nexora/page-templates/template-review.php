<?php
/**
 * Template Name: Review
 *
 * Long-form review + conversion sidebar.
 *
 * @package Nexora
 */

get_header();
$aff = nexora_affiliate_url();
?>

<main id="main" class="nexora-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'nexora-review' ); ?>>
			<header class="nexora-page__hero">
				<div class="nexora-wrap">
					<p class="nexora-kicker"><?php esc_html_e( 'Independent review', 'nexora' ); ?></p>
					<h1><?php the_title(); ?></h1>
				</div>
			</header>

			<div class="nexora-wrap nexora-review__layout">
				<div class="nexora-prose nexora-review__body">
					<?php the_content(); ?>
				</div>
				<aside class="nexora-review__side" aria-label="<?php esc_attr_e( 'Try for free', 'nexora' ); ?>">
					<div class="nexora-side-cta">
						<p class="nexora-side-cta__kicker"><?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?></p>
						<p class="nexora-side-cta__title"><?php esc_html_e( 'Test it on your actual pipeline.', 'nexora' ); ?></p>
						<a class="nexora-btn nexora-btn--primary" href="<?php echo $aff; ?>"<?php echo nexora_affiliate_link_attrs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php esc_html_e( 'Try for free', 'nexora' ); ?></a>
					</div>
				</aside>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
