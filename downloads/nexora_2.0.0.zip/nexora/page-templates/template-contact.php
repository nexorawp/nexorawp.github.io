<?php
/**
 * Template Name: Contact
 *
 * Working form + webmail via wp_mail. Status stays on this page.
 *
 * @package Nexora
 */

get_header();
$status = nexora_contact_status();
$email  = nexora_contact_email();
// Prefill from newsletter / deep links (?nexora_email=&nexora_subject=; legacy pw_* still accepted).
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$prefill_email = isset( $_GET['nexora_email'] ) ? sanitize_email( wp_unslash( $_GET['nexora_email'] ) ) : ( isset( $_GET['pw_email'] ) ? sanitize_email( wp_unslash( $_GET['pw_email'] ) ) : '' );
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$prefill_subject = isset( $_GET['nexora_subject'] ) ? sanitize_text_field( wp_unslash( $_GET['nexora_subject'] ) ) : ( isset( $_GET['pw_subject'] ) ? sanitize_text_field( wp_unslash( $_GET['pw_subject'] ) ) : '' );
if ( $prefill_email && ! is_email( $prefill_email ) ) {
	$prefill_email = '';
}
?>

<main id="main" class="nexora-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'nexora-page nexora-page--contact' ); ?>>
			<header class="nexora-page__hero">
				<div class="nexora-page__atmosphere" aria-hidden="true"></div>
				<div class="nexora-wrap nexora-page__intro">
					<p class="nexora-eyebrow">
						<span class="nexora-eyebrow__ico" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M4 6h16v12H4V6Zm0 0 8 7 8-7" stroke="currentColor" stroke-width="1.75" stroke-linejoin="round"/></svg>
						</span>
						<?php esc_html_e( 'Contact', 'nexora' ); ?>
					</p>
					<h1><?php the_title(); ?></h1>
					<p class="nexora-lede"><?php esc_html_e( 'Guide questions, corrections, or a real partnership — not a spam blast.', 'nexora' ); ?></p>
				</div>
			</header>

			<div class="nexora-wrap nexora-contact">
				<aside class="nexora-contact__aside">
					<div class="nexora-contact__card">
						<p class="nexora-contact__card-label"><?php esc_html_e( 'Direct email', 'nexora' ); ?></p>
						<a class="nexora-contact__email" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
						<p class="nexora-contact__note"><?php esc_html_e( 'I read mail. I do not promise same-hour replies.', 'nexora' ); ?></p>
					</div>
					<div class="nexora-contact__intro nexora-prose">
						<?php the_content(); ?>
					</div>
				</aside>

				<div class="nexora-contact__panel">
					<?php if ( 'sent' === $status ) : ?>
						<p class="nexora-alert nexora-alert--ok" role="status"><?php esc_html_e( 'Thank you — your message has been sent. Our support team will reply as soon as possible.', 'nexora' ); ?></p>
					<?php elseif ( 'invalid' === $status ) : ?>
						<p class="nexora-alert nexora-alert--err" role="alert"><?php esc_html_e( 'Please complete every field with a valid email.', 'nexora' ); ?></p>
					<?php elseif ( 'error' === $status ) : ?>
						<p class="nexora-alert nexora-alert--err" role="alert">
							<?php
							printf(
								/* translators: %s contact email */
								esc_html__( 'Could not send. Email %s directly.', 'nexora' ),
								esc_html( $email )
							);
							?>
						</p>
					<?php endif; ?>

					<form class="nexora-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="nexora_contact">
						<?php wp_nonce_field( 'nexora_contact', 'nexora_contact_nonce' ); ?>

						<p class="nexora-hp" aria-hidden="true">
							<label for="nexora_website"><?php esc_html_e( 'Website', 'nexora' ); ?></label>
							<input type="text" id="nexora_website" name="nexora_website" tabindex="-1" autocomplete="off">
						</p>

						<div class="nexora-form__row">
							<p class="nexora-field">
								<label for="nexora_name"><?php esc_html_e( 'Name', 'nexora' ); ?></label>
								<input type="text" id="nexora_name" name="nexora_name" required maxlength="120" autocomplete="name">
							</p>
							<p class="nexora-field">
								<label for="nexora_email"><?php esc_html_e( 'Email', 'nexora' ); ?></label>
								<input type="email" id="nexora_email" name="nexora_email" required autocomplete="email" value="<?php echo esc_attr( $prefill_email ); ?>">
							</p>
						</div>
						<p class="nexora-field">
							<label for="nexora_subject"><?php esc_html_e( 'Subject', 'nexora' ); ?></label>
							<input type="text" id="nexora_subject" name="nexora_subject" required maxlength="180" value="<?php echo esc_attr( $prefill_subject ); ?>">
						</p>
						<p class="nexora-field">
							<label for="nexora_message"><?php esc_html_e( 'Message', 'nexora' ); ?></label>
							<textarea id="nexora_message" name="nexora_message" required maxlength="5000" rows="7"></textarea>
						</p>
						<p class="nexora-form__actions">
							<button class="nexora-btn nexora-btn--primary" type="submit"><?php esc_html_e( 'Send message', 'nexora' ); ?></button>
						</p>
					</form>
				</div>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
