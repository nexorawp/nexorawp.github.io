<?php
/**
 * Template Name: Legal
 *
 * Narrow reading column for Privacy, Terms, Affiliate Disclosure.
 *
 * @package Nexora
 */

get_header();
$modified = get_the_modified_date( 'F j, Y' );
?>

<main id="main" class="nexora-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'nexora-page nexora-page--legal' ); ?>>
			<header class="nexora-page__hero">
				<div class="nexora-page__atmosphere" aria-hidden="true"></div>
				<div class="nexora-wrap nexora-page__intro nexora-page__intro--narrow">
					<p class="nexora-eyebrow">
						<span class="nexora-eyebrow__ico" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M7 3h10v18H7V3Zm3 4h4M10 9h4M10 13h4" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/></svg>
						</span>
						<?php esc_html_e( 'Legal', 'nexora' ); ?>
					</p>
					<h1><?php the_title(); ?></h1>
					<?php if ( $modified ) : ?>
						<p class="nexora-legal__meta"><?php
							printf(
								/* translators: %s: modified date */
								esc_html__( 'Last updated %s', 'nexora' ),
								esc_html( $modified )
							);
						?></p>
					<?php endif; ?>
				</div>
			</header>

			<div class="nexora-wrap nexora-legal">
				<div class="nexora-prose nexora-legal__body">
					<?php the_content(); ?>
				</div>
			</div>
		</article>
	<?php endwhile; ?>
</main>

<?php
get_footer();
