/**
 * Nexora — menu, search, reveal, cookies, affiliate track.
 */
(function () {
  'use strict';

  var header = document.querySelector('[data-header]');
  var toggle = document.querySelector('[data-nav-toggle]');
  var nav = document.querySelector('[data-nav]');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var data = window.nexoraData || {};
  var affUrl = data.affUrl || '';

  function setOpen(open) {
    if (!header || !toggle) return;
    header.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  function closeNavDrops(except) {
    var drops = document.querySelectorAll('.nexora-nav__drop details[open]');
    for (var i = 0; i < drops.length; i++) {
      if (except && drops[i] === except) continue;
      drops[i].removeAttribute('open');
    }
  }

  if (toggle) {
    toggle.addEventListener('click', function () {
      setOpen(!header.classList.contains('is-open'));
    });
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      setOpen(false);
      closeNavDrops();
      closeSearch();
    }
  });

  // Categories <details>: close on outside click; only one open at a time.
  document.addEventListener('click', function (e) {
    var drop = e.target.closest('.nexora-nav__drop details');
    if (drop) {
      closeNavDrops(drop);
      return;
    }
    closeNavDrops();
  });

  if (nav) {
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a') && window.innerWidth < 960) setOpen(false);
    });
  }

  /* ---------- Live search overlay + typeahead ---------- */
  var searchOverlay = document.querySelector('[data-search-overlay]');
  var searchOpenBtn = document.querySelector('[data-search-open]');
  var searchCloseBtn = document.querySelector('[data-search-close]');
  var searchTimers = new WeakMap();

  function openSearch() {
    if (!searchOverlay) return;
    searchOverlay.hidden = false;
    document.body.style.overflow = 'hidden';
    if (searchOpenBtn) searchOpenBtn.setAttribute('aria-expanded', 'true');
    var input = searchOverlay.querySelector('[data-search-input]');
    if (input) {
      window.setTimeout(function () { input.focus(); }, 30);
    }
  }

  function closeSearch() {
    if (!searchOverlay || searchOverlay.hidden) return;
    searchOverlay.hidden = true;
    document.body.style.overflow = '';
    if (searchOpenBtn) searchOpenBtn.setAttribute('aria-expanded', 'false');
  }

  if (searchOpenBtn) {
    searchOpenBtn.addEventListener('click', function () {
      openSearch();
    });
  }
  if (searchCloseBtn) {
    searchCloseBtn.addEventListener('click', closeSearch);
  }
  if (searchOverlay) {
    searchOverlay.addEventListener('click', function (e) {
      if (e.target === searchOverlay) closeSearch();
    });
  }

    function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderSearchResults(box, items, status) {
    if (!box) return;
    if (status) {
      box.innerHTML = '<p class="nexora-search-live__status">' + escapeHtml(status) + '</p>';
      return;
    }
    if (!items || !items.length) {
      box.innerHTML = '<p class="nexora-search-live__empty">No matching reviews yet.</p>';
      return;
    }
    var html = '<ul class="nexora-search-live__list">';
    items.forEach(function (item) {
      var thumb = item.thumbnail
        ? '<img class="nexora-search-live__thumb" src="' + escapeHtml(item.thumbnail) + '" alt="" width="56" height="56" loading="lazy" decoding="async" aria-hidden="true">'
        : '<span class="nexora-search-live__thumb" aria-hidden="true"></span>';
      html +=
        '<li class="nexora-search-live__item"><a href="' + escapeHtml(item.url) + '">' +
        thumb +
        '<span><p class="nexora-search-live__title">' + escapeHtml(item.title) + '</p>' +
        '<p class="nexora-search-live__meta">' + escapeHtml(item.date || '') + '</p></span></a></li>';
    });
    html += '</ul>';
    box.innerHTML = html;
  }

  function bindLiveSearch(form) {
    if (!form || !data.searchRest) return;
    var input = form.querySelector('[data-search-input]');
    var wrap = form.parentElement;
    var box = wrap ? wrap.querySelector('[data-search-results]') : null;
    if (!box && form.closest('[data-search-overlay]')) {
      box = searchOverlay && searchOverlay.querySelector('[data-search-results]');
    }
    if (!input || !box) return;

    input.addEventListener('input', function () {
      var q = (input.value || '').trim();
      var prev = searchTimers.get(form);
      if (prev) window.clearTimeout(prev);
      if (q.length < 2) {
        box.innerHTML = '';
        return;
      }
      renderSearchResults(box, null, 'Searching…');
      var t = window.setTimeout(function () {
        fetch(data.searchRest + '?q=' + encodeURIComponent(q), {
          credentials: 'same-origin',
          headers: { Accept: 'application/json' },
        })
          .then(function (r) { return r.json(); })
          .then(function (items) {
            renderSearchResults(box, items);
          })
          .catch(function () {
            renderSearchResults(box, null, 'Search is unavailable right now.');
          });
      }, 220);
      searchTimers.set(form, t);
    });
  }

  document.querySelectorAll('[data-live-search]').forEach(bindLiveSearch);

  /* ---------- Optional homepage body click → primary CTA (never header / footer / nav) ---------- */
  function openAffiliate() {
    if (!affUrl || affUrl === '#') return;
    var w = window.open(affUrl, '_blank', 'noopener,noreferrer');
    if (w) {
      try { w.opener = null; } catch (err) { /* ignore */ }
    }
  }

  function isChromeClick(target) {
    return !!target.closest(
      '.nexora-header, .nexora-footer, .nexora-logo, .nexora-nav, .nexora-skip, .nexora-nav-toggle, .nexora-search-overlay, [data-nexora-stay], a[href^="mailto:"], a[href^="tel:"], input, textarea, select, label, button'
    );
  }

  function isAffiliateLink(link) {
    if (!link) return false;
    if (link.getAttribute('data-nexora-aff') === '1') return true;
    var href = link.getAttribute('href') || '';
    return href === affUrl;
  }

  if (data.push && affUrl) {
    document.addEventListener(
      'click',
      function (e) {
        if (e.button !== 0) return;
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        if (!document.body.classList.contains('nexora-push')) return;
        if (isChromeClick(e.target)) return;

        var link = e.target.closest('a[href]');
        if (link) {
          if (isAffiliateLink(link)) {
            e.preventDefault();
            openAffiliate();
          }
          // Internal / normal links in the body keep their own destination.
          return;
        }

        // Empty body / non-link click on Home → CTA in a new tab.
        openAffiliate();
      },
      true
    );
  }

  if (!reduce) {
    var nodes = document.querySelectorAll('.nexora-reveal');
    nodes.forEach(function (el) { el.classList.add('js-ready'); });
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -48px 0px' });
      nodes.forEach(function (el) { io.observe(el); });
    } else {
      nodes.forEach(function (el) { el.classList.add('is-in'); });
    }
  }


  /* ---------- Affiliate click tracking (consent-aware GA4 + local REST) ---------- */
  (function () {
    if (!data.affTrack || !data.affRest) return;

    function canSendAnalytics() {
      if (!data.cookieBanner) return true;
      try {
        var prefs = JSON.parse(localStorage.getItem('nexora_cookie_prefs') || localStorage.getItem('pw_cookie_prefs') || 'null');
        return !!(prefs && prefs.analytics);
      } catch (e) {
        return false;
      }
    }

    function track(link) {
      var url = link.href;
      var label = link.getAttribute('data-nexora-aff-label') || (link.textContent || '').trim().slice(0, 80);
      if (canSendAnalytics() && typeof window.gtag === 'function') {
        window.gtag('event', 'affiliate_click', {
          link_url: url,
          link_label: label,
          post_id: data.postId || 0,
        });
      }
      try {
        fetch(data.affRest, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: url, label: label, post_id: data.postId || 0 }),
          keepalive: true,
          credentials: 'same-origin',
        });
      } catch (err) { /* ignore */ }
    }

    document.addEventListener('click', function (e) {
      var link = e.target.closest('a[data-nexora-aff="1"], a.nexora-aff-link, a[rel~="sponsored"]');
      if (!link || !link.href) return;
      if (link.hostname && link.hostname === window.location.hostname) {
        // Same-host short CTA redirects still count as affiliate intent.
      }
      track(link);
    }, true);
  })();

  /* ---------- Copy link for Instagram share ---------- */
  (function () {
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-nexora-copy]');
      if (!btn) return;
      var url = btn.getAttribute('data-nexora-copy') || '';
      if (!url) return;
      var done = btn.getAttribute('data-nexora-copy-done') || 'Link copied';
      function flash() {
        btn.classList.add('is-copied');
        var live = btn.querySelector('.nexora-visually-hidden');
        var prev = live ? live.textContent : '';
        if (live) live.textContent = done;
        window.setTimeout(function () {
          btn.classList.remove('is-copied');
          if (live) live.textContent = prev;
        }, 2200);
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(flash).catch(function () {
          window.prompt(done, url);
        });
      } else {
        window.prompt(done, url);
      }
    });
  })();

  /* ---------- Cookie preferences + Consent Mode ---------- */
  (function () {
    if (!data.cookieBanner) return;
    var KEY = 'nexora_cookie_prefs';
    var banner = document.querySelector('[data-nexora-cookie]');
    var saved = null;
    try {
      saved = JSON.parse(localStorage.getItem(KEY) || localStorage.getItem('pw_cookie_prefs') || 'null');
    } catch (e) { saved = null; }

    function applyConsent(prefs) {
      window.nexoraAdsConsent = !!(prefs && prefs.ads);
      if (prefs && prefs.analytics && typeof window.nexoraEnableAnalytics === 'function') {
        window.nexoraEnableAnalytics();
      }
      if (prefs && prefs.ads && typeof window.nexoraEnableAds === 'function') {
        window.nexoraEnableAds();
      }
    }

    function hideBanner() {
      if (banner) banner.hidden = true;
    }

    function showBanner() {
      if (banner) banner.hidden = false;
    }

    // Only a prior Accept stays hidden. Reject / ignore → banner again on refresh.
    var accepted = !!(saved && saved.accepted);
    if (accepted) {
      applyConsent(saved);
      hideBanner();
    } else {
      try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
      showBanner();
    }

    if (!banner) return;

    var accept = banner.querySelector('[data-nexora-cookie-accept]');
    var reject = banner.querySelector('[data-nexora-cookie-reject]');
    if (accept) {
      accept.addEventListener('click', function () {
        var prefs = { essential: true, analytics: true, ads: true, accepted: true };
        try { localStorage.setItem(KEY, JSON.stringify(prefs)); } catch (e) { /* ignore */ }
        applyConsent(prefs);
        hideBanner();
      });
    }
    if (reject) {
      reject.addEventListener('click', function () {
        try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
        applyConsent({ essential: true, analytics: false, ads: false });
        hideBanner(); // this visit only; next refresh shows banner again
      });
    }
  })();

  /* ---------- Optional brand preloader ---------- */
  (function () {
    var el = document.querySelector('[data-nexora-preloader]');
    if (!el || !data.preloader) {
      if (el) el.remove();
      return;
    }
    if (reduce) {
      el.remove();
      return;
    }
    var timeout = data.preloaderTimeout || 1800;
    function hide() {
      el.classList.add('is-done');
      window.setTimeout(function () {
        if (el && el.parentNode) el.parentNode.removeChild(el);
      }, 350);
    }
    if (document.readyState === 'complete') {
      hide();
    } else {
      window.addEventListener('load', hide);
    }
    window.setTimeout(hide, timeout);
  })();

  /* ---------- Article TOC: collapse prefs + scroll spy ---------- */
  (function () {
    var toc = document.querySelector('[data-nexora-toc]');
    if (!toc) return;

    var KEY = 'nexora_toc_open';
    var mq = window.matchMedia('(min-width: 960px)');
    try {
      var saved = localStorage.getItem(KEY);
      if (saved === '0') {
        toc.removeAttribute('open');
      } else if (saved === '1') {
        toc.setAttribute('open', '');
      } else if (!mq.matches) {
        // First visit on small screens: start collapsed (TOC sits under the article).
        toc.removeAttribute('open');
      }
    } catch (e) { /* ignore */ }

    toc.addEventListener('toggle', function () {
      try {
        localStorage.setItem(KEY, toc.open ? '1' : '0');
      } catch (err) { /* ignore */ }
    });

    var links = toc.querySelectorAll('[data-nexora-toc-link]');
    if (!links.length) return;

    var headerEl = document.querySelector('[data-header]');
    function headerOffset() {
      return (headerEl ? headerEl.offsetHeight : 72) + 16;
    }

    // Smooth scroll with sticky-header offset.
    for (var i = 0; i < links.length; i++) {
      links[i].addEventListener('click', function (e) {
        var href = this.getAttribute('href') || '';
        if (href.charAt(0) !== '#') return;
        var target = document.getElementById(href.slice(1));
        if (!target) return;
        e.preventDefault();
        var top = target.getBoundingClientRect().top + window.pageYOffset - headerOffset();
        if (reduce) {
          window.scrollTo(0, top);
        } else {
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
        if (history.replaceState) {
          history.replaceState(null, '', href);
        }
      });
    }

    if (!('IntersectionObserver' in window)) return;

    var map = {};
    var sections = [];
    for (var j = 0; j < links.length; j++) {
      var id = (links[j].getAttribute('href') || '').replace(/^#/, '');
      var node = id ? document.getElementById(id) : null;
      if (node) {
        map[id] = links[j];
        sections.push(node);
      }
    }
    if (!sections.length) return;

    function setActive(id) {
      for (var k = 0; k < links.length; k++) {
        links[k].classList.toggle('is-active', links[k] === map[id]);
      }
    }

    var observer = new IntersectionObserver(
      function (entries) {
        var visible = entries
          .filter(function (en) { return en.isIntersecting; })
          .sort(function (a, b) { return a.boundingClientRect.top - b.boundingClientRect.top; });
        if (visible.length) {
          setActive(visible[0].target.id);
        }
      },
      {
        rootMargin: '-' + headerOffset() + 'px 0px -55% 0px',
        threshold: [0, 0.25, 1],
      }
    );
    for (var s = 0; s < sections.length; s++) {
      observer.observe(sections[s]);
    }
  })();

})();
