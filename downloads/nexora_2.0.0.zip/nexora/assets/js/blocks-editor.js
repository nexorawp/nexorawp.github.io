( function ( wp ) {
  if ( ! wp || ! wp.blocks ) return;
  var el = wp.element.createElement;
  var Fragment = wp.element.Fragment;
  var InspectorControls = wp.blockEditor.InspectorControls;
  var TextControl = wp.components.TextControl;
  var TextareaControl = wp.components.TextareaControl;
  var PanelBody = wp.components.PanelBody;
  var ServerSideRender = wp.serverSideRender;
  var register = wp.blocks.registerBlockType;

  function editFields( props, fields ) {
    return el(
      Fragment,
      null,
      el(
        InspectorControls,
        null,
        el(
          PanelBody,
          { title: 'Settings', initialOpen: true },
          fields.map( function ( f ) {
            var Comp = f.multiline ? TextareaControl : TextControl;
            return el( Comp, {
              key: f.key,
              label: f.label,
              value: props.attributes[ f.key ] || '',
              onChange: function ( v ) {
                var o = {};
                o[ f.key ] = v;
                props.setAttributes( o );
              },
            } );
          } )
        )
      ),
      el( ServerSideRender, { block: props.name, attributes: props.attributes } )
    );
  }

  register( 'nexora/ad', {
    edit: function ( props ) {
      return editFields( props, [
        { key: 'placement', label: 'Placement key (e.g. end_content)' },
        { key: 'slot', label: 'Ad unit ID (optional)' },
      ] );
    },
    save: function () {
      return null;
    },
  } );

  register( 'nexora/product', {
    edit: function ( props ) {
      return editFields( props, [
        { key: 'name', label: 'Product name' },
        { key: 'url', label: 'Affiliate URL' },
        { key: 'image', label: 'Image URL' },
        { key: 'badge', label: 'Badge' },
        { key: 'cta', label: 'Button label' },
        { key: 'pros', label: 'Pros (pipe-separated)', multiline: true },
        { key: 'cons', label: 'Cons (pipe-separated)', multiline: true },
        { key: 'features', label: 'Features (pipe-separated)', multiline: true },
        { key: 'body', label: 'Description', multiline: true },
      ] );
    },
    save: function () {
      return null;
    },
  } );

  register( 'nexora/compare', {
    edit: function ( props ) {
      return editFields( props, [
        { key: 'rows', label: 'Rows: Name|Note|URL (one per line)', multiline: true },
      ] );
    },
    save: function () {
      return null;
    },
  } );

  register( 'nexora/disclosure', {
    edit: function () {
      return el( 'p', { className: 'nexora-disclosure-block' }, el( 'em', null, 'Affiliate disclosure (rendered on the front end)' ) );
    },
    save: function () {
      return null;
    },
  } );

  /* Legacy paulworld/* names still present in older post HTML */
  ['ad', 'product', 'compare', 'disclosure'].forEach( function ( slug ) {
    var from = 'nexora/' + slug;
    var to = 'paulworld/' + slug;
    if ( wp.blocks.getBlockType( from ) && ! wp.blocks.getBlockType( to ) ) {
      register( to, {
        edit: wp.blocks.getBlockType( from ).edit,
        save: function () {
          return null;
        },
      } );
    }
  } );
} )( window.wp );
