<?php
/**
 * Global header: logo left, nav center, Contact + search right.
 *
 * @package Nexora
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="nexora-skip" href="#main"><?php esc_html_e( 'Skip to content', 'nexora' ); ?></a>

<header class="nexora-header" data-header>
	<div class="nexora-header__bar nexora-wrap">
		<?php if ( has_custom_logo() ) : ?>
			<div class="nexora-logo nexora-logo--custom"><?php the_custom_logo(); ?></div>
		<?php else : ?>
			<a class="nexora-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<img class="nexora-logo__icon" src="<?php echo esc_url( nexora_mark_url( 'svg' ) ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="24" height="24" decoding="async">
				<span aria-hidden="true"><?php nexora_logo_wordmark(); ?></span>
			</a>
		<?php endif; ?>

		<nav id="nexora-nav" class="nexora-nav" data-nav aria-label="<?php esc_attr_e( 'Primary', 'nexora' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'nexora-nav__list',
					'fallback_cb'    => 'nexora_fallback_menu',
					'depth'          => 2,
					'walker'         => class_exists( 'Nexora_Nav_Walker' ) ? new Nexora_Nav_Walker() : null,
				)
			);
			?>
		</nav>

		<div class="nexora-header__end">
			<button type="button" class="nexora-search-open" data-search-open aria-expanded="false" aria-controls="nexora-search-overlay">
				<span class="nexora-visually-hidden"><?php esc_html_e( 'Open search', 'nexora' ); ?></span>
				<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
			</button>
			<a class="nexora-btn nexora-btn--primary nexora-header__contact" href="<?php echo esc_url( nexora_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact us', 'nexora' ); ?></a>
			<button class="nexora-nav-toggle" type="button" data-nav-toggle aria-controls="nexora-nav" aria-expanded="false">
				<span class="nexora-nav-toggle__bars" aria-hidden="true"></span>
				<span class="nexora-visually-hidden"><?php esc_html_e( 'Menu', 'nexora' ); ?></span>
			</button>
		</div>
	</div>
</header>

<div class="nexora-search-overlay" id="nexora-search-overlay" data-search-overlay hidden>
	<div class="nexora-search-overlay__panel nexora-wrap" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: site name */ __( 'Search %s', 'nexora' ), get_bloginfo( 'name', 'display' ) ) ); ?>">
		<form class="nexora-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-live-search>
			<label class="nexora-visually-hidden" for="nexora-search-input"><?php esc_html_e( 'Search guides', 'nexora' ); ?></label>
			<input id="nexora-search-input" class="nexora-search-form__input" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search car maintenance, DIY repair, mechanic tips…', 'nexora' ); ?>" autocomplete="off" data-search-input>
			<button class="nexora-btn nexora-btn--primary" type="submit"><?php esc_html_e( 'Search', 'nexora' ); ?></button>
			<button type="button" class="nexora-search-form__close" data-search-close><?php esc_html_e( 'Close', 'nexora' ); ?></button>
		</form>
		<div class="nexora-search-live" data-search-results aria-live="polite"></div>
	</div>
</div>

<?php if ( function_exists( 'nexora_ad_slot' ) ) : ?>
	<div class="nexora-ad-band"><?php nexora_ad_slot( 'below_nav' ); ?></div>
<?php endif; ?>
