# Nexora theme

Copy this folder to `wp-content/themes/nexora` and activate it.

Full operator guide (homepage, menu, affiliate URL, contact → webmail): see the repository root `README.md` and `doc/`.

## Customizer

**Appearance → Nexora** (full dashboard) or **Appearance → Customize → Theme Funnel**

- Primary CTA / affiliate URL
- Contact email (form `To:` / webmail)
- Footer disclosure (`{Site name} is reader-supported…`)

## Contact form

`admin-post.php?action=nexora_contact` → `wp_mail()`. Reply from your webmail using the visitor’s address.
