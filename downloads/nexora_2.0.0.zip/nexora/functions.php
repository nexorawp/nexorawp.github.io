<?php
/**
 * Nexora theme bootstrap.
 *
 * @package Nexora
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Commercial display name. */
define( 'NEXORA_THEME_NAME', 'Nexora' );
/** Theme / package slug (matches stylesheet directory). */
define( 'NEXORA_THEME_SLUG', 'nexora' );

define( 'NEXORA_VERSION', '2.0.0-nexora' );
/*
 * Do not bump this to force legal/about HTML rewrites on live sites.
 * Seeded pages are created only when missing; existing content is left alone.
 */
define( 'NEXORA_CONTENT_VERSION', '1.5.0' );
define( 'NEXORA_DIR', get_template_directory() );
define( 'NEXORA_URI', get_template_directory_uri() );
define( 'NEXORA_DEFAULT_AFFILIATE_URL', '' );

require_once NEXORA_DIR . '/inc/compat.php';
require_once NEXORA_DIR . '/inc/setup.php';
require_once NEXORA_DIR . '/inc/theme-options.php';
require_once NEXORA_DIR . '/inc/niches.php';
require_once NEXORA_DIR . '/inc/enqueue.php';
require_once NEXORA_DIR . '/inc/performance.php';
require_once NEXORA_DIR . '/inc/github-updater.php';
require_once NEXORA_DIR . '/inc/customizer.php';
require_once NEXORA_DIR . '/inc/admin-settings.php';
require_once NEXORA_DIR . '/inc/contact-form.php';
require_once NEXORA_DIR . '/inc/schema.php';
require_once NEXORA_DIR . '/inc/seo.php';
require_once NEXORA_DIR . '/inc/article.php';
require_once NEXORA_DIR . '/inc/magazine.php';
require_once NEXORA_DIR . '/inc/ads.php';
require_once NEXORA_DIR . '/inc/affiliate.php';
require_once NEXORA_DIR . '/inc/affiliate-analytics.php';
require_once NEXORA_DIR . '/inc/blocks.php';
require_once NEXORA_DIR . '/inc/privacy.php';
require_once NEXORA_DIR . '/inc/cta-links.php';
require_once NEXORA_DIR . '/inc/pages-setup.php';
