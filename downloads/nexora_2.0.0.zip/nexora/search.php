<?php
/**
 * Search results — magazine grid + refined search.
 *
 * @package Nexora
 */

get_header();
$query = get_search_query();
?>

<main id="main" class="nexora-main">
	<header class="nexora-page__hero nexora-search-hero">
		<div class="nexora-wrap">
			<p class="nexora-search-hero__kicker"><?php esc_html_e( 'Search', 'nexora' ); ?></p>
			<h1>
				<?php
				if ( $query ) {
					printf(
						/* translators: %s: search query */
						esc_html__( 'Results for “%s”', 'nexora' ),
						esc_html( $query )
					);
				} else {
					esc_html_e( 'Search guides', 'nexora' );
				}
				?>
			</h1>
			<form class="nexora-search-form nexora-search-form--page" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-live-search>
				<label class="nexora-visually-hidden" for="nexora-search-page"><?php esc_html_e( 'Search guides', 'nexora' ); ?></label>
				<input id="nexora-search-page" class="nexora-search-form__input" type="search" name="s" value="<?php echo esc_attr( $query ); ?>" placeholder="<?php esc_attr_e( 'Search car maintenance, DIY repair, mechanic tips…', 'nexora' ); ?>" autocomplete="off" data-search-input autofocus>
				<button class="nexora-btn nexora-btn--primary" type="submit"><?php esc_html_e( 'Search', 'nexora' ); ?></button>
			</form>
			<div class="nexora-search-live nexora-search-live--page" data-search-results aria-live="polite"></div>
		</div>
	</header>
	<div class="nexora-wrap nexora-magazine">
		<?php if ( have_posts() ) : ?>
			<div class="nexora-magazine__grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<div class="nexora-magazine__cell">
						<?php get_template_part( 'template-parts/content', 'post' ); ?>
					</div>
				<?php endwhile; ?>
			</div>
			<?php
			global $wp_query;
			if ( $wp_query->max_num_pages > 1 ) :
				?>
			<nav class="nexora-pagination" aria-label="<?php esc_attr_e( 'Search pages', 'nexora' ); ?>">
				<?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
			</nav>
			<?php endif; ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>
</main>

<?php
get_footer();
